/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.venue;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.sim.VirtualTime;
import com.fujitsu.coe.tmh.web.user.LogLocation;
import com.fujitsu.coe.tmh.web.util.AdminType;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.IdExistCheck;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import com.fujitsu.coe.tmh.web.util.LogManage;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import com.fujitsu.coe.tmh.web.util.ValidationCheck;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author qnet8733
 */
@Path("/")
@ApplicationScoped
public class VenueService {

    String classname = VenueService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    @ClasspathResource("CreateVenueInfo.sql")
    private String sqlCreateVenueInfo;
    @Inject
    @ClasspathResource("UpdateVenueInfo.sql")
    private String sqlUpdateVenueInfo;
    @Inject
    @ClasspathResource("UpdateCouponFlag.sql")
    private String sqlUpdateCouponFlag;
    @Inject
    @ClasspathResource("UpdateShopFlag.sql")
    private String sqlUpdateShopFlag;
    @Inject
    @ClasspathResource("UpdateVenueFlag.sql")
    private String sqlUpdateVenueFlag;
    @Inject
    @ClasspathResource("SelectUserType.sql")
    private String sqlSelectUserType;
    @Inject
    @ClasspathResource("SelectShopList.sql")
    private String sqlSelectShopList;
    @Inject
    private SystemSettings settings;
    @Inject
    private LogManage logger;
    @Inject
    private IdExistCheck idExist;
    @Inject
    private AdminType adminUtil;

    /**
     * 開催地リスト取得 (API No.19)
     *
     * @param user [IN] ユーザID(必須)
     * @return 有効な全開催地情報リスト
     * @author Qnet)mikami
     */
    @GET
    @Path("/venuelist")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String, Object> getVenueList(
            @QueryParam("id") String user
    ) throws SQLException {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[id=" + user + "]");

        // 必須パラメータチェック
        if (user == null || user.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(user))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // パラメタチェック
        try {
            // ユーザIDがない場合はエラー
            if (idExist.validateUserId(user) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 有効な開催地DBの登録レコード数を取得
        int count;
        try {
            count = idExist.getRecordCount("venue", "enable_flag", ENABLE_FLAG, null);
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        // 有効な開催地DBの登録数が開催地リスト取得数最大値以上の場合はエラー(LIMIT_GET_CODE：取得数の上限に達した)
        Integer maxnum = Integer.parseInt(settings.get("maxnum.getvenuelist", DB_DEFAULT_MAX_NUM));
        if (count >= maxnum) {
            logger.log(Level.WARNING, classname, methodName, LIMIT_GET_MSG);
            return ErrorFactory.createError(LIMIT_GET_CODE, LIMIT_GET_MSG);
        }

        // ユーザIDの権限はチェックせず全開催地情報を取得
        final Map<String, Object> response = new HashMap<>();
        final ArrayList<Map> venues;
        venues = new ArrayList<>();
        try {
            db.query("SELECT venue_id, name, lat, lon FROM venue WHERE enable_flag=?", (rs) -> {
                final Map<String, Object> res = new HashMap<>();
                res.put("venue_id", rs.getString(1));
                res.put("name", rs.getString(2));
                res.put("lat", rs.getString(3));
                res.put("lon", rs.getString(4));
                venues.add(res);
            }, ENABLE_FLAG);
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // 取得した開催地リストをリターン
        response.put("venue_list", venues);
        logger.log(Level.FINE, classname, methodName, "END");
        return response;
    }

    /**
     * 開催地設定
     *
     * @param adminID
     * @param name
     * @param venueID
     * @param lat
     * @param lon
     * @return
     */
    @POST
    @Path("/venue")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @VirtualTime
    @Transactional
    public Map setVenue(@FormParam("admin_id") String adminID,
            @FormParam("name") String name,
            @FormParam("venue_id") @DefaultValue("-1") int venueID,
            @FormParam("lat") @DefaultValue("-1") Float lat,
            @FormParam("lon") @DefaultValue("-1") Float lon
    ) {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id=%s, name=%s, venue_id=%d, lat=%f, lon=%f]", adminID, name, venueID, lat, lon);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        /**
         * 必須チェック　キー指定なし
         */
        if (adminID == null || name == null || lat <= 0.0 || lon <= 0.0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * 必須チェック　キー指定あり
         */
        if (adminID.equals("") || name.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(venueID));
        if (validate == false) {
            validateErr.add("venue_id");
        }

        validate = ValidationCheck.checkStr100(name);
        if (validate == false) {
            validateErr.add("name");
        }

        int res = -1;
        if (lat != -1) {
            res = ValidationCheck.checkLatLon(lat);
            if (res == NUM_DECIMAL_OVER) {
                //小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(lat);
            } else if (res != 0) {
                validateErr.add("lat");
            }
        }

        if (lon != -1) {
            res = ValidationCheck.checkLatLon(lon);
            if (res == NUM_DECIMAL_OVER) {
                //小数部の最大桁数超えの場合は四捨五入する
                lon = ValidationCheck.roundUpLatLon(lon);
            } else if (res != 0) {
                validateErr.add("lon");
            }
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        //開催地IDが存在しない場合は登録、存在する場合は変更とする。
        int result = 0;
        boolean enableFlag = true;

        try {

            int count = idExist.getRecordCountAll("venue", null);
            int maxCount = Integer.parseInt(settings.get("maxnum.getvenuelist", "-1"));
            //登録数条件チェック
            if (maxCount > 0 && maxCount <= count) {
                logger.log(Level.SEVERE, classname, methodName, LIMIT_SHOP_REGISTER_CODE + " " + LIMIT_SHOP_REGISTER_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(LIMIT_SHOP_REGISTER_CODE, LIMIT_SHOP_REGISTER_MSG);
            }

            //権限チェック
            int adminType = 0;
            adminType = adminUtil.getUserType(adminID);

            if (adminType != USER_INFO_TYPE_SYSTEM) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            //開催地IDが指定されている場合
            if (venueID != -1) {
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s, %f, %f, %d]", sqlUpdateVenueInfo, name, lat, lon, venueID));
                result = db.update(sqlUpdateVenueInfo, name, lat, lon, venueID);
            }

            //開催地IDが指定されていない場合
            if (venueID == -1) {
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s, %f, %f, %d]", sqlUpdateVenueInfo, name, lat, lon, venueID));
                result = db.update(sqlCreateVenueInfo,
                        name,
                        lat,
                        lon,
                        enableFlag);
            }
        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        //SQLの戻り値チェック
        if (result < 1) {
            logger.log(Level.SEVERE, classname, methodName, SQL_ERROR_CODE + " " + SQL_ERROR_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } else {
            String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
            logger.log(Level.FINE, classname, methodName, outParam);
            logger.log(Level.FINE, classname, methodName, "END");
            //正常
            return MapBuilder.build("ok", true);
        }
    }

    /**
     * 開催地情報削除
     *
     * @param adminID
     * @param venueID
     * @return
     */
    @POST
    @Path("/delete_venue")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @VirtualTime
    @Transactional
    public Map deleteVenue(@FormParam("admin_id") String adminID, @FormParam("venue_id") @DefaultValue("-1") int venueID) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id=%s, venue_id=%d]", adminID, venueID);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        /**
         * 必須チェック
         */
        if (adminID == null || adminID.equals("") || venueID < 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(venueID));
        if (validate == false) {
            validateErr.add("venue_id");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        int result = 0;

        try {
            //システム管理者でないばあいは、エラー
            //権限チェック
            int adminType = 0;
            adminType = adminUtil.getUserType(adminID);

            if (adminType != USER_INFO_TYPE_SYSTEM) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            result = this.updateSql(venueID);

        } catch (Exception sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        if (result < 1) {
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
        logger.log(Level.FINE, classname, methodName, outParam);
        logger.log(Level.FINE, classname, methodName, "END");
        //正常
        return MapBuilder.build("ok", true);
    }

    /**
     * 開催地を削除する
     *
     * @param venueID
     * @throws SQLException
     */
    public int updateSql(int venueID) throws SQLException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        logger.log(Level.FINE, classname, methodName, "START");

        int result = 0;
        int shopID = 0;
        boolean flag = false;

        try {
            //開催地配下の店舗を取得する
            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sqlSelectShopList, shopID));
            List<String> shopList = new ArrayList<>();
            db.query(sqlSelectShopList, (rs) -> {
                shopList.add(rs.getString("shop_id"));
            }, venueID);

            //店舗削除
            if (shopList.size() > 0) {
                String[] arr = new String[shopList.size()];
                shopList.toArray(arr);
                String sql = sqlUpdateCouponFlag;
                String separator = " OR shop_id = ";
                sql = sql + String.join(separator, arr);
                //クーポン削除
                //結果が0の場合は許容
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sqlUpdateCouponFlag, flag, shopID));
                result = db.update(sql, flag);

                sql = sqlUpdateShopFlag;
                sql = sql + String.join(separator, arr);
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sql, flag));
                result = db.update(sql, flag);
                if (result < 1) {
                    //shopIDがあるのに、結果が0の場合は異常
                    throw new SQLException("can't find shop_id[" + shopID + "]");
                }
            }

            //開催地削除
            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s, %d]", sqlUpdateVenueFlag, flag, venueID));
            result = db.update(sqlUpdateVenueFlag, flag, venueID);

            if (result < 1) {
                //venueIDがあるのに、結果が0の場合は異常
                //logger.log(Level.SEVERE, classname, methodName, "can't find venueID[" + venueID + "]");
                throw new SQLException("can't find venue_id[" + venueID + "]");
            }
        } catch (SQLException runEx) {
            logger.log(Level.FINE, classname, methodName, "END");
            throw runEx;
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return result;
    }
}
