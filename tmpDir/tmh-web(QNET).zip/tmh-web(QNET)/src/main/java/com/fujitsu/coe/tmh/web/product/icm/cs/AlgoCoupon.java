package com.fujitsu.coe.tmh.web.product.icm.cs;

/**
 *
 * @author chuakayick
 */
public class AlgoCoupon {
    public final long couponId;
    public final String category;
    public final long shopId;
    public final double rating;

    public AlgoCoupon(long couponId, String category, long shopId, double rating) {
        this.couponId = couponId;
        this.category = category;
        this.shopId = shopId;
        this.rating = rating;
    }

}
