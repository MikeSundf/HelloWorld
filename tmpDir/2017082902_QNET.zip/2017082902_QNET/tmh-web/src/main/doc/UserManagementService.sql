--------------------------------------------------UserManagementService
-- user_info
create table user_info( 
  user_id character varying (45) not null
  , name character varying (45) default NULL
  , home_address character varying (100) default NULL
  , postal_code character varying (45) default NULL
  , email character varying (100) not null
  , password character varying (100) not null
  , suspended_until timestamp without time zone default NULL
  , mobile_num character varying (45) default NULL
  , mobile_os character varying (45) default NULL
  , notification_id character varying (45) default NULL
  , type integer not null
  , last_login_time timestamp without time zone default NULL
  , update_time timestamp without time zone not null
  , created_time timestamp without time zone default now() not null
  , constraint user_info_pkey primary key (user_id)
  , constraint user_info_email_key UNIQUE (email)
); 

-- user_login_failure
create table user_login_failure (
  id serial not null
  , user_id character varying(45) default NULL
  , created_time timestamp without time zone default now() not null
  , constraint user_login_failure_pkey primary key (id)
) ;
alter table user_login_failure
  add constraint user_login_failure_pkey1 foreign key (user_id) references user_info(user_id);

-- user_preference
create table user_preference (
  user_id character varying(45) not null
  , pref_key character varying(45) not null
  , pref_value character varying(200) default NULL
  , constraint user_preference_pkey primary key (user_id,pref_key)
) ;
alter table user_preference
  add constraint user_preference_pkey1 foreign key (user_id) references user_info(user_id);

-- user_profile
create table user_profile (
  user_id character varying(45) not null
  , gender character(1) default NULL
  , age_group smallint default NULL
  , income_group smallint default NULL
  , job character varying(100) default NULL
  , workplace_address character varying(100) default NULL
  , is_public_transport boolean default true
  , beta_cg numeric(10, 5) default NULL
  , beta_i numeric(10, 5) default NULL
  , beta_dt numeric(10, 5) default NULL
  , beta_ivtt numeric(10, 5) default NULL
  , beta_ovtt numeric(10, 5) default NULL
  , beta_wt numeric(10, 5) default NULL
  , constraint user_profile_pkey primary key (user_id)
) ;
alter table user_profile
  add constraint user_profile_pkey1 foreign key (user_id) references user_info(user_id);

-- authority_info
create table authority_info (
  id serial not null
  , user_id character varying(45) not null
  , type integer not null
  , manage_id integer not null
  , constraint authority_info_pkey primary key (id)
) ;
alter table authority_info
  add constraint authority_info_pkey1 foreign key (user_id) references user_info(user_id);

-- user_action_log
create table user_action_log (
  id serial NOT NULL
  , time timestamp without time zone default now() not null
  , device_id character varying(100)
  , user_id character varying(45)
  , location_id integer
  , action character varying(100) not null
  , object character varying(100)
  , data text
  , constraint user_action_log_pkey primary key (id)
) ;