UPDATE coupon_logo SET logo=? WHERE coupon_id=?;
INSERT INTO coupon_logo (logo, coupon_id)
       SELECT ?, ?
       WHERE NOT EXISTS (SELECT 1 FROM coupon_logo WHERE coupon_id=?);