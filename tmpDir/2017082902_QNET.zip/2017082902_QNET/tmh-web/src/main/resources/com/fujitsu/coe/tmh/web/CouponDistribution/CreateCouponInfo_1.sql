INSERT 
INTO coupon( 
  shop_id
  , title
  , description
  , terms
  , remarks
  , available
  , max_available
  , expiry_duration
  , expiry_date
  , money_level
  , coupon_value
  , enable_flag
, category
