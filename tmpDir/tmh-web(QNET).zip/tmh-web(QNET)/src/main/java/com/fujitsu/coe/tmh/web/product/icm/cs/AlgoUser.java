package com.fujitsu.coe.tmh.web.product.icm.cs;

import java.util.Set;

/**
 *
 * @author chuakayick
 */
public class AlgoUser {

    public final int hurry;
    public final int hungry;
    public final char gender;
    public final int ageGroup;
    public final int incomeRange;
    public Set<String> likes;

    public AlgoUser(int hurry, int hungry, char gender, int ageGroup, int incomeRange, Set<String> likes) {
        this.hurry = hurry;
        this.hungry = hungry;
        this.gender = gender;
        this.ageGroup = ageGroup;
        this.incomeRange = incomeRange;
        this.likes = likes;
    }
}
