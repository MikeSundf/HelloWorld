--------------------------------------------------LocationService
-- user_location
create table user_location (
  id serial NOT NULL
  , user_id character varying(45) not null
  , time TIMESTAMP not null
  , lat numeric(10, 5) not null
  , lon numeric(10, 5) not null
  , accuracy numeric(10, 5) not null
  , location character varying(100)
  , constraint user_location_pkey primary key (id)
) ;

alter table user_location
  add foreign key (user_id) references user_info(user_id);

-- user_beacon_info
create table user_beacon_info (
  id serial NOT NULL
  , beacon_id character varying(36) not null
  , user_id character varying(45) not null
  , time TIMESTAMP not null
  , major_minor character varying(100) default NULL
  , constraint user_beacon_info_pkey primary key (id)
) ;

-- beacon_info
create table beacon_info (
  beacon_id character varying(36) not null
  , venue_id integer not null
  , lat numeric(10, 5) not null
  , lon numeric(10, 5) not null
  , constraint beacon_info_pkey primary key (beacon_id)
) ;

alter table beacon_info
  add foreign key (venue_id) references venue(venue_id);

-- beacon_facility
create table beacon_facility (
  beacon_id character varying(36) not null
  , facility_type character varying(45) not null
  , facility_id integer not null
  , constraint beacon_facility_pkey primary key (beacon_id,facility_type)
) ;

alter table beacon_facility
  add foreign key (beacon_id) references beacon_info(beacon_id);