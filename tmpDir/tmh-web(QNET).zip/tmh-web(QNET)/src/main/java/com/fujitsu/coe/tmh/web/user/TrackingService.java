package com.fujitsu.coe.tmh.web.user;

import com.fujitsu.coe.ss.fac.CheckRole;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.sql.SQLException;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toTS;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author unicenfujitsu
 */
@Path("/")
@CheckRole("user")
@ApplicationScoped
public class TrackingService {

    @Inject
    private User user;
    @Inject
    private JdbcTemplate db;
    @Inject
    private ActionLogger aLogger;
    @Inject
    private HttpServletRequest req;

    @POST
    @Path("/follow")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map follow(@FormParam("locations") String locations) throws SQLException {
        aLogger.log("LOCATION", null, null);
        String[] lines = locations.split("\n");
        for (String line : lines) {
            String[] tokens = line.split("\t");
            if (tokens.length == 3) {   // beacon, etc
                Date time = new Date(Long.parseLong(tokens[0]));
                double distance = Double.parseDouble(tokens[1]);
                String locationId = tokens[2];
                db.update("INSERT INTO user_location(user_id, time, accuracy, location) VALUES(?, ?, ?, ?)", user.getId(), toTS(time), distance, locationId);
            } else {    // gps
                Date time = new Date(Long.parseLong(tokens[0]));
                double lat = Double.parseDouble(tokens[1]);
                double lon = Double.parseDouble(tokens[2]);
                double accuracy = Double.parseDouble(tokens[3]);
                db.update("INSERT INTO user_location(user_id, time, lat, lon, accuracy) VALUES(?, ?, ?, ?, ?)", user.getId(), toTS(time), lat, lon, accuracy);
            }
        }
        return MapBuilder.build("ok", true);
    }

    @POST
    @Path("/impression")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map impression(@FormParam("action") String action, @FormParam("target") String target) throws SQLException {
        StringBuilder buf = new StringBuilder();
        /*
        for (String key : Collections.list(req.getParameterNames())) {  // TODO: getParameterNames doesn't work with POST
            if ("action".equals(key) || "target".equals(key)) {
                continue;
            }
            buf.append('[').append(key).append('=').append(req.getParameter(key)).append("] ");
        }
        */
        aLogger.log(action, target, buf.toString());
        return MapBuilder.build("ok", true);
    }
}
