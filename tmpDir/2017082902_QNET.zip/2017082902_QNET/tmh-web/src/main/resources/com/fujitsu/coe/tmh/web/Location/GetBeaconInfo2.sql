SELECT beacon_id, lat, lon
FROM beacon_info
WHERE venue_id=?