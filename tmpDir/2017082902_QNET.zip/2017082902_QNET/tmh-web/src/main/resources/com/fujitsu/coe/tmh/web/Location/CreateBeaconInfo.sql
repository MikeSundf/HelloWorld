INSERT INTO beacon_info(beacon_id, venue_id, lat, lon) 
VALUES(?,?,?,?)