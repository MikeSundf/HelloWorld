CREATE TABLE bus_frequency
(
  id serial NOT NULL,
  provider character varying(10),
  service character varying(10),
  direction character varying(10),
  am_peak numeric(4,1),
  am_off numeric(4,1),
  pm_peak numeric(4,1),
  pm_off numeric(4,1),
  CONSTRAINT bus_frequency_pkey PRIMARY KEY (id)
);
