INSERT 
INTO venue(name, lat, lon, enable_flag) 
VALUES (?, ?, ?, ?)