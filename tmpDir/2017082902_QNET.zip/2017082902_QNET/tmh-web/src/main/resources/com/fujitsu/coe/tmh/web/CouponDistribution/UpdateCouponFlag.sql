UPDATE coupon 
SET
  enable_flag = ?
WHERE
  coupon_id = ?
