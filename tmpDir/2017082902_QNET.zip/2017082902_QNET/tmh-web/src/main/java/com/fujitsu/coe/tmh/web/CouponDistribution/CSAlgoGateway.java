package com.fujitsu.coe.tmh.web.CouponDistribution;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.tmh.web.CouponDistribution.ICMContext;
import com.fujitsu.coe.tmh.web.UserManagement.AuthService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author kychua
 */
public class CSAlgoGateway {

    String classname = CSAlgoGateway.class.getName();
    private static final TypeReference<int[]> ARRAY_TYPE = new TypeReference<int[]>() {
    };
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private ICMContext ctx;

    private String YEN = "\"";
    
    public CSAlgoGateway(ICMContext ctx) {
        this.ctx = ctx;
    }

    /**
     * <pre>
     * Pythonの
     * 「Coupon Selection Learning (CSL)」をコールして、
     * 学習を開始する（非同期）
     * </pre>
     *
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public boolean learnCSL() throws SQLException, IOException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        ctx.loggerV2.log(Level.FINE, classname, methodName, "START");

        boolean result = false;
        try {
            //コマンド
            String algo = ctx.settings.get("algo.csl.algo", "/Temp/algo/exeCouponLearning.py");
            String[] argList = {"python", algo};

            //コマンド実行
            ctx.loggerV2.log(Level.FINE, classname, methodName, "AI algo START cmd[" + argList[0] + " " + argList[1] + "]");
            Runtime run = Runtime.getRuntime();
            Process pro = run.exec(argList);
            result = true;

        } catch (IOException ex) {
            result = false;
            ctx.loggerV2.thrownLog(Level.FINE, classname, "", "", ex);
        }

        ctx.loggerV2.log(Level.FINE, classname, methodName, "AI response :" + result + ".");
        ctx.loggerV2.log(Level.FINE, classname, methodName, "END");
        return result;
    }

    /**
     * <pre>
     * Pythonの
     * 「Coupon Selection Recommendation (CSR)」をコールして、
     * おすすめクーポンIDを取得する（同期）
     * </pre>
     *
     * @param userId
     * @param venueId
     * @param lat
     * @param lon
     * @param date
     * @param hungry
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public int[] recommend(String userId, int venueId, Float lat, Float lon, String date, int hungry) throws SQLException, IOException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        ctx.loggerV2.log(Level.FINE, classname, methodName, "START");

        int[] coupons = null;
        String response = "[]";

        try {
            //コマンド
            date = YEN + date + YEN;
            userId = YEN + userId + YEN;
            String algo = ctx.settings.get("algo.csl.algo.csr", "/Temp/algo/getRecommendedCoupons.py");
            String cmd = "";
            if (hungry > 0) {
                //hungryパラメータ指定あり
                //抑制するカテゴリを取得
                String getCat = ctx.settings.get("getcoupon.hungry1", "");
                if (!getCat.equals("")) {
                    String regex = ",";
                    Pattern p = Pattern.compile(regex);
                    Matcher m = p.matcher(getCat);
                    String separator = ",";
                    getCat = YEN + m.replaceFirst(separator) + YEN;

                    String[] argList = {"python", algo, "-user_id", userId, "-venue_id", String.valueOf(venueId),
                        "-lat", lat.toString(), "-lon", lon.toString(), "-time", date, "-hungry", String.valueOf(hungry), "-categories", getCat};
                    cmd = String.join(" ", argList);
                } else {
                    ctx.loggerV2.log(Level.WARNING, classname, methodName, "can't find param[getcoupon.hungry1].");
                    //hungryパラメータ指定なしと同等にする
                    String[] argList = {"python", algo, "-user_id", userId, "-venue_id", String.valueOf(venueId),
                        "-lat", lat.toString(), "-lon", lon.toString(), "-time", date, "-hungry", "0", "-categories", YEN+YEN};
                    cmd = String.join(" ", argList);
                }
            } else {
                //hungryパラメータ指定なし
                String[] argList = {"python", algo, "-user_id", userId, "-venue_id", String.valueOf(venueId),
                    "-lat", lat.toString(), "-lon", lon.toString(), "-time", date, "-hungry", "0", "-categories", YEN+YEN};
                cmd = String.join(" ", argList);
            }

            //コマンド実行
            ctx.loggerV2.log(Level.FINE, classname, methodName, "AI algo START cmd[" + cmd + "]");
            Runtime run = Runtime.getRuntime();
            Process pro = run.exec(cmd);

            String timeout = ctx.settings.get("algo.csl.algo.timeout", "30");
            boolean end = pro.waitFor(Integer.parseInt(timeout), TimeUnit.SECONDS); //タイムアウト
            if (end) {
                if (pro.exitValue() == 0) {
                    ctx.loggerV2.log(Level.FINE, classname, methodName, "AI algo END [response OK, " + pro.exitValue() + "]");
                    InputStream is = pro.getInputStream();	//標準出力
                    response = printInputStream(is);
                } else {
                    ctx.loggerV2.log(Level.FINE, classname, methodName, "AI algo END [response NG, " + pro.exitValue() + "]");
                    response = "[]";
                }
            } else {
                response = "[]";
                ctx.loggerV2.log(Level.FINE, classname, methodName, "AI algo END [TimeOut]");
                //pro.destroy(); // プロセスを強制終了
            }

            ctx.loggerV2.log(Level.FINE, classname, methodName, "AI response :[" + response + "].");
            coupons = MAPPER.readValue(response, ARRAY_TYPE);

        } catch (IOException | InterruptedException ex) {
            coupons = MAPPER.readValue("[]", ARRAY_TYPE);
            ctx.loggerV2.thrownLog(Level.FINE, classname, "", "END", ex);
        }

        ctx.loggerV2.log(Level.FINE, classname, methodName, "END");
        return coupons;
    }

    /**
     * 標準出力を取得する
     *
     * @param is
     * @return
     * @throws IOException
     */
    public static String printInputStream(InputStream is) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String result = "";
        try {
            for (;;) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }
                result = line;
            }
        } finally {
            br.close();
        }
        return result;
    }

}
