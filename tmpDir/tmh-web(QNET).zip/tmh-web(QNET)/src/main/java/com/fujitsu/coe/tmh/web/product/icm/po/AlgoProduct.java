package com.fujitsu.coe.tmh.web.product.icm.po;

/**
 *
 * @author unicenfujitsu
 */
class AlgoProduct {
    private String mode;
    private double fare;
    private int dt;
    private int tt;
    private int wt;
    private int at;
    private int cg;
    private double cv;
    private int ic;

    public AlgoProduct(String mode, double fare, int dt, int tt, int wt, int at, int cg, double cv, int ic) {
        this.mode = mode;
        this.fare = fare;
        this.dt = dt;
        this.tt = tt;
        this.wt = wt;
        this.at = at;
        this.cg = cg;
        this.cv = cv;
        this.ic = ic;
    }

    public String getMode() {
        return mode;
    }

    public double getFare() {
        return fare;
    }

    public int getDt() {
        return dt;
    }

    public int getTt() {
        return tt;
    }

    public int getWt() {
        return wt;
    }

    public int getAt() {
        return at;
    }

    public int getCg() {
        return cg;
    }

    public double getCv() {
        return cv;
    }

    public int getIc() {
        return ic;
    }
}
