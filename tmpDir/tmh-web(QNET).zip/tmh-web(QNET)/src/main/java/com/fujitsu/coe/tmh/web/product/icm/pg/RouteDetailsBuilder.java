package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;
import com.fujitsu.coe.tmh.web.util.Location;
import java.sql.SQLException;
import java.util.Arrays;

/**
 *
 * @author kychua
 */
public class RouteDetailsBuilder {

    private static final String WALK = "WALK";
    private static final String ARRIVE = "ARRIVE";
    private ICMContext ctx;
    private int[] taxiWT;   // taxi waiting time matrix
    private Location userLocation;  // user location

    public RouteDetailsBuilder(ICMContext ctx, Location userLocation) throws SQLException {
        this.ctx = ctx;
        String taxiWTStr = ctx.settings.get(String.format("algo.taxi.wt.%d", ctx.user.getVenue()));
        this.taxiWT = Arrays.stream(taxiWTStr.split(" "))
                .mapToInt(wt -> Integer.parseInt(wt))
                .toArray();
        this.userLocation = userLocation;
    }

    public RouteDetails build(Route route) throws SQLException {
        for (Step step : route.getSteps()) {
            if (WALK.equals(step.getVehicleType())) {
                continue;
            } else if (ARRIVE.equals(step.getVehicleType())) {
                return new WalkRouteDetails(route); // whole route only had walk steps
            }
            Egress.Mode mode = Egress.Mode.valueOf(step.getVehicleType());
            if (mode == Egress.Mode.TAXI) {
                return new TaxiRouteDetails(ctx, route, userLocation, taxiWT);
            } else if (mode == Egress.Mode.BUS) {
                return new BusRouteDetails(ctx, route, mode, userLocation);
            } else if (mode == Egress.Mode.TRAIN) {
                return new TrainRouteDetails(ctx, route, mode, userLocation);
            }
        }
        throw new IllegalArgumentException();
    }

}
