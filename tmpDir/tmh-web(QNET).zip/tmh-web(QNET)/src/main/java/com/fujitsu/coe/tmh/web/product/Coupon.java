package com.fujitsu.coe.tmh.web.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fujitsu.coe.ss.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Coupon lite-model for Coupon Service.
 * 
 * @author ky
 */
@XmlRootElement
public class Coupon {
    private long id;
    private String shop;
    private String title;
    private String desc;
    private String address;
    private String location;
    private String mapHint;
    private String tel;
    private String terms;
    private Date expiry;
    private boolean redeemed;
    private boolean hasBanner;
    // server-side, used only during CS/CA
    private int edt;    // expected dwell time
    private String category;
    
    public Coupon(long id, String shop, String title, String desc, String address, String location, String mapHint, String tel, String terms, Date expiry, boolean redeemed, boolean hasBanner) {
        this(id, shop, title, desc, address, location, mapHint, tel, terms, expiry, redeemed, hasBanner, 0, null);
    }

    public Coupon(long id, String shop, String title, String desc, String address, String location, String mapHint, String tel, String terms, Date expiry, boolean redeemed, boolean hasBanner, int edt, String category) {
        this.id = id;
        this.shop = shop;
        this.title = title;
        this.desc = desc;
        this.address = address;
        this.location = location;
        this.mapHint = mapHint;
        this.tel = tel;
        this.terms = terms;
        this.expiry = expiry;
        this.redeemed = redeemed;
        this.hasBanner = hasBanner;
        this.edt = edt;
        this.category = category;
    }

    public long getId() {
        return id;
    }

    public String getShop() {
        return shop;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getAddress() {
        return address;
    }

    public String getLocation() {
        return location;
    }

    public String getMapHint() {
        return mapHint;
    }

    public String getTel() {
        return tel;
    }

    public String getTerms() {
        return terms;
    }

    public Date getExpiry() {
        return expiry;
    }

    public void setExpiry(Date expiry) {
        this.expiry = expiry;
    }

    public boolean isRedeemed() {
        return redeemed;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isBanner() {
        return hasBanner;
    }
    
    @JsonIgnore
    public int getEDT() {
        return edt;
    }
    
    @JsonIgnore
    public String getCategory() {
        return category;
    }
    
    @Override
    public Object clone() {
        return new Coupon(id, shop, title, desc, address, location, mapHint, tel, terms, expiry, redeemed, hasBanner, edt, category);
    }
}
