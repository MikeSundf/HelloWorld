CREATE TABLE route_cache
(
  id serial NOT NULL,
  created_time timestamp without time zone NOT NULL DEFAULT now(),
  from_location character varying(100),
  to_location character varying(100),
  response text,
  CONSTRAINT route_cache_pkey PRIMARY KEY (id)
);
