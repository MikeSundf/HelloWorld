CREATE TABLE shuttle_schedule
(
  id serial NOT NULL,
  route character varying(10),
  departure_time timestamp without time zone,
  CONSTRAINT shuttle_schedule_pkey PRIMARY KEY (id)
);
