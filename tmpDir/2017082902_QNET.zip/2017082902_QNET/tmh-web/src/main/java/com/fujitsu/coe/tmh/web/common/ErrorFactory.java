package com.fujitsu.coe.tmh.web.common;

import com.fujitsu.coe.tmh.web.AppException;
import java.util.Map;

/**
 * Lazy method to help generate errors.
 * 
 * @author ky
 */
public class ErrorFactory {

    public static Map<String, Object> createError(AppException e) {
        return createError(e.getCode(), e.getDescription(), e.getData());
    }
    
    public static Map<String, Object> createError(final int code, final String desc) {
        return createError(code, desc, null);
    }

    public static Map<String, Object> createError(final int code, final String desc, final Object data) {
        return MapBuilder.create("error", code)
                .put("desc", desc)
                .put("data", data)
                .build();
    }
}
