package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

/**
 * JSON model for root.taxi.is;
 * 
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDTaxiRouteDetail {
    private List<SDStep> journey;    // j
    private SDRouteTotal total;   // ti
    private List<SDTaxiFare> taxiFare;    // tf

    public void setTi(SDRouteTotal total) {
        this.total = total;
    }

    public void setTf(List<SDTaxiFare> taxiFare) {
        this.taxiFare = taxiFare;
    }

    public void setJ(List<SDStep> journey) {
        this.journey = journey;
    }

    public SDTaxiFare getTaxiFare(int index) {
        return taxiFare.get(index);
    }

    public SDRouteTotal getTotal() {
        return total;
    }
}
