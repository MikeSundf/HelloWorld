package com.fujitsu.coe.tmh.web.sim;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;
import javax.servlet.http.HttpServletRequest;

/**
 * Implementation of the LogLocation annotation.
 * 
 * @author ky
 */
@Interceptor
@VirtualTime
public class VirtualTimeInterceptor {

    private static final Logger LOGGER = Logger.getLogger(VirtualTimeInterceptor.class.getName());
    @Inject
    private HttpServletRequest request;
    @Inject
    private SysClock clock;

    @AroundInvoke
    public Object setVirtualTime(InvocationContext ctx) throws Exception {
        _setVirtualTime();
        return ctx.proceed();
    }
    
    private void _setVirtualTime() {
        String vTime = request.getHeader("X-Time");
        if (vTime == null) {
            return;
        }
        clock.setTime(Long.parseLong(vTime));
        LOGGER.log(Level.INFO, "Client changed time to {0}", String.valueOf(vTime));
    }
}
