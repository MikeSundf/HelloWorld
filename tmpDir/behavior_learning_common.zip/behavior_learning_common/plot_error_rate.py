﻿# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import numpy as np
import csv

# グラフ化に必要なものの準備
import matplotlib
import matplotlib.pyplot as plt

# データの扱いに必要なライブラリ
import pandas as pd
import numpy as np
import datetime as dt

from user_agent import UserAgent
from user_agent import BehaviorModelParam
from user_agent import RangeCount
from user_agent import Histogram

plt.style.use('ggplot') 
font = {'family' : 'meiryo'}
matplotlib.rc('font', **font)

def main():

    df = pd.read_csv( 'param_error_rate.csv' )
    print df
#    df.plot( y=BehaviorModelParam.coef_keys, figsize=(16,4), alpha=0.5)
    df.plot()  
#    plt.ylim([-1,1])
#    plt.legend(loc='best')
    plt.legend(bbox_to_anchor=(1.1, 1), loc='upper left', borderaxespad=0)
    plt.subplots_adjust(left = 0.1, right = 0.7)
    plt.show()

if __name__ == "__main__":
    
    main()
    
