﻿# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import numpy as np
import csv

# グラフ化に必要なものの準備
import matplotlib
import matplotlib.pyplot as plt

# データの扱いに必要なライブラリ
import pandas as pd
import numpy as np
import datetime as dt
import sys

from user_agent import UserAgent
from user_agent import BehaviorModelParam
from histogram import RangeCount
from histogram import Histogram

plt.style.use('ggplot') 
font = {'family' : 'meiryo'}
matplotlib.rc('font', **font)

def plot(filepath, title, size):
    print (filepath)
    df = pd.read_csv(filepath)
    print (df)
    if(size > 0):
        df = df.head(size)
#    df.plot( y=BehaviorModelParam.coef_keys, figsize=(16,4), alpha=0.5)
    df.plot()  
    plt.title(title)
    plt.ylim([-1,1])
#    plt.legend(loc='best')
    plt.legend(bbox_to_anchor=(1.1, 1), loc='upper left', borderaxespad=0)
    plt.subplots_adjust(left = 0.1, right = 0.7)
    plt.show()

def main():

    args = sys.argv
#    print args
#    print len(args)
    filepath = ""
    if len(args) > 1:
        filepath = args[1] + "/"
    filepath += "param_error_norm.csv"

    plot(filepath, "", 0)

if __name__ == "__main__":
    
    main()
    
