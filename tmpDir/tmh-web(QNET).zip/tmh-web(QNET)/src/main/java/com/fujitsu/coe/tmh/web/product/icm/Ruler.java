package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.tmh.web.util.Location;

/**
 * A ruler measures distance. http://yamadarake.jp/trdi/report000001.html
 *
 * @author unicenfujitsu
 */
public class Ruler {

    private static final double WGS84_A = 6378137.000;
    private static final double WGS84_E2 = 0.00669437999019758;
    private static final double WGS84_MNUM = 6335439.32729246;

    public static double distance(Location loc1, Location loc2) {
        return distance(loc1.getLat(), loc1.getLon(), loc2.getLat(), loc2.getLon());
    }
    
    // result in metres
    public static double distance(double lat1, double lng1, double lat2, double lng2) {
        double my = deg2rad((lat1 + lat2) / 2.0);
        double dy = deg2rad(lat1 - lat2);
        double dx = deg2rad(lng1 - lng2);

        double sin = Math.sin(my);
        double w = Math.sqrt(1.0 - WGS84_E2 * sin * sin);
        double m = WGS84_MNUM / (w * w * w);
        double n = WGS84_A / w;

        double dym = dy * m;
        double dxncos = dx * n * Math.cos(my);

        return Math.sqrt(dym * dym + dxncos * dxncos);
    }

    private static double deg2rad(double deg) {
        return deg * Math.PI / 180.0;
    }
}
