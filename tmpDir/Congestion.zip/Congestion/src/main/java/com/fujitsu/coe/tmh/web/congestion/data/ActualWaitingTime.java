/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.congestion.data;

/**
 *
 * @author fujitsu
 */
public class ActualWaitingTime {
    private String time_from;
    private String time_to;
    private int waitingtime;

    public String getTime_from() {
        return time_from;
    }

    public void setTime_from(String time_from) {
        this.time_from = time_from;
    }

    public String getTime_to() {
        return time_to;
    }

    public void setTime_to(String time_to) {
        this.time_to = time_to;
    }

    public int getWaitingtime() {
        return waitingtime;
    }

    public void setWaitingtime(int waitingtime) {
        this.waitingtime = waitingtime;
    }
    
    public ActualWaitingTime(String from, String to, int waittime){
        this.time_from=from;
        this.time_to=to;
        this.waitingtime=waittime;
    }
}
