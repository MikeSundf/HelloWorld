SELECT pc.id, s.name, c.title, c.description, s.address, s.location, s.map_hint, s.tel, c.terms, pc.expiry_time, 
(pc.redemption_time IS NOT NULL) AS redeemed, (sl.id IS NOT NULL) AS has_banner
FROM product_coupon pc 
INNER JOIN coupon c ON pc.coupon_id=c.coupon_id 
INNER JOIN shop s ON c.shop_id=shop.id 
LEFT JOIN shop_logo sl ON c.coupon_id=sl.id AND sl.type='COUPON'
WHERE product_id=? 
ORDER BY pc.seq