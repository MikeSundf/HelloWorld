package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * JSON model for root.taxi;
 *
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDTaxiRoute {

    private SDTaxiRouteDetail detail;   // is

    public void setIs(SDTaxiRouteDetail detail) {
        this.detail = detail;
    }

    public SDTaxiRouteDetail getDetail() {
        return detail;
    }
}
