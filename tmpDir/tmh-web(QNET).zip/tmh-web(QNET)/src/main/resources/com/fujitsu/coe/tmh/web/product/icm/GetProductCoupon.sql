SELECT pc.id, pc.seq, c.id, s.name, c.title, c.description, s.address, s.location, s.map_hint, s.tel, c.terms, pc.expiry_time, pc.redemption_time, (sl.id IS NOT NULL) AS has_banner 
FROM product_coupon pc
INNER JOIN coupon c ON pc.coupon_id=c.id
INNER JOIN shop s ON c.shop_id=s.id 
LEFT JOIN shop_logo sl ON c.id=sl.id AND sl.type='COUPON'
WHERE pc.product_id=?
ORDER BY pc.product_id, pc.seq