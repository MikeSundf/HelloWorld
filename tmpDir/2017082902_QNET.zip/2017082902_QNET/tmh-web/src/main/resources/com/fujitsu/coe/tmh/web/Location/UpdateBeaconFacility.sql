UPDATE beacon_facility
SET facility_id=?
WHERE beacon_id=? AND facility_type =?