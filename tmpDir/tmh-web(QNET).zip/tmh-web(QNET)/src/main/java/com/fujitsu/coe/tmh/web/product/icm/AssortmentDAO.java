package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.ss.util.Date;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.*;
import com.fujitsu.coe.tmh.web.product.Coupon;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.EgressStep;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.sim.SysClock;
import com.fujitsu.coe.tmh.web.user.User;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;

/**
 *
 * @author unicenfujitsu
 */
public class AssortmentDAO {

    @Inject
    private User user;
    @Inject
    private JdbcTemplate db;
    @Inject
    private SysClock clock;
    @Inject
    @ClasspathResource("InsertProduct.sql")
    private String sqlInsertProduct;
    @Inject
    @ClasspathResource("GetRecentAssortment.sql")
    private String sqlGetRecentAssortment;
    @Inject
    @ClasspathResource("GetProductCoupon.sql")
    private String sqlGetProductCoupon;

    public void saveAssortment(String requestId, List<Product> products) throws SQLException {
        Timestamp now = toTS(clock.now());
        db.update("INSERT INTO assortment(user_id, venue_id, request_id, created_time) VALUES(?, ?, ?, ?)", user.getId(), user.getVenue(), requestId, now);
        long aId = db.queryForLong("SELECT LASTVAL()");
        int pSeq = 1;
        for (Product product : products) {
            Egress egress = product.getEgress();
            db.update(sqlInsertProduct,
                    aId, pSeq, egress.getMode().toString(), egress.getCongestion(), egress.getFare(), now,
                    product.getDt(), product.getAt(), product.getWt(), product.getTt(), 
                    toTS(product.getEgress().getDep()), toTS(product.getEgress().getArr()));
            long pId = db.queryForLong("SELECT LASTVAL()");
            product.setId(pId);

            int sSeq = 1;
            for (EgressStep step : egress.getSteps()) {
                db.update("INSERT INTO product_egress(product_id, step, mode, duration, wait_duration, action, service, location, details, lat, lon) "
                        + "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        pId, sSeq, step.getMode(), step.getTime(), step.getWaitTime(), null, step.getService(), step.getLocation(), step.getDetails(), step.getLat(), step.getLon());
                sSeq++;
            }

            int cSeq = 1;
            for (Coupon coupon : product.getCoupons()) {
                db.update("INSERT INTO product_coupon(product_id, coupon_id, seq, expiry_time) VALUES(?, ?, ?, ?)",
                        pId, coupon.getId(), cSeq, toTS(coupon.getExpiry()));
                long cId = db.queryForLong("SELECT LASTVAL()");
                coupon.setId(cId);
                cSeq++;
            }
            
            // tag FMOD products
            new FmodDAO(db).tag(requestId, product, pId);
            
            pSeq++;
        }
    }
    
    public List<Product> getRecentAssortment(String from, String to, int seats, int mins) throws SQLException {
        List<Long> recent = db.query(String.format(sqlGetRecentAssortment, mins), (rs) -> {
            return rs.getLong("id");
        }, user.getId(), user.getVenue(), from, to, seats);
        
        if (recent.isEmpty()) {
            return null;
        }
        
        Map<Long, Product> pMap = new HashMap<>();
        List<Product> products = db.query("SELECT * FROM product WHERE assortment_id=? ORDER BY seq", (rs) -> {
            long id = rs.getLong("id");
            Product product = new Product(id, 
                    new Egress(Egress.Mode.valueOf(rs.getString("egress_mode")), rs.getInt("congestion"), rs.getDouble("cost"), 
                            new Date(rs.getTimestamp("created_time").getTime() + toMS(rs.getLong("dwell_duration")))), 
                    fromTS(rs.getTimestamp("created_time")));
            product.getEgress().setTime(fromTS(rs.getTimestamp("dep_time")), fromTS(rs.getTimestamp("arr_time")));
            product.setDt(rs.getInt("dwell_duration"));
            product.setAt(rs.getInt("access_duration"));
            product.setWt(rs.getInt("waiting_duration"));
            product.setTt(rs.getInt("travel_duration"));
            pMap.put(id, product);
            return product;
        }, recent.get(0));
        
        db.query("SELECT * FROM product_egress WHERE product_id IN (SELECT id FROM product WHERE assortment_id=?) ORDER BY product_id, step", (rs) -> {
            Product product = pMap.get(rs.getLong("product_id"));
            product.getEgress().addStep(rs.getInt("step"), rs.getString("mode"), 
                    rs.getString("service"), rs.getString("location"), rs.getString("details"), 
                    rs.getLong("duration"), rs.getLong("wait_duration"), 
                    rs.getDouble("lat"), rs.getDouble("lon"));
        }, recent.get(0));

        for (Product product: products) {
            product.setCoupons(db.query(sqlGetProductCoupon, (rs) -> {
                return new Coupon(rs.getLong("id"), rs.getString("name"), rs.getString("title"), 
                        rs.getString("description"), rs.getString("address"), rs.getString("location"), 
                        rs.getString("map_hint"), 
                        rs.getString("tel"), rs.getString("terms"), fromTS(rs.getTimestamp("expiry_time")), 
                        rs.getTimestamp("redemption_time") != null, rs.getBoolean("has_banner"));
            }, product.getId()));
        }
        
        return products;
    }
}
