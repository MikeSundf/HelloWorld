UPDATE coupon 
SET
  title = ?
  , description = ?
  , terms = ?
  , remarks = ?
  , max_available = ?
  , money_level = ?
  , coupon_value = ?
  , enable_flag = ?
WHERE
  coupon_id = ?