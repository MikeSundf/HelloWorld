package com.fujitsu.coe.tmh.web.product.icm.cs;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.pg.PGUtil;
import com.fujitsu.coe.tmh.web.user.AuthService;
import com.fujitsu.coe.tmh.web.util.LogManage;
import com.fujitsu.coe.tmh.web.util.LogManage_r2;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.io.IOException;
import java.sql.SQLException;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.*;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import javax.inject.Inject;
import static jdk.nashorn.internal.objects.NativeArray.map;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;

/**
 *
 * @author kychua
 */
public class CSAlgoGateway {
    
    private static final String[] PREFS = new String[] {"beauty","dining","electronics","fashion","grocery","lifestyle","maternity","sport","sportswear","travel"};
    private static final TypeReference<int[]> ARRAY_TYPE = new TypeReference<int[]>() {
    };
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private ICMContext ctx;
    
    public CSAlgoGateway(ICMContext ctx) {
        this.ctx = ctx;
    }
    
    public boolean learn(Date start, Date end) throws SQLException, IOException {
        Map<String, Object> data = new HashMap<>();
        data.put("range", new Long[] { start.getTime(), end.getTime() });
        // should have been a proper data structure, but you know, projects always have constraints
        List<Map<String, Object>> users = new ArrayList<>();
        data.put("users", users);
        
        // pick up coupon interactions between date range
        ctx.db.query(ctx.getResource(this, "CSLCoupons.sql"), (ResultSet rs) -> {
            Map<String, Object> user = users.isEmpty() ? new HashMap<>() : users.get(users.size() - 1);
            Long userId = rs.getLong("user_id");
            if (!userId.equals(user.get("id"))) {
                user = new HashMap<>();
                user.put("id", userId);
                user.put("coupons", new ArrayList<>());
                users.add(user);
            }
            
            List<int[]> coupons = (List<int[]>)user.get("coupons");
            coupons.add(new int[] {rs.getInt("coupon_id"), rs.getInt("chosen"), rs.getInt("viewed"), rs.getInt("recommended") });
        }, toTS(start), toTS(end), toTS(start), toTS(end));
        
        // pick up latest user profile
        for (Map<String, Object> user : users) {
            ctx.db.query(ctx.getResource(this, "CSLUser.sql"), (rs) -> {
                int[] prefs = new int[PREFS.length];
                for (int i=0;i<PREFS.length;i++) {
                    prefs[i] = rs.getBoolean(PREFS[i]) ? 1 : 0;
                }
                user.put("profile", MapBuilder.create("gender", rs.getString("gender"))
                        .put("income", rs.getInt("income_group"))
                        .put("income", rs.getInt("age_group"))
                        .put("prefs", prefs)
                        .build());
            }, user.get("id"));
        }
        
        // send it to CSL
        String endpoint = ctx.settings.get("cs.r.endpoint", "http://localhost/cs/l");
        String response = Request.Post(endpoint)
            .connectTimeout(10000)
            .socketTimeout(20000)
            .bodyString(MAPPER.writeValueAsString(data), ContentType.APPLICATION_JSON)
            .execute().returnContent().asString();

        // if response OK, update last-update-date
        if (response.equals("true")) {
            ctx.db.update("UPDATE system_settings SET setting_value=? WHERE setting_key=?", toTS(end), "cs.l.last");
        }
        return true;
    }
    
    public boolean learnCSL(Date start, Date end, LogManage logger) throws SQLException, IOException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String classname = AuthService.class.getName();

        logger.log(Level.FINE, classname, methodName, "START");

        Map<String, Object> data = new HashMap<>();
        data.put("range", new Long[]{start.getTime(), end.getTime()});
        // should have been a proper data structure, but you know, projects always have constraints
        List<Map<String, Object>> users = new ArrayList<>();
        data.put("users", users);

        logger.log(Level.FINE, classname, methodName, "SQL[" + ctx.getResource(this, "CSLCoupons_v2.sql") + "] Param[" + toTS(start) + "," + toTS(end) + "]");

        ctx.db.query(ctx.getResource(this, "CSLCoupons_v2.sql"), (ResultSet rs) -> {
            Map<String, Object> user = users.isEmpty() ? new HashMap<>() : users.get(users.size() - 1);
            String userId = rs.getString("user_id");
            if (!userId.equals(user.get("id"))) {
                user = new HashMap<>();
                user.put("id", userId);
                user.put("coupons", new ArrayList<>());
                users.add(user);
            }

            List<int[]> coupons = (List<int[]>) user.get("coupons");
            coupons.add(new int[]{rs.getInt("coupon_id"), rs.getInt("chosen"), rs.getInt("viewed"), rs.getInt("recommended")});
        }, toTS(start), toTS(end));

        // pick up latest user profile
        for (Map<String, Object> user : users) {
            List<String> pref_key = new ArrayList<>();
            List<Integer> pref_value = new ArrayList<>();
            String[] gender = new String[1];
            int[] age = new int[1];
            int[] income = new int[1];
            logger.log(Level.FINER, classname, methodName, "SQL[" + ctx.getResource(this, "CSLUser_v2.sql") + "] Param[" + user.get("id") + "]");
            ctx.db.query(ctx.getResource(this, "CSLUser_v2.sql"), (rs) -> {

                gender[0] = rs.getString("gender");
                income[0] = rs.getInt("age_group");
                age[0] = rs.getInt("income_group");

                pref_key.add(rs.getString("pref_key"));
                int value = (rs.getBoolean("pref_value") ? 1 : 0);
                pref_value.add(value);

            }, user.get("id"));
            user.put("profile", MapBuilder.create("gender", gender[0])
                    .put("income", income[0])
                    .put("income", age[0])
                    .put("category", pref_key)
                    .put("prefs", pref_value)
                    .build());
        }

        boolean result = false;
        // send it to CSL
        String endpoint = ctx.settings.get("cs.r.endpoint", "http://localhost/cs/l");
        try {
            if (logger.settinglogLevel > 4) {
                // 変換
                ObjectMapper objectMapper = new ObjectMapper();
                String json = objectMapper.writeValueAsString(data);
                logger.log(Level.FINE, classname, methodName, "Send to AI, [endpoint:" + endpoint + "] [Param:" + json + "]");
            }
            logger.log(Level.FINE, classname, methodName, "Send to AI, [endpoint:" + endpoint + "] ");

            String response = Request.Post(endpoint)
                    .connectTimeout(10000)
                    .socketTimeout(20000)
                    .bodyString(MAPPER.writeValueAsString(data), ContentType.APPLICATION_JSON)
                    .execute().returnContent().asString();

            // if response OK, update last-update-date
            if (response.equals("true")) {
                ctx.db.update("UPDATE system_settings SET setting_value=? WHERE setting_key=?", toTS(end), "cs.l.last");
            }
        } catch (Exception e) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "AI response Error.", e);
            result = false;
        }

        logger.log(Level.FINE, classname, methodName, "AI response :" + result + ".");
        logger.log(Level.FINE, classname, methodName, "END");
        return result;
    }

    // query CSR for coupons
    //public int[] recommend(long userId) throws SQLException, IOException {
    public int[] recommend(String userId, Float lat, Float lon, String date, LogManage logger) throws SQLException, IOException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String classname = AuthService.class.getName();

        logger.log(Level.FINE, classname, methodName, "START");

//        String endpoint = ctx.settings.get("cs.r.endpoint", "http://localhost/cs/r?id=%s&lat=%f&lon=%f&date=%s");
//        date = URLEncoder.encode(date, "UTF-8");
//        endpoint = String.format(endpoint, userId, lat, lon, date);
//
//        logger.log(Level.FINE, classname, methodName, "Send to AI, [endpoint:" + endpoint + "] ");
//
//        String response = "";
//        try {//@TODO　パスを調べめE
//            response = PGUtil.curl(endpoint);
//        } catch (Exception e) {
//            logger.thrownLog(Level.SEVERE, classname, methodName, "AI response Error.", e);
//        }
//        int[] coupons = MAPPER.readValue(response, ARRAY_TYPE);
        int[] coupons = MAPPER.readValue("[1,2,3]", ARRAY_TYPE);


        logger.log(Level.FINE, classname, methodName, "AI response :[" + coupons.toString() + "].");
        logger.log(Level.FINE, classname, methodName, "END");
        return coupons;
    }
    
}
