package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.Ruler;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;
import com.fujitsu.coe.tmh.web.util.Location;
import java.sql.SQLException;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toHHMM;

/**
 *
 * @author kychua
 */
class TaxiRouteDetails extends AbstractRouteDetails {

    private int[] wt;

    public TaxiRouteDetails(ICMContext ctx, Route route, Location userLocation, int[] wt) throws SQLException {
        super(ctx, route, Egress.Mode.TAXI);
        this.wt = wt;

        // assumptions - first step always walk, 2nd step always the taxi
        Step firstWalk = route.getSteps().get(0);
        Step firstTaxi = route.getSteps().get(1);

        // rewrite first mile access
        // TODO since user location doesn't change for a request, nearest taxi stand is re-calculated more times than necessary
        final TaxiStand[] nearest = new TaxiStand[1];
        final double[] minDist = new double[]{Double.MAX_VALUE};
        ctx.db.query("SELECT id, name, lat, lon FROM taxi_stand WHERE venue_id=?", (rs) -> {
            double distance = Ruler.distance(userLocation.getLat(), userLocation.getLon(), rs.getDouble(3), rs.getDouble(4));
            if (distance < minDist[0]) {
                nearest[0] = new TaxiStand(rs.getString(2), new Location(rs.getDouble(3), rs.getDouble(4)));
                minDist[0] = distance;
            }
        }, ctx.user.getVenue());
        firstWalk.setTime(PGUtil.getAccessTime(userLocation, nearest[0].location));
        String location = "Taxi stand " + nearest[0].description;
        firstWalk.setLocation(userLocation.getLat(), userLocation.getLon());
        firstWalk.setInstruction(location, null, null);
        firstTaxi.setLocation(nearest[0].location.getLat(), nearest[0].location.getLon());
        firstTaxi.setInstruction(firstTaxi.getLocation(), location, null);

        init();
    }

    @Override
    public double getWaitingTime(long stepTime, Step step) {
        if ("TAXI".equals(step.getVehicleType())) {
            int hhmm = toHHMM(new Date(stepTime));
            return wt[hhmm / 100];
        } else {
            return 0;
        }
    }

    private class TaxiStand {

        final String description;
        final Location location;

        public TaxiStand(String description, Location location) {
            this.description = description;
            this.location = location;
        }
    }
}
