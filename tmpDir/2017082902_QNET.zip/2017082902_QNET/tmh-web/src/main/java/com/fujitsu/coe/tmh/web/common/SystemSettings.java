package com.fujitsu.coe.tmh.web.common;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import java.sql.SQLException;
import javax.inject.Inject;

/**
 *
 * @author unicenfujitsu
 */
public class SystemSettings {

    @Inject
    private JdbcTemplate db;

    public String get(String key) throws SQLException {
        return db.queryForString("SELECT setting_value FROM system_settings WHERE setting_key=?", key);
    }
    
    public String get(String key, String def) throws SQLException {
        String val = get(key);
        return (val == null) ? def : val;
    }
}
