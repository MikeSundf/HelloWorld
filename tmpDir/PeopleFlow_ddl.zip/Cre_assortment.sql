CREATE TABLE assortment
(
  id serial NOT NULL,
  user_id character varying(45) NOT NULL,
  venue_id integer NOT NULL,
  created_time timestamp without time zone NOT NULL DEFAULT now(),
  selected_product integer,
  selected_time timestamp without time zone,
  request_id character varying(86) NOT NULL,
  CONSTRAINT assortment_pkey PRIMARY KEY (id),
  CONSTRAINT "requestFK" FOREIGN KEY (request_id)
      REFERENCES request (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "userInfoFK" FOREIGN KEY (user_id)
      REFERENCES user_info (user_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "venueFK" FOREIGN KEY (venue_id)
      REFERENCES venue (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
