INSERT 
INTO coupon_logo(coupon_id, logo) 
VALUES (?, ?)
