package com.fujitsu.coe.tmh.web.common;

import com.fujitsu.coe.ss.util.Date;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import javax.enterprise.context.ApplicationScoped;

/**
 *
 * @author unicenfujitsu
 */
@ApplicationScoped
public class SysClock {

    public enum Mode {

        SERVER, SIM
    }

    private final Mode mode;
    private Clock clock;

    public SysClock() {
        String modeStr = System.getProperty("mode");
        if (modeStr == null) {
            modeStr = Mode.SERVER.name();
        }
        this.mode = Mode.valueOf(modeStr.toUpperCase());
        clock = Clock.systemDefaultZone();
    }

    public void setTime(long time) {
        if (mode == Mode.SERVER) {
            throw new IllegalStateException("Cannot set time in server mode.");
        }

        if (time <= 0) {
            clock = Clock.systemDefaultZone();
            return;
        }
        
        clock = Clock.fixed(Instant.ofEpochMilli(time), ZoneId.systemDefault());
    }

    public Mode getMode() {
        return mode;
    }
    
    public Date now() {
        return new Date(clock.instant().toEpochMilli());
    }
}
