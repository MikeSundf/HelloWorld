SELECT sl.logo FROM shop_logo sl
INNER JOIN shop s ON sl.id=s.id AND sl.type='SHOP'
INNER JOIN coupon c ON s.id=c.shop_id
INNER JOIN product_coupon pc ON pc.coupon_id=c.id
INNER JOIN product p ON pc.product_id=p.id 
INNER JOIN assortment a ON a.id=p.assortment_id 
WHERE pc.id=? AND a.user_id=?