package com.fujitsu.coe.tmh.web.util;

import com.fujitsu.coe.ss.util.Date;

/**
 * Nothing much, just a holder for a mutable date.
 *
 * @author chuakayick
 */
public class MutableDate {

    private Date date;

    public MutableDate() {
        this(new Date());
    }
    
    public MutableDate(Date date) {
        this.date = date;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

}
