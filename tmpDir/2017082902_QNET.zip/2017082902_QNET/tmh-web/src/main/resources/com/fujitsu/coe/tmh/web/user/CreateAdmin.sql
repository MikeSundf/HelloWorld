INSERT INTO authority_info(
            user_id, type, manage_id)
    VALUES (?, ?, ?);
