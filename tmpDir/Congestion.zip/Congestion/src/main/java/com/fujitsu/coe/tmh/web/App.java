package com.fujitsu.coe.tmh.web;

import java.util.Set;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * JAX-RS application root.
 * 
 * @author ky
 */
@ApplicationPath("/")
public class App extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        try {
            // https://java.net/jira/browse/GLASSFISH-21141
            resources.add(Class.forName("org.glassfish.jersey.jackson.JacksonFeature"));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(com.fujitsu.coe.tmh.web.AppExceptionHandler.class);
        resources.add(com.fujitsu.coe.tmh.web.ForbiddenExceptionHandler.class);
        resources.add(com.fujitsu.coe.tmh.web.congestion.CongestionService.class);
        resources.add(com.fujitsu.coe.tmh.web.congestion.CrowdingService.class);
        resources.add(com.fujitsu.coe.tmh.web.congestion.TimeSlotService.class);
        resources.add(com.fujitsu.coe.tmh.web.congestion.WaitingTimeService.class);
    }
    
}
