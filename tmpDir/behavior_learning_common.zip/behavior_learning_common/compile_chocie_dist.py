# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import psycopg2
import psycopg2.extras
import sys
import numpy as np
import pandas as pd
import random
import math
import os.path
import copy
import pandas as pd
import csv

def main():

    args = sys.argv

    skew_list = []

    for j in range(2):
        path2 = "/fixed"
        f = [None, None, None, None]
        if j == 1:
            path2 = "/random"
            f[0] = open('skew_random.csv', 'w')
            f[1] = open('choice_dist_dt_random.csv', 'w')
            f[2] = open('choice_dist_cg_random.csv', 'w')
            f[3] = open('choice_dist_ic_random.csv', 'w')
        else:
            f[0] = open('skew_fixed.csv', 'w')
            f[1] = open('choice_dist_dt_fixed.csv', 'w')
            f[2] = open('choice_dist_cg_fixed.csv', 'w')
            f[3] = open('choice_dist_ic_fixed.csv', 'w')

        for i in range(100):
            user_id = "user_%d" % (i)
            path1 = "algo4/" + user_id
            if (os.path.exists(path1) == False):
                print("no directory: %s" %path1)
                break

            path = path1 + path2

            print(path)
            if (os.path.exists(path) == False):
                continue

            for k in range(4):

                filepath = ""
                if(k == 0):
                    filepath = path + "/skew/skew.csv"
                elif(k == 1):
                    filepath = path + "/choice/choice_dist_DT.csv"
                elif(k == 2):
                    filepath = path + "/choice/choice_dist_CG.csv"
                elif (k == 3):
                    filepath = path + "/choice/choice_dist_IC.csv"

                print(filepath)
                csvWriter = csv.writer(f[k], lineterminator='\n')

                df = pd.read_csv(filepath)

#                print(df)

                if(i == 0):
                    row = list(df.columns)
                    csvWriter.writerow(row)

#                tail = df.tail(1)

                test = df.ix[(len(df) -1):]

                row = list(test.values.flatten())

                row.insert(0, user_id)
                csvWriter.writerow(row)

        #                csvWriter.writerow(listData)

        for i in range(4):
            f[i].close()

        #    print(skew_list)

    print("finished!")



if __name__ == "__main__":
    main()

