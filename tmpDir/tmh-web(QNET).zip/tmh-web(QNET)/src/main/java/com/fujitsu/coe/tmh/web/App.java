package com.fujitsu.coe.tmh.web;

import java.util.Set;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * JAX-RS application root.
 * 
 * @author ky
 */
@ApplicationPath("v1")
public class App extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        try {
            // https://java.net/jira/browse/GLASSFISH-21141
            resources.add(Class.forName("org.glassfish.jersey.jackson.JacksonFeature"));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(com.fujitsu.coe.tmh.web.AppExceptionHandler.class);
        resources.add(com.fujitsu.coe.tmh.web.CheckService.class);
        resources.add(com.fujitsu.coe.tmh.web.ForbiddenExceptionHandler.class);
        resources.add(com.fujitsu.coe.tmh.web.product.CouponService.class);
        resources.add(com.fujitsu.coe.tmh.web.product.LaunchService.class);
        resources.add(com.fujitsu.coe.tmh.web.product.ProductService.class);
        resources.add(com.fujitsu.coe.tmh.web.product.RouteService.class);
        resources.add(com.fujitsu.coe.tmh.web.shop.ShopService.class);
        resources.add(com.fujitsu.coe.tmh.web.surveyor.SurveyorService.class);
        resources.add(com.fujitsu.coe.tmh.web.user.AuthService.class);
        resources.add(com.fujitsu.coe.tmh.web.user.PasswordService.class);
        resources.add(com.fujitsu.coe.tmh.web.user.ProfileService.class);
        resources.add(com.fujitsu.coe.tmh.web.user.RegisterService.class);
        resources.add(com.fujitsu.coe.tmh.web.user.TrackingService.class);
        resources.add(com.fujitsu.coe.tmh.web.venue.VenueService.class);
    }
    
}
