/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.util;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

/**
 *
 * @author qnet8733
 */
public class IdExistCheck {

    @Inject
    private JdbcTemplate db;

    /**
     * ユーザIDチェック
     */
    public boolean validateUserId(String user_id) throws SQLException {
        // ユーザIDの指定がない場合はエラー
        if (user_id == null || user_id.isEmpty()) {
            return false;
        }
        // ユーザIDがDBに存在すれば正常(true)、存在しなければエラー(false)をリターン
        int count = getRecordCount("user_info", "user_id", user_id, null);
        return count > 0;
    }

    /**
     * 開催地IDチェック
     */
    public boolean validateaVenueId(Integer venue_id) throws SQLException {
        //開催地IDが null の場合はエラー(1001：パラメタ不正)
        if (venue_id == null) {
            return false;
        }
        // 開催地IDがDBに存在すれば正常(true)、存在しなければエラー(false)をリターン
        int count = getRecordCount("venue", "venue_id", venue_id,
                " AND enable_flag=".concat(
                        Boolean.toString(ParamConstants.ENABLE_FLAG)));
        return count > 0;
    }

    /**
     * 店舗IDチェック
     */
    public boolean validateShopId(Integer shop_id) throws SQLException {
        //店舗IDが null の場合はエラー
        if (shop_id == null) {
            return false;
        }
        // 店舗IDがDBに存在すれば正常(true)、存在しなければエラー(false)をリターン
        int count = getRecordCount("shop", "shop_id", shop_id,
                " AND enable_flag=".concat(
                        Boolean.toString(ParamConstants.ENABLE_FLAG)));
        return count > 0;
    }

    /**
     * クーポンIDチェック
     */
    public boolean validateCouponId(Long coupon_id) throws SQLException {
        //クーポンIDが null の場合はエラー
        if (coupon_id == null) {
            return false;
        }
        // クーポンIDがDBに存在すれば正常(true)、存在しなければエラー(false)をリターン
        int count = getRecordCount("coupon", "coupon_id", coupon_id,
                " AND enable_flag=".concat(
                        Boolean.toString(ParamConstants.ENABLE_FLAG)));
        return count > 0;
    }

    /**
     * DBレコード数取得
     */
    public int getRecordCount(String table, String column, Object value, String opt_cond) throws SQLException {
        // SQL文を作成(付加条件パラメタ(opt_cond)があれば付加)
        StringBuilder buf = new StringBuilder();
        buf.append("SELECT COUNT(*) FROM ");
        buf.append(table);
        buf.append(" WHERE ");
        buf.append(column);
        buf.append("=?");
        if (opt_cond != null) {
            buf.append(" ");
            buf.append(opt_cond);
        }
        String sql = buf.toString();
        // DB検索結果レコード数を取得
        final List<Integer> counts = new ArrayList<>();
        db.query(sql, (rs) -> {
            counts.add(rs.getInt(1));
        }, value);
        // レコード件数をリターン
        return counts.get(0);
    }
    
    /**
     * DBレコード数取得 条件なし
     */
    public int getRecordCountAll(String table, String opt_cond) throws SQLException {
        // SQL文を作成(付加条件パラメタ(opt_cond)があれば付加)
        StringBuilder buf = new StringBuilder();
        buf.append("SELECT COUNT(*) FROM ");
        buf.append(table);
        if (opt_cond != null) {
            buf.append(" ");
            buf.append(opt_cond);
        }
        String sql = buf.toString();
        // DB検索結果レコード数を取得
        final List<Integer> counts = new ArrayList<>();
        db.query(sql, (rs) -> {
            counts.add(rs.getInt(1));
        });
        // レコード件数をリターン
        return counts.get(0);
    }
}
