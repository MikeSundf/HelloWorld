INSERT INTO beacon_facility(beacon_id, facility_type, facility_id)
VALUES (?, ?, ?)