
package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fujitsu.coe.tmh.web.product.route.Step;

/**
 *
 * @author kychua
 */
public class ICMStep implements Step {
    private String mode;
    private double tt;
    
    private double lat;
    private double lon;
    
    public String service;
    public String location;
    public String details;
    
    // Used to represent final alighting point
    public ICMStep(String mode, double lat, double lon) {
        this(mode, lat, lon, 0);
    }
    
    public ICMStep(String mode, double lat, double lon, double tt) {
        this.mode = mode;
        this.lat = lat;
        this.lon = lon;
        this.tt = tt;
    }
    
    @Override
    public void setInstruction(String service, String location, String details) {
        this.service = service;
        this.location = location;
        this.details = details;
    }

    @Override
    public String getVehicleType() {
        return mode;
    }

    @Override
    public String getService() {
        return service;
    }

    @Override
    public String getLocation() {
        return location;
    }

    @Override
    public String getDetails() {
        return details;
    }

    @Override
    public double getTime() {
        return tt;
    }

    @Override
    public double getLat() {
        return lat;
    }

    @Override
    public double getLon() {
        return lon;
    }

    @Override
    public void setTime(double time) {
        this.tt = time;
    }

    @Override
    public void setLocation(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
    }
}
