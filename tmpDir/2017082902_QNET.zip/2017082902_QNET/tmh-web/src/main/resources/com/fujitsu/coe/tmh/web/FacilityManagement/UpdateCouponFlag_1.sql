UPDATE coupon 
SET
  enable_flag = ?
WHERE
  shop_id = 
