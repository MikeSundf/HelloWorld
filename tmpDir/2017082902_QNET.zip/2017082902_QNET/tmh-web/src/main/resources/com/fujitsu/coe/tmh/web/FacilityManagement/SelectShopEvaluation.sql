SELECT
  user_id
  , shop_id
  , value
  , time
FROM
  shop_evaluation 
WHERE
  shop_id = ? 
ORDER BY
  user_id, time;