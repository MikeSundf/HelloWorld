package com.fujitsu.coe.tmh.web.congestion;




import com.fujitsu.coe.tmh.web.congestion.data.TimeSlot;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.user.ActionLogger;
import com.fujitsu.coe.tmh.web.util.AdminType;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.IdExistCheck;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.fujitsu.coe.tmh.web.util.LogManage;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.fromTS;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toTS;
//import com.fujitsu.coe.tmh.web.util.LogManage_r2;
import com.fujitsu.coe.tmh.web.util.ValidationCheck;
import javax.ws.rs.FormParam;

/**
 * Services related to the congestion service .
 *
 * @author sun
 */
@Path("/")
@ApplicationScoped
public class TimeSlotService {

    String classname = TimeSlotService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    private AdminType adminUtil;
    @Inject
    private LogManage logger;
    @Inject
    private IdExistCheck idExist;
    @Inject
    private ActionLogger aLogger;
    
    /**
     * createTimeSlot
     *
     * @param adminuser
     * @param str_facility_id
     * @param facility_type
     * @param date_from
     * @param date_to
     * @param str_interval
     * @return status
     * @auther Sun
     */
    @POST
    @Path("/createTimeSlot")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map<String, Object> createTimeSlot(
            @FormParam("admin_id") String adminuser,
            @FormParam("facility_type") String facility_type,
            @FormParam("facility_id") String str_facility_id,
            @FormParam("date_from") String date_from,
            @FormParam("date_to") String date_to,
            @FormParam("interval") String str_interval
    ) throws SQLException  {
        aLogger.log(adminuser, "CREATE_TIMESLOT", null, 
                String.format("[admin_id=%s] [facility_type=%s] [facility_id=%s] "
                        + "[date_from=%s] [date_to=%s] [interval=%s] ", 
                        adminuser,facility_type,str_facility_id,date_from,date_to,
                        str_interval));
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + adminuser + ", "
                + "facility_type=" + facility_type + ", "
                + "facility_id=" + str_facility_id + ", "        
                + "date_from=" + date_from + ", "
                + "date_to=" + date_to + ", "        
                + "interval=" + str_interval + "]");

        // 必須パラメータチェック
        if (adminuser == null || adminuser.equals("") || facility_type == null || facility_type.equals("")
                || str_facility_id == null || date_from == null ||date_from.equals("") 
                || date_to == null || date_to.equals("") || str_facility_id == null || str_facility_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(adminuser))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        int facility_id,interval = 0;
        
        try{
            facility_id = Integer.parseInt(str_facility_id);
            interval = Integer.parseInt(str_interval);
        }catch(NumberFormatException e){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);            
        }
        
        if (1440 % interval != 0) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date dateFrom,dateTo; //to use some method in java.util.date, set it as Date first.
        try {
            dateFrom = sdf.parse(date_from + " 00:00:00");
            dateTo = sdf.parse(date_to + " 23:59:59");
        } catch (ParseException ex) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        if (dateFrom.after(dateTo)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(adminuser) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
            /**
             * 権限チェック　
             */
            int auth = adminUtil.getUserType(adminuser);
            if (auth <= USER_INFO_TYPE_USER) { //any operator?
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        java.util.Date tmpDate = dateFrom;
        
        while(tmpDate.before(dateTo)){
            try {
                Date time_slot_from = new Date(tmpDate);
                Date time_slot_to = new Date(time_slot_from.getTime() + interval*60*1000-1000);
                db.update("INSERT INTO time_slot (facility_type, facility_id, start_time, end_time) VALUES (?,?,?,?)",
                        facility_type,facility_id,toTS(time_slot_from),toTS(time_slot_to));
                tmpDate = new java.util.Date(tmpDate.getTime()+ interval*60*1000);
            } catch (SQLException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB Insert error.", ex);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
        }

        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }
    
        /**
     * getInterval
     *
     * @param adminuser
     * @param facility_type
     * @param str_facility_id
     * @param date_from
     * @param date_to
     * @return interval Information
     * @auther Sun
     */
    @GET
    @Path("/getInterval")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> getInterval(
            @QueryParam("admin_id") String adminuser,
            @QueryParam("facility_type") String facility_type,
            @QueryParam("facility_id") String str_facility_id,
            @QueryParam("date_from") String date_from,
            @QueryParam("date_to") String date_to
    ) throws SQLException  {
        aLogger.log(adminuser, "GET_INTERVAL", null, 
                String.format("[admin_id=%s] [facility_type=%s] [facility_id=%s] "
                        + "[date_from=%s] [date_to=%s]", 
                        adminuser,facility_type,str_facility_id,date_from,date_to
                        ));
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + adminuser + ", "
                + "facility_type=" + facility_type + ", "
                + "facility_id=" + str_facility_id + ", "        
                + "date_from=" + date_from + ", "
                + "date_to=" + date_to + "]");

        // 必須パラメータチェック
        if (adminuser == null || adminuser.equals("") || facility_type == null || facility_type.equals("")
                || str_facility_id == null) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(adminuser))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        int facility_id  = 0;
        
        try{
            facility_id = Integer.parseInt(str_facility_id);
        }catch(NumberFormatException e){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);            
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date dateFrom = null,dateTo = null; //to use some method in java.util.date, set it as Date first.

        try {
            if(date_from!=null && !date_from.equals("")){
                dateFrom = sdf.parse(date_from + " 00:00:00");
            }
            if(date_to!=null && !date_to.equals("")){
                dateTo = sdf.parse(date_to + " 23:59:59");
            }
        } catch (ParseException ex) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        if (dateFrom!=null & dateTo !=null && dateFrom.after(dateTo)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(adminuser) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
            /**
             * 権限チェック　
             */
            int auth = adminUtil.getUserType(adminuser);
            if (auth <= USER_INFO_TYPE_USER) { //any operator?
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        if (dateFrom == null) {
            dateFrom = db.query("SELECT MIN(start_time) FROM time_slot WHERE facility_id=?", (rs) ->{
                return new java.util.Date(fromTS(rs.getTimestamp(1)).getTime());
            }, facility_id).get(0);
        }
        if (dateTo == null) {
            dateTo = db.query("SELECT MAX(start_time) FROM time_slot WHERE facility_id=?", (rs) ->{
                return new java.util.Date(fromTS(rs.getTimestamp(1)).getTime());
            }, facility_id).get(0);
        }
        
        java.util.Date tmpDate = dateFrom;
        
        Map<String, Object> res = new HashMap<> ();
        List<TimeSlot> resLink = new ArrayList<>();
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
        while(tmpDate.before(dateTo)){
            try {
                Date time_slot_from = new Date(tmpDate);
                db.query("SELECT start_time,end_time FROM time_slot WHERE facility_type=? "
                        + "and facility_id=? and start_time=?", (rs) -> {                    
                    String tmpkey = sdf2.format(new java.util.Date(time_slot_from.getTime()));                    
                    resLink.add(new TimeSlot(tmpkey,(int)(rs.getTimestamp(2).getTime()-rs.getTimestamp(1).getTime() + 1000)/1000/60));
                }, facility_type,facility_id,toTS(time_slot_from));
                tmpDate = new java.util.Date(tmpDate.getTime()+ 24*60*60*1000);
            } catch (SQLException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", ex);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG + ": " +ex);
            }
        }
        res.put("intervals", resLink);
        logger.log(Level.FINE, classname, methodName, "END");
        return res;
    }
    
}
