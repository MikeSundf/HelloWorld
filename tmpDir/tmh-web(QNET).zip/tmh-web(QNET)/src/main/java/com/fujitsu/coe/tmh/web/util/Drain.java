package com.fujitsu.coe.tmh.web.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author unicenfujitsu
 */
public class Drain implements Runnable {
    
    private static final Logger LOGGER = Logger.getLogger(Drain.class.getName());

    private OutputStream out;
    private InputStream in;

    public Drain(Path log, InputStream in) throws IOException {
        out = Files.newOutputStream(log);
        this.in = in;
    }

    @Override
    public void run() {
        try {
            IOUtils.copy(in, out);
            out.close();
            in.close();
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "", e);
        }
    }
}
