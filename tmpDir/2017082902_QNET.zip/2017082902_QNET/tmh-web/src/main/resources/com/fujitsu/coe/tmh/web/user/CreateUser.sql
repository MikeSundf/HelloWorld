INSERT INTO user_info(
            user_id, email, name, password, home_address, postal_code, 
            mobile_num, mobile_os, notification_id, type, update_time)
    VALUES (?, ?, ?, ?, ?, 
            ?, ?, ?, ?, ?, ?);
