package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.EgressStep;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.ICMRequest;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.*;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.RouteFinder;
import com.fujitsu.coe.tmh.web.product.route.Step;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.math3.distribution.EnumeratedDistribution;

/**
 *
 * @author unicenfujitsu
 */
public class SDProductGenerator {

    private ICMContext ctx;
    private ICMRequest request;
    private Map<Integer, EnumeratedDistribution> cDistributions;

    public SDProductGenerator(ICMContext ctx, ICMRequest request) {
        this.ctx = ctx;
        this.request = request;
        cDistributions = new HashMap<>();
    }

    public List<Product> generate(int maxTime) throws SQLException, IOException {
        Date now = ctx.clock.now();
        List<? extends Route> routes = new RouteFinder(ctx).route(request.getFrom(), request.getTo());
        List<Product> products = new ArrayList<>();
        RouteDetailsBuilder rdBuilder = new RouteDetailsBuilder(ctx, request.getFromLocation());
        CongestionLevel cgLevel = new CongestionLevel(ctx);
        ctx.log(PG_CONGESTION, cgLevel);
        Set<Egress.Mode> supportedModes = PGUtil.getSupportedModes(ctx);
        BusFilter busFilter = new BusFilter(ctx.settings.get("icm.bus.filter", ""));
        for (Route route : routes) {
            RouteDetails rd = rdBuilder.build(route);
            if (!supportedModes.contains(rd.getMode())) continue;
            if (request.getSeats() > 4 && rd.getMode() == Egress.Mode.TAXI) continue;  // Singapore taxi only 4 pax
            int at = (int)Math.ceil(rd.getAccessTime());
            int tt = (int)Math.ceil(rd.getTravelTime());
            outer: for (int dt = 0; dt < maxTime; dt += 15) {
                long stepTime = 0;
                double sumWt = 0;
                
                Egress egress = new Egress(rd.getMode(), cgLevel.get(rd.getMode(), now.getTime() + toMS(dt) + stepTime), route.getFare(), new Date(now.getTime() + toMS(dt)));
                Step prev = null;
                for (Step step : route.getSteps()) {
                    // check for train transfer (and apply transfer time)
                    if (!busFilter.isAvailable(step)) {
                        continue outer;
                    }
                    if (prev != null && "TRAIN".equals(step.getVehicleType()) && "TRAIN".equals(prev.getVehicleType())) {
                        long walkingTime = toMS(getWalkingTime(prev, step));
                        egress.addStep(egress.getSteps().size() + 1, "WALK",
                                step.getService(), step.getLocation(),
                                null, walkingTime, 0, step.getLat(), step.getLon());
                        stepTime += walkingTime;
                    }
                    prev = step;
                    
                    double wt = rd.getWaitingTime(now.getTime() + stepTime, step);
                    sumWt += wt;
                    stepTime += wt;
                    egress.addStep(egress.getSteps().size() + 1, step.getVehicleType(),
                            step.getService(), step.getLocation(),
                            step.getDetails(), toMS(step.getTime()), toMS(wt), step.getLat(), step.getLon());
                    stepTime += toMS(step.getTime());
                }
                
                Product product = new Product(0, egress, now);
                product.setDt(dt);
                product.setAt(at);
                product.setWt((int)Math.ceil(sumWt));
                product.setTt(tt);
                product.reschedule();
                products.add(product);
            }
        }
        log(routes, products);
        return products;
    }
    
    private int getWalkingTime(Step prev, Step step) throws SQLException {
        return ((int)ctx.db.queryForLong("SELECT access_duration FROM train_transfer WHERE station_name=? AND line_from=? AND line_to=?", 
                step.getLocation(), prev.getService(), step.getService()));
    }
    
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("HH:mm:ss");
    private void log(List<? extends Route> routes, List<Product> products) throws SQLException {
        for (Route route: routes) {
            ctx.log(PG_ROUTE, route.getFare());
            int seq = 0;
            for (Step step: route.getSteps()) {
                seq++;
                ctx.log(PG_STEP, seq, step.getVehicleType(), step.getService(), step.getLocation(), step.getDetails(), step.getTime(), step.getLat(), step.getLon());
            }
        }
        ctx.log(PG_PRODUCT1);
        for (Product product: products) {
            Egress egress = product.getEgress();
            ctx.log(PG_PRODUCT2, egress.getMode(), egress.getCongestion(), 
                    product.getDt(), product.getAt(), product.getWt(), product.getTt(),
                    DATE_FORMAT.format(new java.util.Date(product.getStartTime().getTime())), 
                    DATE_FORMAT.format(new java.util.Date(egress.getStartTime().getTime())), 
                    DATE_FORMAT.format(new java.util.Date(egress.getDep().getTime())), 
                    DATE_FORMAT.format(new java.util.Date(egress.getArr().getTime())));
            for (EgressStep step : egress.getSteps()) {
                ctx.log(PG_PRODUCT3, step.getSeq(), step.getMode(), toXmXs(step.getTime()), toXmXs(step.getWaitTime()));
            }
        }
    }
    
    private static String toXmXs(long ms) {
        long s = ms / 1000;
        long m = s / 60;
        s = s % 60;
        return String.format("%dm%ds", m, s);
    }
    
    // KWM-FT2 requirement: certain buses are not available, filter these buses if they are in the solution
    private class BusFilter {
        private Set<String> unavailableServices;
        
        BusFilter(String setting) {
            this.unavailableServices = new HashSet<>(Arrays.asList(setting.split(" ")));
        }
        
        boolean isAvailable(Step step) {
            if (!"BUS".equals(step.getVehicleType())) return true;
            return !unavailableServices.contains(step.getService());
        }
    }
}
