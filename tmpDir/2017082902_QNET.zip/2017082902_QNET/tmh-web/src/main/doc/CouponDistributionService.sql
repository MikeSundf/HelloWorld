--------------------------------------------------CouponDistributionService
-- shop_evaluation
create table shop_evaluation (
  id serial not null
  , user_id character varying(45) not null
  , shop_id integer not null
  , value integer not null
  , time TIMESTAMP not null
  , constraint shop_evaluation_pkey primary key (id)
) ;
alter table shop_evaluation
  add constraint shop_evaluation_pkey1 foreign key (user_id) references user_info(user_id);

alter table shop_evaluation
  add constraint shop_evaluation_pkey2 foreign key (shop_id) references shop(shop_id);

-- coupon
create table coupon (
  coupon_id serial NOT NULL
  , shop_id integer not null
  , title character varying(100) not null
  , category character varying(45) not null
  , description character varying(300) default NULL
  , terms text default NULL
  , remarks character varying(100) default NULL
  , available integer not null
  , max_available integer not null
  , expiry_duration integer not null
  , expected_dwell_time integer default NULL
  , expiry_date timestamp without time zone
  , money_level numeric(10, 5) not null
  , coupon_value numeric(6, 2) not null
  , price_category integer default NULL
  , discount_category integer default NULL
  , enable_flag boolean default true not null
  , constraint coupon_pkey primary key (coupon_id)
) ;
alter table coupon
  add constraint coupon_pkey1 foreign key (shop_id) references shop(shop_id);

  
-- coupon_logo
create table coupon_logo (
  coupon_id integer not null
  , logo bytea not null
  , constraint coupon_id_pkey primary key (coupon_id)
) ;

alter table coupon_logo
  add constraint coupon_logo_pkey1 foreign key (coupon_id) references coupon(coupon_id);

-- user_coupon_activity
create table user_coupon_activity (
  id serial not null
  , user_id character varying(45) not null
  , coupon_id integer not null
  , activity_type integer not null
  , time TIMESTAMP not null
  , constraint user_coupon_activity_pkey primary key 

(id)
) ;
alter table user_coupon_activity
  add constraint user_coupon_activity_pkey1 foreign key (coupon_id) references coupon(coupon_id);

alter table user_coupon_activity
  add constraint user_coupon_activity_pkey2 foreign key (user_id) references user_info(user_id);

-- �N�[�|���{��
create table user_coupon_reading (
  id serial not null
  , user_id character varying(45) not null
  , coupon_id integer not null
  , reading_start_time TIMESTAMP not null
  , reading_end_time TIMESTAMP not null
  , reading_time integer not null
  , constraint user_coupon_reading_pkey primary key 

(id)
) ;
alter table user_coupon_reading
  add constraint user_coupon_reading_pkey1 foreign key (coupon_id) references coupon(coupon_id);

alter table user_coupon_reading
  add constraint user_coupon_reading_pkey2 foreign key (user_id) references user_info(user_id);

