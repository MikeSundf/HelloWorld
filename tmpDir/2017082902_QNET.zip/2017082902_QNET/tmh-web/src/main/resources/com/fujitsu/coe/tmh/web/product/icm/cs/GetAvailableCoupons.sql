SELECT c.id AS coupon_id, s.category, s.id AS shop_id, c.money_level, c.available, c.max_available 
FROM coupon c 
INNER JOIN shop s ON c.shop_id=s.id 
WHERE s.venue_id=? 
AND ? < c.expiry_date   -- not yet expired
AND (c.available > 0 OR c.max_available = -1)   -- coupon count available
AND c.id NOT IN (   -- not redeemed today (may be expensive subquery if data gets big, in the distanttttt future)
	SELECT pc.coupon_id 
	FROM product_coupon pc
	INNER JOIN product p ON pc.product_id=p.id
	INNER JOIN assortment a ON p.assortment_id=a.id
	WHERE pc.redemption_time::date = CURRENT_DATE
	AND a.user_id=?
)
