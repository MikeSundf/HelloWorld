DELETE FROM  beacon_facilityWHERE  beacon_facility.beacon_id = ?;
DELETE FROM  beacon_infoWHERE  beacon_id = ?;
