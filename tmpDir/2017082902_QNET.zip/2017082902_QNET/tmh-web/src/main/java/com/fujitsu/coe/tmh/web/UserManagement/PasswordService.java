package com.fujitsu.coe.tmh.web.UserManagement;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.tmh.web.common.ErrorFactory;
import com.fujitsu.coe.tmh.web.common.MapBuilder;
import com.fujitsu.coe.tmh.web.common.ValidationCheck;
import com.fujitsu.coe.tmh.web.common.SystemSettings;
import java.sql.SQLException;
import java.util.Date;
import java.util.Random;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.enterprise.context.ApplicationScoped;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.inject.Inject;
import javax.mail.Session;
import javax.mail.MessagingException;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.jasypt.util.password.StrongPasswordEncryptor;
import com.fujitsu.coe.tmh.web.common.LogManage;
import static com.fujitsu.coe.tmh.web.common.ParamConstants.*;

/**
 *
 * @author unicenfujitsu
 */
@Path("/profile")
@ApplicationScoped
public class PasswordService {

    String classname = PasswordService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private ActionLogger aLogger;
    @Inject
    private SystemSettings settings;
    private final StrongPasswordEncryptor encryptor;
    @Resource(lookup = "mail/tmh")
    private Session mailSession;
    @Inject
    private LogManage logger;
    private static final String PASSWORD_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int PASSWORD_LEN = 8;
    
    public PasswordService() {
        encryptor = new StrongPasswordEncryptor();
    }

    /**
     * パスワード変更
     * @param user_id
     * @param oldPass
     * @param newPass
     * @return
     * @throws SQLException
     * @author Qnet)gotoh
     */
    @POST
    @Path("/password")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map<String, Object> changePassword(
            @FormParam("user_id") String user_id,
            @FormParam("oldPass") String oldPass,
            @FormParam("newPass") String newPass) throws SQLException {
        aLogger.log(user_id, "PASSWORD_CHANGE", null, null);

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", oldPass=" + oldPass + ", newPass=" + newPass + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("") || oldPass == null || oldPass.equals("") || newPass == null || newPass.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(user_id)) ||
           !(ValidationCheck.checkPassword(oldPass)) ||
           !(ValidationCheck.checkPassword(newPass))
          ){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // パスワードチェック
        String actualPass = db.queryForString("SELECT password FROM user_info WHERE user_id=?", user_id);
        if (oldPass.equals(actualPass)) {
            try{
                db.update("UPDATE user_info SET password=? WHERE user_id=?", newPass, user_id);
                logger.log(Level.FINE, classname, methodName, "UPDATE user_info:[password=" + newPass + "]");
                logger.log(Level.FINE, classname, methodName, "END");
                return MapBuilder.build("ok", true);
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
                return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
        } else {
            logger.log(Level.WARNING, classname, methodName, INCORRECT_PW_MSG);
            return ErrorFactory.createError(INCORRECT_PW_CODE, INCORRECT_PW_MSG);
        }
    }

    /**
     * パスワードリセット
     * @param user_id
     * @param email
     * @return
     * @throws SQLException
     * @throws MessagingException 
     * @author Qnet)gotoh
     */
    @POST
    @Path("/reset_password")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map<String, Object> resetPassword(
            @FormParam("user_id") String user_id,
            @FormParam("email") String email) throws SQLException, MessagingException {
        aLogger.log(user_id, "PASSWORD_RESET", null, String.format("[user_id=%s] [email=%s]", user_id, email));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", email=" + email + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("") || email == null || email.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(user_id)) ||
           !(ValidationCheck.checkEmail(email))
          ){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // ユーザは登録済みか？
        long count = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?", user_id);
        if(count == 0){
            logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
            return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
        }

        // 名前取得
        String name = db.queryForString("SELECT name FROM user_info WHERE user_id=?", user_id);
        
        // 初期パスワード生成
        String password = genPassword();
        if(password == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // データベース登録
        try{
            db.update("UPDATE user_info SET password=? WHERE user_id=?", password, user_id);
            logger.log(Level.FINE, classname, methodName, "UPDATE user_info:[password=" + password + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        
        // 初期パスワードをメール送信しない場合
        if (settings.get("mail.enabled", "false").equalsIgnoreCase("false")) {
            logger.log(Level.INFO, classname, methodName,"Generated password for {0}: {1}");
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.create("ok", true)
                    .put("password", password)
                    .build();
        }

        // 初期パスワード送信
        int result = emailPassword(name, email, password);
        if(result == -1){
            return ErrorFactory.createError(FAILED_MAIL_CODE, FAILED_MAIL_MSG);
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    private String genPassword() throws SQLException {
        
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        
        String fixedPassword = settings.get("register.password");
        if (fixedPassword != null) {
            return fixedPassword;
        }

        Random rng = (Random)null;
        rng = new Random();
        if(rng == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return null;
        }
        StringBuilder buf = (StringBuilder)null;
        buf = new StringBuilder();
         if(buf == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return null;
        }       
        for (int i = 0; i < PASSWORD_LEN; i++) {
            buf.append(PASSWORD_CHARS.charAt(rng.nextInt(PASSWORD_CHARS.length())));
        }
        return buf.toString();
    }

    // TODO (future) generic mail(email, subject, body) method when more email needs to be sent
    // TODO (future) support multi-language for subject & body
    private int emailPassword(String clientName, String clientEmail, String clientPassword) throws SQLException, MessagingException {
        
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        
        MimeMessage message = new MimeMessage(mailSession);
        try {
            message.setFrom(new InternetAddress(settings.get("mail.from")));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(clientEmail));
            message.setSubject(settings.get("mail.subject"));
            message.setSentDate(new Date());
            message.setText(String.format(settings.get("mail.body"), clientName, clientPassword));
            Transport.send(message);
        } catch (MessagingException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "Mail send error.", ex);
            // 送信失敗した場合は30秒 wait
            try{
                Thread.sleep(30000);
            } catch (InterruptedException e){
                logger.thrownLog(Level.SEVERE, classname, methodName, "sleep error.", e);
            }
            // メール送信をリトライ
            try{
                Transport.send(message);
            } catch(MessagingException e){
                logger.thrownLog(Level.SEVERE, classname, methodName, "Mail send error.", e);
                return -1;
            }
        }
        return 0;
    }
    
    // TODO reset password
}
