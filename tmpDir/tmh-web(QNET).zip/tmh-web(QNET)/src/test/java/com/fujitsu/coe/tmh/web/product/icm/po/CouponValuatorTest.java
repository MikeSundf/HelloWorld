package com.fujitsu.coe.tmh.web.product.icm.po;

/**
 *
 * @author chuakayick
 */
public class CouponValuatorTest {
    public void testRedemption() {
        assert CouponValuator.getValue(0) == 0;
        assert CouponValuator.getValue(5) == 0;
        assert CouponValuator.getValue(12) == 0;
        assert CouponValuator.getValue(14) == 0;
        assert CouponValuator.getValue(15) == 2;
        assert CouponValuator.getValue(16) == 2;
        assert CouponValuator.getValue(29) == 2;
        assert CouponValuator.getValue(30) == 4;
        assert CouponValuator.getValue(60) == 8;
        assert CouponValuator.getValue(90) == 12;
        assert CouponValuator.getValue(105) == 12;
        assert CouponValuator.getValue(120) == 12;
        assert CouponValuator.getValue(200) == 12;
    }
}
