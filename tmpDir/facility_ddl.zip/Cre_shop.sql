CREATE TABLE shop
(
  id serial NOT NULL,
  name character varying(100) NOT NULL,
  venue_id integer NOT NULL,
  category character varying(45) DEFAULT NULL::character varying,
  address character varying(100) DEFAULT NULL::character varying,
  tel character varying(45) DEFAULT NULL::character varying,
  remarks character varying(100) DEFAULT NULL::character varying,
  location character varying(120) DEFAULT NULL::character varying,
  map_hint character varying(120) DEFAULT NULL::character varying,
  passcode character varying(45) DEFAULT NULL::character varying,
  lat numeric(10,5) DEFAULT NULL::numeric,
  lon numeric(10,5) DEFAULT NULL::numeric,
  gender_age_group character varying(120) DEFAULT NULL::character varying,
  enable_flag boolean,
  CONSTRAINT shop_pkey PRIMARY KEY (id),
  CONSTRAINT "venueFK" FOREIGN KEY (venue_id)
      REFERENCES venue (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
