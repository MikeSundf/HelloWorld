CREATE TABLE shuttle_stop
(
  id serial NOT NULL,
  venue_id integer,
  route character varying(10),
  name character varying(50),
  stop_name character varying(100),
  lat numeric(10,5) DEFAULT NULL::numeric,
  lon numeric(10,5) DEFAULT NULL::numeric,
  travel_duration smallint,
  CONSTRAINT shuttle_stop_pkey PRIMARY KEY (id),
  CONSTRAINT "venueFK" FOREIGN KEY (venue_id)
      REFERENCES venue (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
