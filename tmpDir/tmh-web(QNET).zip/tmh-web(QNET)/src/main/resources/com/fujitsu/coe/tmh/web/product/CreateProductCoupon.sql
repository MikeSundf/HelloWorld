INSERT 
INTO product_coupon(user_id, shop_id, coupon_id) 
VALUES 
