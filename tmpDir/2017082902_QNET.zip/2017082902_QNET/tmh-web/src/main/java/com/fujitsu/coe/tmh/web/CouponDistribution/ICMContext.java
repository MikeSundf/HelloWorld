package com.fujitsu.coe.tmh.web.CouponDistribution;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.tmh.web.common.ICMLogger;
import com.fujitsu.coe.tmh.web.common.ICMLogger.LogCategory;
import com.fujitsu.coe.tmh.web.common.SysClock;
import com.fujitsu.coe.tmh.web.UserManagement.User;
import com.fujitsu.coe.tmh.web.common.LogManage;
import com.fujitsu.coe.tmh.web.common.SystemSettings;
import com.fujitsu.coe.tmh.web.common.Timer;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.cxf.helpers.IOUtils;

/**
 *
 * @author unicenfujitsu
 */
public class ICMContext {

    private static final Logger LOGGER = Logger.getLogger(ICMContext.class.getName());
    private static final SimpleDateFormat REQID_FORMAT = new SimpleDateFormat("yyMMdd-HHmmss-SSS-");

    public final JdbcTemplate db;
    public final User user;
    public final SystemSettings settings;
    public final SysClock clock;
    public final Timer timer;
    public final String reqId;
    private ICMLogger logger;
    public static LogManage loggerV2;

    public ICMContext(JdbcTemplate db, User user, SystemSettings settings, SysClock clock, Timer timer) {
        this.db = db;
        this.user = user;
        this.settings = settings;
        this.clock = clock;
        this.timer = timer;
        this.reqId = REQID_FORMAT.format(new Date()) + user.getId();   // must use system date, not virtual time

        try {
            if (Boolean.valueOf(settings.get("icm.log.enabled", "true"))) {
                String logPath = settings.get("icm.log.path", "/temp/icm/log");
                logger = new ICMLogger(logPath, reqId);
            }
        } catch (SQLException | IOException e) {
            // too bad, no logging. but shouldn't happen
            LOGGER.log(Level.SEVERE, "", e);
        }

    }

    public ICMContext(JdbcTemplate db, SystemSettings settings, SysClock clock, Timer timer, LogManage logger) {
        this.db = db;
        this.user = null;
        this.settings = settings;
        this.clock = clock;
        this.timer = timer;
        this.loggerV2 = logger;
        this.reqId = "";
    }

    public void log(LogCategory type, Object... params) {
        if (logger == null) {
            return;
        }
        logger.log(type, params);
    }

    public String getResource(Object ref, String path) {
        try {
            return IOUtils.toString(ref.getClass().getResourceAsStream(path));
        } catch (IOException ioE) {
            throw new IllegalArgumentException(ioE);    // should be static resource, so should not happen during runtime
        }
    }
}
