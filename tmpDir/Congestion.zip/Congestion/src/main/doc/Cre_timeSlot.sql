﻿CREATE TABLE time_slot
(
    facility_type character varying(45) NOT NULL,
    facility_id integer NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    actual_congestion_level integer,
    predicted_congestion_level integer,
    actual_wait_time integer,
    predicted_wait_time integer,
    capacity integer,
    expected_people_count integer,
    CONSTRAINT time_slot_pkey PRIMARY KEY (facility_type, facility_id, start_time, end_time)
);
