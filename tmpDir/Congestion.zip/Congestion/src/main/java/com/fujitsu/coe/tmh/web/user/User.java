package com.fujitsu.coe.tmh.web.user;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

/**
 * Represents a session. Abstraction allows change of implementation, e.g.
 * cluster-based.
 *
 * @author ky
 */
@RequestScoped
public class User {

    private String id;
    private String role;
    private int venue;

    @Inject
    private transient HttpSession session;

    @PostConstruct
    protected void init() {
        String id = (String)session.getAttribute("userId");
        if (id == null) {
            return;
        }
        String role = (String) session.getAttribute("role");
        if (role == null) {
            return;
        }
        String venue = (String) session.getAttribute("venue");//
        if (venue == null) {
            return;
        }
        this.id = id;
        this.role = role;
        this.venue = (int) session.getAttribute("venue");
    }

    public String getId() {
        return id;
    }

    public boolean isLoggedIn() {
        return (id == null);
    }

    public int getVenue() {
        return venue;
    }
    
    //＠TODO　これでいいか？
    public void setId(String id) {        
        if (id == null) {
            return;
        }
        this.id = id;
    }

    public void setVenue(int venue) {
        if (venue< 0) {
            return;
        }
        this.venue = venue;
    }

    public void setRole(String role) {
        if (role == null) {
            return;
        }
        this.role = role;
    }
}
