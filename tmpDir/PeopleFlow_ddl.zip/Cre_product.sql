CREATE TABLE product
(
  id serial NOT NULL,
  assortment_id integer NOT NULL,
  seq smallint,
  egress_mode character varying(10) NOT NULL,
  congestion smallint,
  cost numeric(6,2) NOT NULL,
  created_time timestamp without time zone NOT NULL DEFAULT now(),
  dwell_duration smallint,
  access_duration smallint,
  waiting_duration smallint,
  travel_duration smallint,
  dep_time timestamp without time zone NOT NULL,
  arr_time timestamp without time zone NOT NULL,
  CONSTRAINT product_pkey PRIMARY KEY (id),
  CONSTRAINT product_assortment_id_fkey FOREIGN KEY (assortment_id)
      REFERENCES assortment (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
