package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;
import com.fujitsu.coe.tmh.web.util.Location;
import java.sql.SQLException;

/**
 *
 * @author kychua
 */
public class TrainRouteDetails extends BusTrainRouteDetails {

    public TrainRouteDetails(ICMContext ctx, Route route, Egress.Mode mode, Location userLocation) throws SQLException {
        super(ctx, route, mode);
        
        // assumptions - first step always walk, 2nd step always the train
        Step firstWalk = route.getSteps().get(0);
        Step firstTrain = route.getSteps().get(1);

        // rewrite first mile access
        final Location[] stnLocation = new Location[1];
        ctx.db.query("SELECT id, lat, lon FROM train_station WHERE name=?", (rs) -> {
            stnLocation[0] = new Location(rs.getDouble(2), rs.getDouble(3));
        }, firstTrain.getLocation());   // station name
        
        firstWalk.setLocation(userLocation.getLat(), userLocation.getLon());
        firstWalk.setTime(PGUtil.getAccessTime(userLocation, stnLocation[0]));
        
        init();
    }
    
}
