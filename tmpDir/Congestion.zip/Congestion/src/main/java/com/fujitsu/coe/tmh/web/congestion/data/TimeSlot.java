/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.congestion.data;

/**
 *
 * @author fujitsu
 */
public class TimeSlot {
    private String date;
    private int interval;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }
    
    public TimeSlot(String date, int interval){
        this.date = date;
        this.interval = interval;
    }
}
