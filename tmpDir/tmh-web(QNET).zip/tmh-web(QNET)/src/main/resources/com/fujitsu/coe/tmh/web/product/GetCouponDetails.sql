SELECT s.name AS shop_name, c.*, pc.*, (pc.redemption_time IS NOT NULL) AS redeemed, (sl.id IS NOT NULL) AS has_banner 
FROM coupon c
INNER JOIN shop s ON c.shop_id=s.shop_id
INNER JOIN product_coupon pc ON c.coupon_id=pc.coupon_id 
INNER JOIN product p ON pc.product_id=p.id 
INNER JOIN assortment a ON a.id=p.assortment_id 
LEFT JOIN shop_logo sl ON c.coupon_id=sl.id AND sl.type='COUPON'
WHERE pc.id=? AND a.user_id=?

