﻿# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: yfan

v5. it is to run the PO learning from command window with user id as the parameter


"""
import psycopg2
import psycopg2.extras
import sys
import numpy as np
import csv
from configparser import ConfigParser
from learning_framework63_segment_reverse import segment_learning_reverse_all
from user_agent import UserAgent

def config(filename = 'database.ini', section= 'postgresql'):
    #create a parser
    parser = ConfigParser()
    #read config file
    parser.read(filename)
    #get section, default to postgresql
    db = {}
    if parser.has_section(section):
        parameters = parser.items(section)
        for parameter in parameters:
            db[parameter[0]]=parameter[1]
    else:
        raise Exception('Section {0} not found in {1} file'.format(section, filename))
        
    return db

def main(user_id):
        
    ## to connect to database    
    #Define our connection string
    conn = None
    parameters = config()
    try:
#        conn_string = "host='localhost' dbname='ICM' user='postgres' password='password'"  
#        print "Connecting to database\n	->%s" % (conn_string)  
        conn = psycopg2.connect(**parameters)    
        # conn.cursor will return a cursor object, you can use this cursor to perform queries
        cursor = conn.cursor(cursor_factory = psycopg2.extras.DictCursor)
        print 'Connected!\n'
    except psycopg2.DatabaseError:
        print 'I am unable to connect the database:'
        sys.exit(1)
    
    sql = "SELECT * from l_products WHERE user_id= %s" % user_id
    try:    
        print 'SQL: %s' %(sql)
        cursor.execute(sql)
    except psycopg2.DatabaseError:
        print 'unable to retrieve the records'
        sys.exit(1)
        
    products = cursor.fetchall()
    cursor.close()   
    print 'the number of products: %d' %(len(products))
    r_choice = -1
    list_choices = []
    list_seq = []
    list_products = []
    
    if (len(products) > 0): #only go into learning when this user with specified user_id has record
        
        # to get the id of selected products and number of choice this user has made
        for idx, product in enumerate(products):


            if (product['id'] == product['selected']):
                list_choices.append(product['selected'])
                list_seq.append(product['seq']-1)

        # to get all assortment provided to the user for each choice 
        for idx in range(len(list_choices)):
            r_choice = list_choices[idx]
            one_list_products = []
            for iddx, product in enumerate(products):
                hist_product = []
                if (product['selected']==r_choice):
                    cv_value = int(product['dt']/15)*2
                    if (cv_value > 12):
                        cv_value = 12

#		    print 'product(%s): seq=%d, selected=%d, mode=%s, fare=%d, dt=%d, at=%d, wt=%d, tt=%d, cg=%d, cv=%d' %(product['id'], product['seq'], product['selected'], product['mode'], product['fare'], product['dt'], product['at'], product['wt'], product['tt'], product['cg'], product['cv'])
		    print 'product(%s): seq=%d, selected=%d, mode=%s, fare=%d, dt=%d, at=%d, wt=%d, tt=%d, cg=%d, cv=%d' %(product['id'], product['seq'], product['selected'], product['mode'], product['fare'], product['dt'], product['at'], product['wt'], product['tt'], product['cg'], cv_value)

                    hist_product = {"mode":product['mode'],"fare":float(product['fare']), "dt":product['dt'], "at":product['at'], "wt":product['wt'], "tt":product['tt'], "cg":product['cg'],"cv": cv_value}
                    one_list_products.append(hist_product)
            list_products.append(one_list_products)
        
        user_learnt, ch = segment_learning_reverse_all(list_products, list_seq)
        
        update_user = """UPDATE l_user_profile
                            SET beta_cg = %s,
                            beta_i = %s,
                            beta_dt = %s,
                            beta_ivtt = %s,
                            beta_ovtt = %s,
                            beta_wt = %s
                            WHERE user_id = %s """
        updated_rows = 0
        
        if (ch > 0): 
            # update the database table only when their coefficients are learnt
            try:
                
                cursor = conn.cursor()
                cursor.execute(update_user, (user_learnt["B_CG"], user_learnt["B_I"], user_learnt["B_DT"], user_learnt["B_TT"], user_learnt["B_AT"], user_learnt["B_WT"], user_id)) 
                updated_rows = cursor.rowcount
                print(updated_rows)
                conn.commit()
                cursor.close()
            except psycopg2.DatabaseError:
                print "unable to update the coefficients of user!"
        else:
            print "this user's coefficients are not learnt. "
                     
    else:
        print "this user has no record."
    
    if conn is not None:
        conn.close()
        print("Database connection closed.")
    
#    return (user_learnt, ch) 
    

if __name__ == "__main__":
    
#    user_id = sys.argv[1]
    if (len(sys.argv) <= 1):
        filename = open("C:/DMMDevelopment/Vishal/ICM/userlist.csv", "r")
        reader = csv.reader(filename)
        list_user = list(reader)
        list_user = np.array(list_user[1:])
        learnt_result = []
        for i in range(len(list_user)):
            main(list_user[i][1])
#            user_learnt, ch = main(list_user[i][1])
#            user_learnt['iter']=ch
#            learnt_result.append(user_learnt)
#        print(learnt_result)
#        with open('c:/DMMDevelopment/Vishal/ICM/learnt_result.csv', 'wb') as output:
#            writer = csv.writer(output, delimiter=',')
#            writer.writerows(enumerate(learnt_result))
        #print user_learnt
    else:
#        main(sys.argv[1])
        main3()
    
