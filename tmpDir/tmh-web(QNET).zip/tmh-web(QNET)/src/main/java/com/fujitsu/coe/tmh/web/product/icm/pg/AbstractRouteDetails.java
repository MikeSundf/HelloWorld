package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;

/**
 *
 * @author kychua
 */
abstract class AbstractRouteDetails implements RouteDetails {

    private static final String WALK = "WALK";

    protected ICMContext ctx;
    protected Route route;
    private Egress.Mode mode;

    private double at;
    private double tt;

    public AbstractRouteDetails(ICMContext ctx, Route route, Egress.Mode mode) {
        this.ctx = ctx;
        this.route = route;
        this.mode = mode;
    }
    
    protected void init() {
        for (Step step : route.getSteps()) {
            if (WALK.equals(step.getVehicleType())) {
                at += step.getTime();
            } else {
                tt += step.getTime();
            }
        }
    }

    @Override
    public Egress.Mode getMode() {
        return mode;
    }

    @Override
    public double getAccessTime() {
        return at;
    }

    @Override
    public double getTravelTime() {
        return tt;
    }
}
