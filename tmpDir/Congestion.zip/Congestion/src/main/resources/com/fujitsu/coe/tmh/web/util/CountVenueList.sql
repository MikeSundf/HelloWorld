SELECT COUNT(*) 
from
  shop 
  inner join admin_info 
    on admin_info.manage_id = shop.venue_id 
    AND admin_info.user_id = ? 
    AND shop.shop_id = ?