package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.Ruler;
import com.fujitsu.coe.tmh.web.util.Location;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.apache.http.HttpHost;
import org.apache.http.client.fluent.Executor;
import org.apache.http.client.fluent.Request;

/**
 *
 * @author kychua
 */
public class PGUtil {
    
    // For future support of database proxy setting
    private static final Pattern PROXY_PATTERN = Pattern.compile("(([^:]+):([^@]+)@)?([^@:]+)(:(\\d+))?");
    /*
        Match 1
        Full match	0-24	`user:pass@proxy.com:8080`
        Group 1.	0-10	`user:pass@`
        Group 2.	0-4	`user`
        Group 3.	5-9	`pass`
        Group 4.	10-19	`proxy.com`
        Group 5.	19-24	`:8080`
        Group 6.	20-24	`8080`
    */
    
    // KWM-FT2 requirement: only MRT modes allowed, so DB settings shall define which modes supported.
    public static Set<Egress.Mode> getSupportedModes(ICMContext ctx) throws SQLException {
        String[] modesStr = ctx.settings.get("icm.modes", "BUS TRAIN TAXI STAXI SHUTTLE WALK").split(" ");
        return Arrays.asList(modesStr).stream()
                .map(it -> Egress.Mode.valueOf(it))
                .collect(Collectors.toSet());
    }
        
    // WARNING: 75 metres/min is what SD.com uses (as of now), adjusting this may require recalculating all other access time derived from distance.
    public static double getAccessTime(Location userLocation, Location eLoc) {
        double distance = Ruler.distance(userLocation, eLoc);
        double speed = 75; // m/min
        return distance / speed; // minutes
    }
    
    public static String curl(String url) throws IOException {
        Executor exe = Executor.newInstance();  // TODO share instance pool?
        if (System.getProperty("http.proxyHost") != null) {
            exe.auth(new HttpHost(System.getProperty("http.proxyHost"), 
                    Integer.parseInt(System.getProperty("http.proxyPort"))), 
                    System.getProperty("http.proxyUser"), 
                    System.getProperty("http.proxyPass"));
        }
        return exe.execute(Request.Get(url)
                        .connectTimeout(10000)
                        .socketTimeout(20000))
                .returnContent().asString();
    }
}
