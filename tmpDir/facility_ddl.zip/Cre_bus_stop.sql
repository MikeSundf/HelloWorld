CREATE TABLE bus_stop
(
  stop_code integer NOT NULL,
  name character varying(100) NOT NULL,
  venue_id integer NOT NULL,
  lat numeric(10,5),
  lon numeric(10,5),
  CONSTRAINT bus_stop_pkey PRIMARY KEY (stop_code),
  CONSTRAINT "venueFK" FOREIGN KEY (venue_id)
      REFERENCES venue (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);

