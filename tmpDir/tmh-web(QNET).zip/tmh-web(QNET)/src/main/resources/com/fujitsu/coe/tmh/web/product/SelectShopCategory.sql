SELECT category
from
  shop 
where shop_id = ?