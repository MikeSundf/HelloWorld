SELECT up.user_id, 
CASE WHEN (gender IS NULL) THEN '-' ELSE gender END, 
CASE WHEN (age_group IS NULL) THEN -1 ELSE age_group END, 
CASE WHEN (income_group IS NULL) THEN -1 ELSE income_group END, 
beauty.pref_value beauty, dining.pref_value dining, electronics.pref_value electronics, fashion.pref_value fashion, grocery.pref_value grocery, 
lifestyle.pref_value lifestyle, maternity.pref_value maternity, sport.pref_value sport, sportswear.pref_value sportswear, travel.pref_value travel
FROM user_profile up
LEFT JOIN user_preference beauty 	ON up.user_id=beauty.user_id 		AND beauty.pref_key='beauty'
LEFT JOIN user_preference dining 	ON up.user_id=dining.user_id 		AND dining.pref_key='dining'
LEFT JOIN user_preference electronics 	ON up.user_id=electronics.user_id 	AND electronics.pref_key='electronics'
LEFT JOIN user_preference fashion 	ON up.user_id=fashion.user_id 		AND fashion.pref_key='fashion'
LEFT JOIN user_preference grocery 	ON up.user_id=grocery.user_id 		AND grocery.pref_key='grocery'
LEFT JOIN user_preference lifestyle 	ON up.user_id=lifestyle.user_id 	AND lifestyle.pref_key='lifestyle'
LEFT JOIN user_preference maternity 	ON up.user_id=maternity.user_id 	AND maternity.pref_key='maternity'
LEFT JOIN user_preference sport 	ON up.user_id=sport.user_id 		AND sport.pref_key='sport'
LEFT JOIN user_preference sportswear 	ON up.user_id=sportswear.user_id 	AND sportswear.pref_key='sportswear'
LEFT JOIN user_preference travel 	ON up.user_id=travel.user_id 		AND travel.pref_key='travel'
WHERE up.user_id=?;
