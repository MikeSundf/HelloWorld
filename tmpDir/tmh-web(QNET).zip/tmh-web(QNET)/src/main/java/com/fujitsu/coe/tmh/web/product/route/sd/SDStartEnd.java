package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 *
 * @author kychua
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDStartEnd {
    private double lat; // y
    private double lon; // x;
    
    private String title;  // tt
    private String description; // dc
    private String postal; // po
    
    private String addressId;  // ai
    private String placeId;  // pi

    public void setY(double lat) {
        this.lat = lat;
    }

    public void setX(double lon) {
        this.lon = lon;
    }

    public void setDc(String description) {
        this.description = description;
    }

    public void setTt(String title) {
        this.title = title;
    }

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }

    public String getDescription() {
        return description;
    }

    public String getTitle() {
        return title;
    }
}
