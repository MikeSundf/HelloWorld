# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import psycopg2
import psycopg2.extras
import sys
import numpy as np
import pandas as pd
import random
import math
import os.path
import copy

from config import Config
from configparser import ConfigParser


def main():
    """
    extract last line from param_valid.csv file for each test (actual parameters)
    The file contains results that same choice probability of actual parameters and estimated parameters
    """

    args = sys.argv

    algo_str = "algo4"


    for k in range(2):
        assort_str = "fixed"
        if (k == 1):
            assort_str = "random"
        else:
            continue

        for j in range(2):
            param_str = "err1"
            if (j == 1):
                param_str = "err_all_attr"

            filepath2 = "./" + algo_str + "/param_valid_" + assort_str + "_" + param_str + "_exact.csv"
            filepath3 = "./" + algo_str + "/param_valid_" + assort_str + "_" + param_str + "_segment.csv"
            print("write same choice probability (exact match)  to file: %s" % filepath2)
            print("write same choice probability (segment match)  to file: %s" % filepath3)
            data_exact = pd.DataFrame(index=[], columns=[])
            data_segment = pd.DataFrame(index=[], columns=[])

            for i in range(100):
                user_str = "user_%d" % (i)


                filepath = "./" + algo_str + "/" + user_str + "/" + assort_str + "/" + param_str + "/param_valid.csv"

                if (os.path.exists(filepath) == False):
                    print ("cannot find file: %s" % filepath)
                    continue

                data1 = pd.read_csv(filepath)
                data2 = data1['exact_rate']
                data3 = data1['segment_rate']

#                data2.columns = [user_str]
#                data2 = data2.rename(columns={'iter', user_str}, inplace=True)
#                print(data2)
                data_exact[user_str] = list(data2.values.flatten())
                data_segment[user_str] = list(data3.values.flatten())

#                data = pd.concat([data, data2])

                data_exact.to_csv(filepath2, header='True')
                data_segment.to_csv(filepath3, header='True')

        #                csvWriter = csv.writer(f, lineterminator='\n')

    print ("finished!")


if __name__ == "__main__":
    main()

