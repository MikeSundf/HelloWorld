package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.ICMRequest;
import com.fujitsu.coe.tmh.web.product.icm.Ruler;
import com.fujitsu.coe.tmh.web.product.icm.pg.fmod.FMODGateway;
import com.fujitsu.coe.tmh.web.product.icm.pg.fmod.FMODProduct;
import com.fujitsu.coe.tmh.web.util.Location;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toMS;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author kychua
 */
public class FMODProductGenerator {
    
    private ICMContext ctx;
    private ICMRequest request;

    public FMODProductGenerator(ICMContext ctx, ICMRequest request) {
        this.ctx = ctx;
        this.request = request;
    }
    
    // TODO icm logging
    public List<Product> generate(int maxTime) throws SQLException, IOException {
        Set<Egress.Mode> supportedModes = PGUtil.getSupportedModes(ctx);
        if (!supportedModes.contains(Egress.Mode.STAXI)) return Collections.emptyList();

        String[] originSetting = ctx.settings.get("fmod.origin" + ctx.user.getVenue(), "1.292919, 103.857651").split(",");   // lat, lon
        Location origin = new Location(Double.parseDouble(originSetting[0].trim()), Double.parseDouble(originSetting[1].trim()));
        
        FMODGateway fmod = new FMODGateway(ctx);
        fmod.register();
        List<FMODProduct> fmodProducts = fmod.request(origin, request.getToLocation(), request.getSeats());
        if (fmodProducts == null) return Collections.emptyList();
        // TODO save the results first
        
        double distance = Ruler.distance(origin, request.getToLocation());
        double fare = calculateFare(distance, request.getSeats());
        long at = (long)Math.ceil(PGUtil.getAccessTime(request.getFromLocation(), origin) * TimeUnit.MINUTES.toMillis(1));     // milliseconds
       
        CongestionLevel cgLevel = new CongestionLevel(ctx);
        List<Product> products = new ArrayList<>();
        for (FMODProduct fmodProduct: fmodProducts) {
            Date depDate = fmodProduct.getPickupEarly();
            int dt = (int)TimeUnit.MILLISECONDS.toMinutes(depDate.getTime() - ctx.clock.now().getTime() - at);
            if (dt <= 0) continue;  // infeasible product
            if (dt < 15) continue; // eiji@20161223: show only 15min later products to allow enought time to go booth, make payment, etc.
            if (dt > maxTime) continue;
            
            Egress egress = new Egress(Egress.Mode.STAXI, cgLevel.get(Egress.Mode.STAXI, ctx.clock.now().getTime() + toMS(dt)), fare, new Date(new Date().getTime() + TimeUnit.MINUTES.toMillis(dt)));
            
            egress.addStep(1, "WALK", "Pickup Point", null, "Convention Centre Entrance", at, 0, request.getFromLocation().getLat(), request.getFromLocation().getLon());
            egress.addStep(2, "STAXI", null, "Suntec Convention Centre Level 1", String.valueOf(request.getSeats()), (int)Math.ceil(fmodProduct.getTravelTime() * TimeUnit.MINUTES.toMillis(1)), 0, origin.getLat(), origin.getLon());
            egress.addStep(3, "ARRIVE", null, null, null, 0, 0, request.getToLocation().getLat(), request.getToLocation().getLon());
            
            Product product = new Product(0, egress, ctx.clock.now());
            product.setDt(dt);
            product.setAt((int)TimeUnit.MILLISECONDS.toMinutes(at));
            product.setWt(0);   // always 0
            product.setTt((int)Math.ceil(fmodProduct.getTravelTime()));
            product.setSource(fmodProduct);
            products.add(product);
        }
        
        return products;
    }
    
    private double calculateFare(double distance, int seats) {
        double zone = Math.ceil(distance / 2000);
        double fare = zone * 2;
        return Math.min(fare, 10) * seats;
    }
}
