package com.fujitsu.coe.tmh.web.common;

import com.fujitsu.coe.ss.util.Date;
import java.sql.Timestamp;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author unicenfujitsu
 */
public class TimeUtil {

    public static int toHHMM(Date date) {
        long mins = (date.getTime() + TimeZone.getDefault().getRawOffset()) / 1000 / 60;
        int mm = (int) (mins % 60);
        int hh = (int) ((mins / 60) % 24);
        return hh * 100 + mm;
    }
    
    public static Timestamp toTS(Date date) {
        return new Timestamp(date.getTime());
    }

    public static Date fromTS(Timestamp ts) {
        return new Date(ts.getTime());
    }

    public static long toMS(double mins) {
        // return TimeUnit.MINUTES.toMillis(mins); // only accept long?
        return (long)(mins * TimeUnit.MINUTES.toMillis(1));
    }
}
