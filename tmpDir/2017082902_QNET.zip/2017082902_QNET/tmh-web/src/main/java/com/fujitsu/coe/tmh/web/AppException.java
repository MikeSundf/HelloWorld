package com.fujitsu.coe.tmh.web;

/**
 *
 * @author unicenfujitsu
 */
public class AppException extends RuntimeException {
    private int code;
    private String description;
    private Object data;

    public AppException(int code, String description, Object data) {
        super(description);
        this.code = code;
        this.description = description;
        this.data = data;
    }
    
    public AppException(int code, String description) {
        this(code, description, null);
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public Object getData() {
        return data;
    }
}
