﻿# -*- coding: utf-8 -*-
"""
Created on Tue Apr 4 00:00:00 2017

@author: takuro
v1.0 create
"""

import numpy as np

class RangeCount(object):
    """
    histogram
    """
    def __init__(self, lower, upper):
        
        self.lower = lower
        self.upper = upper
        self.count = 0

    def setCount(self, count):
        self.count = count

    def getCount(self):
        return self.count

class Histogram(object):
    """
    histogram
    """
    def __init__(self, lower, upper, level_num):
        
        self.lower = lower
        self.upper = upper

        interval = float(upper - lower) / (level_num - 1)
        self.list = []
        max = 0
        for j in range(level_num -1):
            range_count = RangeCount(lower + j * interval, lower + (j + 1) * interval)
            max = lower + (j + 1) * interval
            self.list.append(range_count)
            print ("range[%f, %f]" % (range_count.lower, range_count.upper))

        self.list.append(RangeCount(max, float("inf")))

    def update(self, value):
        
#        print ("update(%f)" % (value)

        for j in range(len(self.list)):
            range_count = self.list[j]
#            print ("range[%f, %f]" % (range_count.lower, range_count.upper)
            if range_count.lower <= value and range_count.upper > value:
                range_count.count += 1
#                print ("increment count %d" % (range_count.count)
                break

    def get_frequent_range(self):

        frequent_range_list = []
        for i in range(len(self.list)):
            range_count = self.list[i]
            insert = None
            if i != 0:
                for j in range(len(frequent_range_list)):
                    if range_count.getCount() >= frequent_range_list[j].getCount():
                        frequent_range_list.insert(j, range_count)
                        insert = True
                        break

            if insert == None:
                frequent_range_list.append(range_count)
        return frequent_range_list


