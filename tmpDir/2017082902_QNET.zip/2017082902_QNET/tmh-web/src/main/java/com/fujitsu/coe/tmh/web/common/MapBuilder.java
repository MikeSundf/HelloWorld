package com.fujitsu.coe.tmh.web.common;

import java.util.HashMap;
import java.util.Map;

/**
 * Lazy method to generate maps.
 * 
 * @author ky
 */
public class MapBuilder {
    
    private Map map;
    
    public MapBuilder() {
        map = new HashMap();
    }
    
    public MapBuilder put(Object key, Object value) {
        map.put(key, value);
        return this;
    }
    
    public Map build() {
        return map;
    }
    
    public static MapBuilder create() {
        return new MapBuilder();
    }
    
    public static MapBuilder create(Object key, Object value) {
        return new MapBuilder().put(key, value);
    }
    
    public static Map build(Object key, Object value) {
        return create(key, value).build();
    }
}
