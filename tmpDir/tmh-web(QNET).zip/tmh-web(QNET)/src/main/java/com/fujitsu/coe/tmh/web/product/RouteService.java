package com.fujitsu.coe.tmh.web.product;

import com.fujitsu.coe.ss.fac.CheckRole;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.user.ActionLogger;
import com.fujitsu.coe.tmh.web.user.LogLocation;
import com.fujitsu.coe.tmh.web.user.User;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.sql.SQLException;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.*;

/**
 *
 * @author unicenfujitsu
 */
@Path("/route")
@ApplicationScoped
@CheckRole("user")
public class RouteService {

    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private ActionLogger aLogger;
    @Inject
    @ClasspathResource("GetCurrentProduct.sql")
    private String sqlGetCurrentProduct;

    /**
     * Retrieves the egress details of the currently selected product.
     *
     * @return details of a specific egress
     * @throws SQLException
     */
    @GET
    @Path("/details")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Egress getEgressDetails() throws SQLException {
        aLogger.log("EGRESS", null, null);
        final long[] holder = new long[1];
        db.query(sqlGetCurrentProduct, (rs) -> {
            holder[0] = rs.getLong(1);
        }, user.getId(), user.getVenue());
        long productId = holder[0];
        if (productId == 0) {
            return null;
        }

        Egress[] egress = new Egress[1];
        db.query("SELECT * FROM product WHERE id=?", (rs) -> {
            egress[0] = new Egress(Egress.Mode.valueOf(rs.getString("egress_mode")), rs.getInt("congestion"), rs.getDouble("cost"), 
                    new Date(rs.getTimestamp("created_time").getTime() + toMS(rs.getLong("dwell_duration"))));
            egress[0].setTime(fromTS(rs.getTimestamp("dep_time")), fromTS(rs.getTimestamp("arr_time")));
        }, productId);

        db.query("SELECT * FROM product_egress WHERE product_id=? ORDER BY step", (rs) -> {
            egress[0].addStep(rs.getInt("step"), rs.getString("mode"),
                    rs.getString("service"), rs.getString("location"), rs.getString("details"),
                    rs.getLong("duration"), rs.getLong("wait_duration"),
                    rs.getDouble("lat"), rs.getDouble("lon"));
        }, productId);

        return egress[0];
    }
    
    @POST
    @Path("/cancel")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String, Object> cancel() throws SQLException {
        // TODO stub
        return MapBuilder.create("ok", true).build();
    }
}
