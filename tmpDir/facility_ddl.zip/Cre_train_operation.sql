CREATE TABLE train_operation
(
  operator_id integer NOT NULL,
  line_id integer NOT NULL,
  station_id integer NOT NULL,
  "time" timestamp without time zone NOT NULL,
  actual_delay_time integer,
  predict_delay_time integer,
  CONSTRAINT train_operation_pk PRIMARY KEY (operator_id),
  CONSTRAINT "stationFK" FOREIGN KEY (station_id)
      REFERENCES train_station (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
