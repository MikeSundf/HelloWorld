# -*- coding: utf-8 -*-
"""
Created on Wed May 17 22:41:57 2017

@author: ikeda.takuro
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import os.path

from configparser import ConfigParser
from user_agent import DummyUserManager
import pandas as pd

class Config(object):

    def __init__(self):
        self.algo_dir = ""
        self.user_dir = ""
        self.output_dir = ""
        self.log_file = None
        self.assortment_file = None
        # create reference models(dummy users)
        self.dum = DummyUserManager()
        self.au_list = []


    def initialize(self, algo_type, user_id):
        self.algo_dir = "./algo%d" % algo_type
        if(os.path.exists(self.algo_dir) == False):
            os.mkdir(self.algo_dir)
    
        print ("\ncreate dummy users: "), 
        self.dum.generate_dummy_users3()
        self.dum.output_dummy_users(self.algo_dir)
        print ("\n"), 

        self.user_dir = self.algo_dir + "/user_%d" %(user_id)
        if(os.path.exists(self.user_dir) == False):
            os.mkdir(self.user_dir)


    def uninitialize(self):
        print("uninitialize")

def config(filename = 'database.ini', section= 'postgresql'):
    #create a parser
    parser = ConfigParser()
    #read config file
    parser.read(filename)
    #get section, default to postgresql
    db = {}
    if parser.has_section(section):
        parameters = parser.items(section)
        for parameter in parameters:
            db[parameter[0]]=parameter[1]
    else:
        raise Exception('Section {0} not found in {1} file'.format(section, filename))
        
    return db

