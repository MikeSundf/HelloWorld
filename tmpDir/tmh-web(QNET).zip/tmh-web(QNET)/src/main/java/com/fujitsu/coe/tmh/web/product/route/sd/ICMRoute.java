
package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fujitsu.coe.tmh.web.product.route.Route;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kychua
 */
public class ICMRoute implements Route {

    private double fare;
    private List<ICMStep> steps;
    
    public ICMRoute(double fare) {
        this.fare = fare;
        this.steps = new ArrayList<>();
    }
    
    @Override
    public double getFare() {
        return fare;
    }
    
    @Override
    public List<ICMStep> getSteps() {
        return steps;
    }
    
    public void addStep(ICMStep step) {
        steps.add(step);
    }
}
