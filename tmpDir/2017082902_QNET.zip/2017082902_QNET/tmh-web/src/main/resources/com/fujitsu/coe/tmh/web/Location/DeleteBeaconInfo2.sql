DELETE FROM  beacon_info WHERE  beacon_id = ?;
