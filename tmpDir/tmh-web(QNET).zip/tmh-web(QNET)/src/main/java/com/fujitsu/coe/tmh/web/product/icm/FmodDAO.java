package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.pg.fmod.FMODProduct;
import com.fujitsu.coe.tmh.web.util.TimeUtil;
import java.sql.SQLException;

/**
 *
 * @author kychua
 */
public class FmodDAO {
    
    private JdbcTemplate db;
    
    public FmodDAO(JdbcTemplate db) {
        this.db = db;
    }
    
    public void insert(String requestId, FMODProduct product) throws SQLException {
        db.update("INSERT INTO fmod_product(icm_request_id, fmod_request_id, fmod_product_id, schedule_id, pickup_time, dropoff_time) VALUES(?, ?, ?, ?, ?, ?)", 
                requestId, product.getRequestId(), product.getProductId(), product.getScheduleId(), TimeUtil.toTS(product.getPickupEarly()), TimeUtil.toTS(product.getDropoffEarly()));
    }
    
    public void tag(String requestId, Product product, long productId) throws SQLException {
        if (product.getEgress().getMode() != Egress.Mode.STAXI) return;
        
        FMODProduct fmodProduct = (FMODProduct)product.getSource();
        
        db.update("UPDATE fmod_product SET icm_product_id=? WHERE icm_request_id=? AND fmod_request_id=? AND fmod_product_id=?", 
                productId, requestId, fmodProduct.getRequestId(), fmodProduct.getProductId());
    }
    
    public FMODProduct getFMODProduct(long productId) throws SQLException {
        final FMODProduct product = new FMODProduct();
        
        db.query("SELECT * FROM fmod_product WHERE icm_product_id=?", (rs) -> {
            product.setRequestId(rs.getString("fmod_request_id"));
            product.setProductId(rs.getString("fmod_product_id"));
            product.setScheduleId(rs.getString("schedule_id"));
            product.setPickupEarly(new Date(rs.getTimestamp("pickup_time")));
            product.setDropoffEarly(new Date(rs.getTimestamp("dropoff_time")));
        }, productId);
        return product;
    }
}
