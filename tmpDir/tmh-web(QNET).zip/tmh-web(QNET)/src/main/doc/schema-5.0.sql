CREATE TABLE assortment (
  id serial NOT NULL,
  user_id int NOT NULL,
  venue_id int NOT NULL,
  created_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  selected_product int DEFAULT NULL,
  selected_time timestamp NULL DEFAULT NULL,
  request_id character varying(50) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE coupon (
  id serial NOT NULL,
  shop_id int NOT NULL,
  title character varying(100) NOT NULL,
  description character varying(300) DEFAULT NULL,
  terms text,
  remarks character varying(100) DEFAULT NULL,
  available int NOT NULL,
  max_available int NOT NULL,
  expiry_duration int NOT NULL,
  cluster_id smallint DEFAULT NULL,
  expected_dwell_time int DEFAULT NULL,
  expiry_date timestamp NOT NULL,
  money_level numeric(10,5) NOT NULL,
  coupon_value numeric(6,2) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE product (
  id serial NOT NULL,
  assortment_id int NOT NULL,
  seq smallint NOT NULL,
  egress_mode character varying(10) NOT NULL,
  congestion smallint DEFAULT NULL,
  cost numeric(6,2) NOT NULL,
  created_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  dwell_duration smallint DEFAULT NULL,
  access_duration smallint DEFAULT NULL,
  waiting_duration smallint DEFAULT NULL,
  travel_duration smallint DEFAULT NULL,
  dep_time timestamp NOT NULL,
  arr_time timestamp NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE product_coupon (
  id serial NOT NULL,
  product_id int NOT NULL,
  coupon_id int NOT NULL,
  seq smallint DEFAULT NULL,
  spent numeric(6,2) DEFAULT NULL,
  ref character varying(100) DEFAULT NULL,
  expiry_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  redemption_time timestamp NULL DEFAULT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE product_egress (
  product_id int NOT NULL,
  step smallint NOT NULL,
  mode character varying(10) NOT NULL,
  duration int NULL DEFAULT NULL,
  wait_duration int NULL DEFAULT NULL,
  action character varying(100) DEFAULT NULL,
  service character varying(100) DEFAULT NULL,
  location character varying(100) DEFAULT NULL,
  details character varying(100) DEFAULT NULL,
  lat numeric(11,8) DEFAULT NULL,
  lon numeric(11,8) DEFAULT NULL,
  PRIMARY KEY (product_id,step)
);

CREATE TABLE route_cache (
  id serial NOT NULL,
  created_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  from_location character varying(100),
  to_location character varying(100),
  response text,
  PRIMARY KEY (id)
);

CREATE TABLE shop (
  id serial NOT NULL,
  name character varying(100) NOT NULL,
  venue_id int NOT NULL,
  category character varying(45) DEFAULT NULL,
  address character varying(100) DEFAULT NULL,
  tel character varying(45) DEFAULT NULL,
  remarks character varying(100) DEFAULT NULL,
  location character varying(120) DEFAULT NULL,
  map_hint character varying(120) DEFAULT NULL,
  passcode character varying(45) DEFAULT NULL,
  utility_value numeric(10,5) DEFAULT NULL,
  PRIMARY KEY (id)
);

-- TODO rename to image_repo
CREATE TABLE shop_logo (
  id integer NOT NULL,
  type character varying(45) NOT NULL,
  logo bytea,
  PRIMARY KEY (id, type)
);

CREATE TABLE user_activity (
  user_id int NOT NULL,
  time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  location character varying(100) DEFAULT NULL,
  activity character varying(100) DEFAULT NULL,
  intent character varying(100) DEFAULT NULL,
  PRIMARY KEY (user_id)
);

CREATE TABLE user_info (
  id serial NOT NULL,
  first_name character varying(45) DEFAULT NULL,
  last_name character varying(45) DEFAULT NULL,
  home_address character varying(100) DEFAULT NULL,
  postal_code character varying(6) NULL,
  email character varying(100) NOT NULL UNIQUE,
  password character varying(100) NOT NULL,
  suspended_until timestamp DEFAULT NULL,
  mobile_num character varying(45) DEFAULT NULL,
  mobile_os character varying(45) DEFAULT NULL,
  notification_id character varying(45) DEFAULT NULL,
  created_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

CREATE TABLE user_location (
  id serial NOT NULL,
  user_id int NOT NULL,
  time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  lat numeric(11,8) DEFAULT NULL,
  lon numeric(11,8) DEFAULT NULL,
  accuracy numeric(10,5) DEFAULT NULL,
  location character varying(100) DEFAULT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE user_preference (
  user_id int NOT NULL,
  pref_key character varying(45) NOT NULL,
  pref_value character varying(200) DEFAULT NULL,
  PRIMARY KEY (user_id,pref_key)
);

CREATE TABLE user_profile
(
  user_id integer NOT NULL,
  gender character(1) DEFAULT NULL::bpchar,
  age_group smallint,
  income_group smallint,
  is_public_transport boolean DEFAULT true,
  cluster_id smallint,
  beta_cg numeric(10,5) DEFAULT NULL::numeric,
  beta_i numeric(10,5) DEFAULT NULL::numeric,
  beta_dt numeric(10,5) DEFAULT NULL::numeric,
  beta_ivtt numeric(10,5) DEFAULT NULL::numeric,
  beta_ovtt numeric(10,5) DEFAULT NULL::numeric,
  beta_wt numeric(10,5) DEFAULT NULL::numeric,
  CONSTRAINT user_profile_pkey PRIMARY KEY (user_id)
);

CREATE TABLE user_login_failure
(
  id serial NOT NULL,
  created_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  email character varying(100) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE venue (
  id serial NOT NULL,
  name character varying(100),
  lat numeric(10,5),
  lon numeric(10,5),
  PRIMARY KEY (id)
);

CREATE TABLE system_settings (
    setting_key character varying,
    setting_value character varying,
    PRIMARY KEY (setting_key)
);

CREATE TABLE bus_service (
    service_id serial,
    service_number character varying(10),
    direction character varying(10),
    stop_code integer,
    PRIMARY KEY (service_id)
);

CREATE TABLE bus_arrival (
    id serial,
    service_id integer,
    arrival_date date,
    arrival_time timestamp,
    PRIMARY KEY (id)
);

CREATE TABLE bus_frequency
(
  id serial NOT NULL,
  provider character varying(10),
  service character varying(10),
  direction character varying(10),
  am_peak numeric(4,1),
  am_off numeric(4,1),
  pm_peak numeric(4,1),
  pm_off numeric(4,1),
  PRIMARY KEY (id)
);

CREATE TABLE bus_stop (
  stop_code integer NOT NULL,
  name character varying(100) NOT NULL,
  venue_id int NOT NULL,
  lat numeric(10,5),
  lon numeric(10,5),
  PRIMARY KEY (stop_code)
);

CREATE TABLE taxi_stand (
  id serial NOT NULL,
  code character varying(10) NOT NULL,
  name character varying(100) NOT NULL,
  venue_id int NOT NULL,
  lat numeric(10,5),
  lon numeric(10,5),
  PRIMARY KEY (id)
);

CREATE TABLE train_station (
  id serial NOT NULL,
  code character varying(10)[] NOT NULL,
  name character varying(100) NOT NULL,
  venue_id int NOT NULL,
  lat numeric(10,5),
  lon numeric(10,5),
  PRIMARY KEY (id)
);

CREATE TABLE train_transfer (
  id serial NOT NULL,
  station_id int,
  station_name character varying(50),
  line_from character varying(50),
  line_to character varying(50),
  access_duration int,
  PRIMARY KEY (id),
  UNIQUE (station_id, line_from, line_to)
);

CREATE TABLE request (
    id character varying(50) NOT NULL,
    user_id int NOT NULL,
    venue_id int NOT NULL,
    from_location character varying(100),
    to_location character varying(100),
    from_lat numeric(11,8),
    from_lon numeric(11,8),
    to_lat numeric(11,8),
    to_lon numeric(11,8),
    hurry smallint,
    hungry smallint,
    seats smallint,
    created_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);

CREATE TABLE user_action_log (
  id serial NOT NULL,
  time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  device_id character varying(100),
  user_id int,
  location_id int,
  action character varying(100) NOT NULL,
  object character varying(100),
  data text,
  PRIMARY KEY (id)
);

-- FMOD Schema

CREATE TABLE fmod_product (
    id serial NOT NULL,
    icm_request_id character varying(50),
    icm_product_id int,
    fmod_request_id character varying(50),
    fmod_product_id character varying(50),
    schedule_id character varying(50),
    pickup_time timestamp,
    dropoff_time timestamp,
    PRIMARY KEY (id)
);

-- Shuttle Schema

CREATE TABLE shuttle_stop (
  id serial NOT NULL,
  route character varying(10),
  name character varying(50),
  stop_name character varying(100),
  lat numeric(11,8) DEFAULT NULL,
  lon numeric(11,8) DEFAULT NULL,
  travel_duration smallint DEFAULT NULL, 
  PRIMARY KEY (id)
);

CREATE TABLE shuttle_schedule (
  id serial NOT NULL,
  route character varying(10),
  departure_time timestamp,
  PRIMARY KEY (id)
);
