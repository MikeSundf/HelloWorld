package com.fujitsu.coe.tmh.web.product.route;

/**
 * Egress step of the RouteFinder.
 * 
 * @author unicenfujitsu
 */
public interface Step {

    public String getVehicleType();
    
    public String getService();
    public String getLocation();
    public String getDetails();
    public double getTime();    // in minutes
    public double getLat();
    public double getLon();
    
    // allow overwriting
    public void setTime(double time);
    public void setLocation(double lat, double lon);
    public void setInstruction(String service, String location, String details);
}
