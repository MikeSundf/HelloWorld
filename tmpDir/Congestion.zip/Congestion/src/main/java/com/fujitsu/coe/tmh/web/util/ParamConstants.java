/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.util;

/**
 *
 * @author qnet8733
 */
public class ParamConstants {

    private ParamConstants() {
    }

    //**************************************
    //             default
    //**************************************
    /**
     * DB最大値(default)
     */
    public static final String DB_DEFAULT_MAX_NUM = "10000000";

    //**************************************
    //             内部設定値
    //**************************************
    /**
     * 緯度経度　整数部最大桁数
     */
    public static final int LAT_LON_INTEGER_MAX_LENGTH = 3;    
    
    /**
     * 緯度経度　小数部最大桁数
     */
    public static final int LAT_LON_DECIMAL_MAX_LENGTH = 5;    
    
    /**
     * 整数部最大桁数超え
     */
    public static final int NUM_INTEGER_OVER = 1;    
    
    /**
     * 小数部最大桁数超え
     */
    public static final int NUM_DECIMAL_OVER = 2;    
    
    /**
     * マイナス
     */
    public static final int NUM_MINUS = -1;
    
    /**
     * 整数部最大桁数
     */
    public static final int NUM_INTEGER_MAX_LENGTH = 6;    
    
    /**
     * 小数部最大桁数
     */
    public static final int NUM_DECIMAL_MAX_LENGTH = 2;   
    
    //**************************************
    //             メッセージ
    //**************************************
    /**
     * パラメータ不正
     */
    public static int ILLEGAl_PARAM_CODE = 1001;
    public static String ILLEGAl_PARAM_MSG = "Illegal parameter.";

    /**
     * システムエラー
     */
    public static int SYSTEM_ERROR_CODE = 1002;
    public static String SYSTEM_ERROR_MSG = "System error.";

    /**
     * 登録数の上限に達した
     */
    public static int LIMIT_SHOP_REGISTER_CODE = 1003;
    public static String LIMIT_SHOP_REGISTER_MSG = "Limit of the number of registration.";

    /**
     * 取得数の上限に達した
     */
    public static int LIMIT_GET_CODE = 1004;
    public static String LIMIT_GET_MSG = "Limit of the number of acquisition.";

    /**
     * ID未登録
     */
    public static int UNREGISTERED_ID_CODE = 1005;
    public static String UNREGISTERED_ID_MSG = "Unregistered ID.";

    /**
     * 使用不可
     */
    public static int DISABLED_REGISTRATION_CODE = 2001;
    public static String DISABLED_REGISTRATION_MSG = "Registration disabled.";

    /**
     * アカウント使用不可
     */
    public static int DISABLED_LOGIN_CODE = 2002;
    public static String DISABLED_LOGIN_MSG = "Login disabled.";

    /**
     * アカウント停止中
     */
    public static int SUSPENDED_ACCOUNT_CODE = 2003;
    public static String SUSPENDED_ACCOUNT_MSG = "Account suspended.";

    /**
     * メールアドレス二重登録
     */
    public static int TAKEN_EMAIL_ALREADY_CODE = 2004;
    public static String TAKEN_EMAIL_ALREADY_MSG = "The email address has already been taken.";

    /**
     * ユーザID二重登録
     */
    public static int TAKEN_ID_ALREADY_CODE = 2005;
    public static String TAKEN_ID_ALREADY_MSG = "The user ID has already been taken.";

    /**
     * 管理者ID二重登録
     */
    public static int TAKEN_ADMINID_ALREADY_CODE = 2006;
    public static String TAKEN_ADMINID_ALREADY_MSG = "The admin ID has already been taken.";

    /**
     * ユーザ名とパスワードが無効
     */
    public static int INVALID_USERNAME_CODE = 2007;
    public static String INVALID_USERNAME_MSG = "Invalid username/password.";

    /**
     * パスワード誤り
     */
    public static int INCORRECT_PW_CODE = 2008;
    public static String INCORRECT_PW_MSG = "Incorrect password.";

    /**
     * ユーザ未登録
     */
    public static int UNREGISTERED_USER_CODE = 2009;
    public static String UNREGISTERED_USER_MSG = "Unregistered user.";

    /**
     * メール送信失敗
     */
    public static int FAILED_MAIL_CODE = 3001;
    public static String FAILED_MAIL_MSG = "Failed in a mail transmission.";

    /**
     * 権限がない
     */
    public static int NO_AUTHORITY_CODE = 4001;
    public static String NO_AUTHORITY_MSG = "There is no administrative authority.";

    /**
     * クーポンは既に使用済み
     */
    public static int USER_ALREADY_COUPON_CODE = 4002;
    public static String USER_ALREADY_COUPON_MSG = "The coupon is used already.";

    /**
     * パスコード誤り
     */
    public static int INVALID_PASSCODE_CODE = 4003;
    public static String INVALID_PASSCODE_MSG = "Invalid passcode.";

    /**
     * 残枚数不足
     */
    public static int SHORTAGE_COUPON_CODE = 4004;
    public static String SHORTAGE_COUPON_MSG = "Remainder number of sheets shortage of coupon.";

    /**
     * SQL発行エラー
     */
    public static int SQL_ERROR_CODE = 5000;
    public static String SQL_ERROR_MSG = "SQL Exception.";

    /**
     * SQL発行エラー
     */
    public static int SQL_UPDATE_ERROR_CODE = 5001;
    public static String SQL_UPDATE_ERROR_MSG = "Other users is editing in progress.";

    /**
     * クーポンセレクションから応答なし
     */
    public static int CS_ALGO_RESPONSE_ERR_CODE = 6000;
    public static String CS_ALGO_RESPONSE_ERR_MSG = "No response from Coupon-Selection Algo.";

    //**************************************
    //             DB設定値
    //**************************************
    /**
     * 有効
     */
    public static final boolean ENABLE_FLAG = true;      // 有効

    /**
     * 無効
     */
    public static final boolean NOT_ENABLE_FLAG = false; // 無効

    /**
     * <pre>
     * 管理者情報
     * admin_info
     * 管理車種別：2　開催地管理者
     * </pre>
     */
    public static final int ADMIN_TYPE_VENUE = 2;  // 開催地管理者

    /**
     * <pre>
     * 管理者情報
     * admin_info
     * 管理車種別：3　店舗管理者
     * </pre>
     */
    public static final int ADMIN_TYPE_SHOP = 3;   // 店舗管理者

    /**
     * <pre>
     * クーポン利用状況
     * user_coupon_activity
     * 利用種別：0　getCoupon
     * </pre>
     */
    public static final int ADMIN_TYPE_GET = 0;        // getCoupon

    /**
     * <pre>
     * クーポン利用状況
     * user_coupon_activity
     * 利用種別：1　getCouponDetail
     * </pre>
     */
    public static final int GET_DETAIL = 1; // getCouponDetail

    /**
     * <pre>
     * クーポン利用状況
     * user_coupon_activity
     * 利用種別：2　RedeemCoupon
     * </pre>
     */
    public static final int REDEEM = 2;     // RedeemCoupon

    /**
     * <pre>
     * ユーザ情報
     * user_info
     * 種別：0　ユーザ
     * </pre>
     */
    public static final int USER_INFO_TYPE_USER = 0;

    /**
     * <pre>
     * ユーザ情報
     * user_info
     * 種別：1　システム管理者
     * </pre>
     */
    public static final int USER_INFO_TYPE_SYSTEM = 1;

    /**
     * <pre>
     * ユーザ情報
     * user_info
     * 種別：2　開催地管理者
     * </pre>
     */
    public static final int USER_INFO_TYPE_VENUE = 2;

    /**
     * <pre>
     * ユーザ情報
     * user_info
     * 種別：3　店舗管理者
     * </pre>
     */
    public static final int USER_INFO_TYPE_SHOP = 3;
}
