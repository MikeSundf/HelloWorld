UPDATE venue 
SET
  name = ?
  , lat = ?
  , lon = ? 
WHERE
  venue_id = ?