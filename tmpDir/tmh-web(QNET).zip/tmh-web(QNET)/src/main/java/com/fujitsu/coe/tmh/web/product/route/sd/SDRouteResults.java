package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

/**
 * JSON model for root;
 *
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDRouteResults {

    private SDTaxiRoute taxi;   // taxi
    private SDBusTrainRoute bustrain; // bustrain
    private SDBusTrainRoute bus;  // bus
    private List<SDStartEnd> startEnd;    // start_end

    public void setTaxi(SDTaxiRoute taxi) {
        this.taxi = taxi;
    }

    public void setBustrain(SDBusTrainRoute bustrain) {
        this.bustrain = bustrain;
    }

    public void setBus(SDBusTrainRoute bus) {
        this.bus = bus;
    }

    public void setStart_end(List<SDStartEnd> startEnd) {
        this.startEnd = startEnd;
    }

    public SDTaxiRoute getTaxi() {
        return taxi;
    }

    public SDBusTrainRoute getBustrain() {
        return bustrain;
    }

    public SDBusTrainRoute getBus() {
        return bus;
    }

    public SDStartEnd getStart() {
        return startEnd.get(0);
    }

    public SDStartEnd getEnd() {
        return startEnd.get(1);
    }
    
    public boolean hasRoutes() {
        return (startEnd != null);
    }
}
