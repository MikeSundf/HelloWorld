UPDATE shop SET name=?, venue_id=?, category=?, address=?, 
                location=?, map_hint=?, passcode=?, enable_flag=?, 
