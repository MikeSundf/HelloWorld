SELECT
  id
  , user_id
  , type
  , manage_id 
FROM
  authority_info 
WHERE
  user_id = ?
ORDER BY
  id