INSERT INTO product(assortment_id, seq, egress_mode, congestion, cost, created_time, 
                    dwell_duration, access_duration, waiting_duration, travel_duration,
                    dep_time, arr_time)
                    VALUES(?, ?, ?, ?, ?, ?, 
                    ?, ?, ?, ?,
                    ?, ?)
