SELECT a.* FROM assortment a
INNER JOIN request r ON a.request_id=r.id
WHERE r.user_id=?
AND r.venue_id=?
AND r.from_location=? AND r.to_location=?
AND r.seats=?
AND ((r.created_time, r.created_time + INTERVAL '%d seconds') OVERLAPS (NOW(), NOW()))
AND a.selected_product IS NULL
ORDER BY r.created_time DESC
LIMIT 1