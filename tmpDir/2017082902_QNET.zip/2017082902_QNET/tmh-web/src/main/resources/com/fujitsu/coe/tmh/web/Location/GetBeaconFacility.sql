SELECT facility_type, facility_id
FROM beacon_facility
WHERE beacon_id=?