SELECT
  user_id
  , pref_key
  , pref_value 
FROM
  user_preference 