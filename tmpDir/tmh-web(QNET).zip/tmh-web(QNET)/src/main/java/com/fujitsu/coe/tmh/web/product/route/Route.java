package com.fujitsu.coe.tmh.web.product.route;

import java.util.List;

/**
 * Route result of the RouteFinder.
 * 
 * @author unicenfujitsu
 */
public interface Route {
    public double getFare();
    public List<? extends Step> getSteps();
}
