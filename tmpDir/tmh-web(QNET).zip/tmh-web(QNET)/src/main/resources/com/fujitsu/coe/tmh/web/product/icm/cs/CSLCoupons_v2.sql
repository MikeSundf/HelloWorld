SELECT
  uca.user_id
  , uca.coupon_id
  , COUNT(CASE WHEN (uca.activity_type = 0) THEN 1 END) recommended
  , COUNT(CASE WHEN (uca.activity_type = 1) THEN 1 END) viewed
  , COUNT(CASE WHEN (uca.activity_type = 2) THEN 1 END) chosen 
FROM
  user_coupon_activity uca 
WHERE
  uca.time >= ? 
  AND uca.time < ? 
GROUP BY
  uca.user_id
  , uca.coupon_id
