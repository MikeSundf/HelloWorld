SELECT
  user_id
  , gender
  , age_group
FROM
  user_profile 
