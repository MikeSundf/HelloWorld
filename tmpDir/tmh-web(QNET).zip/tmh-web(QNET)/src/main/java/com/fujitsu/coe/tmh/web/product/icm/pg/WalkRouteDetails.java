package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;

/**
 * Should the walking time of a WALK product be the "access time" or the "travel time"?
 * VoT is more appropriate when set on access time.
 * 
 * @author kychua
 */
public class WalkRouteDetails implements RouteDetails {

    private static final String WALK = "WALK";
    
    private double at;
    
    public WalkRouteDetails(Route route) {
        
        for (Step step : route.getSteps()) {
            if (WALK.equals(step.getVehicleType())) {
                at += step.getTime();
            }
        }
    }

    @Override
    public Egress.Mode getMode() {
        return Egress.Mode.WALK;
    }

    @Override
    public double getAccessTime() {
        return at;
    }

    @Override
    public double getTravelTime() {
        return 0;
    }

    @Override
    public double getWaitingTime(long stepTime, Step step) {
        return 0;
    }
    
}
