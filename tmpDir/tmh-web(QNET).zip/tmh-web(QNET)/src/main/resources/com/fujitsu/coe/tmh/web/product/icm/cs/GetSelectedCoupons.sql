SELECT c.id, s.name, c.title, c.description, s.address, s.location, s.map_hint, s.tel, c.terms, c.expiry_duration, (sl.id IS NOT NULL) AS has_banner, c.expected_dwell_time, s.category 
FROM coupon c 
INNER JOIN shop s ON c.shop_id=s.id 
LEFT JOIN shop_logo sl ON c.id=sl.id 
AND sl.type='COUPON' WHERE c.id IN %s
