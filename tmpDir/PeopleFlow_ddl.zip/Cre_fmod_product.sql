CREATE TABLE fmod_product
(
  id serial NOT NULL,
  icm_request_id character varying(86),
  icm_product_id integer,
  fmod_request_id character varying(86),
  fmod_product_id character varying(50),
  schedule_id character varying(50),
  pickup_time timestamp without time zone,
  dropoff_time timestamp without time zone,
  CONSTRAINT fmod_product_pkey PRIMARY KEY (id)
);
