
SELECT t1.user_id, t1.coupon_id, chosen, viewed, recommended FROM

(SELECT a.user_id, pc.coupon_id, COUNT(pc.id) recommended, COUNT(CASE WHEN (pc.redemption_time IS NOT NULL) THEN 1 END) chosen
FROM product_coupon pc
INNER JOIN product p ON pc.product_id = p.id
INNER JOIN assortment a ON p.assortment_id = a.id
WHERE p.created_time >= ?
  AND p.created_time <  ?
GROUP BY a.user_id, pc.coupon_id) AS t1

LEFT JOIN

(SELECT a.user_id, pc.coupon_id, COUNT(ual.object) viewed FROM user_action_log ual
INNER JOIN product_coupon pc ON ual.object::int = pc.id
INNER JOIN product p ON pc.product_id = p.id
INNER JOIN assortment a ON p.assortment_id = a.id AND ual.user_id=a.user_id
WHERE ual.action = 'OFFER_COUPON'
  AND p.created_time >= ?
  AND p.created_time <  ?
GROUP BY a.user_id, pc.coupon_id) AS t2

ON t1.user_id = t2.user_id AND t1.coupon_id = t2.coupon_id
ORDER BY t1.user_id