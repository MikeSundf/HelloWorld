package com.fujitsu.coe.tmh.web.UserManagement;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.util.logging.Logger;

/**
 * Populates user_action_log with the trail of the user actions for behavior analysis.
 * 
 * @author unicenfujitsu
 */
@RequestScoped
public class ActionLogger {
    
    @Inject
    private JdbcTemplate db;
    
    @Inject
    private User user;
    
    @Inject
    private HttpServletRequest req;

    private static final Logger LOGGER = Logger.getLogger(ActionLogger.class.getName());

    // 旧メソッド(user_idが取れないので使用不可)
    public void log(String action, String object, String data) throws SQLException {
        String deviceId = req.getHeader("X-DID");
        Long locationId = (Long)req.getAttribute("locationId");
        db.update("INSERT INTO user_action_log(device_id, user_id, location_id, action, object, data) VALUES(?, ?, ?, ?, ?, ?)", 
                deviceId, user.getId(), locationId, action, object, data);
    }

    // 新メソッド(STEP1からはこちらを使用)
    public void log(String user_id, String action, String object, String data) throws SQLException {
        String deviceId = req.getHeader("X-DID");
        Long locationId = (Long)req.getAttribute("locationId");
        try{
            db.update("INSERT INTO user_action_log(device_id, user_id, location_id, action, object, data) VALUES(?, ?, ?, ?, ?, ?)", 
                deviceId, user_id, locationId, action, object, data);
        } catch (SQLException sqle) {
            LOGGER.log(Level.INFO, null, sqle);
        }
    }
}
