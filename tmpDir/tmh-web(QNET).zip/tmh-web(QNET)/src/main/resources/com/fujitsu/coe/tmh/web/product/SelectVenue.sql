SELECT
  venue_id
  , name
  , lat
  , lon
  , enable_flag 
FROM
  venue 
WHERE
  venue_id = ?
ORDER BY
  venue_id
