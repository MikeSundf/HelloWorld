INSERT 
INTO shop( 
  name
  , venue_id
  , category
  , address
  , location
  , map_hint
  , passcode
  , enable_flag
