package com.fujitsu.coe.tmh.web.product.icm.log;

/**
 *
 * @author chuakayick
 */
public class ICMLogFormat {

    static void init() {
        ICMLogger.LogCategory.REQUEST.setFormat(String.join("\n",
                "[REQUEST]",
                "id\t%s",
                "clock\t%s",
                "now\t%s",
                "user\t%d",
                "venue\t%d",
                "from\t%s [%f,%f]",
                "to\t%s [%f,%f]",
                "hurry\t%d",
                "hungry\t%d",
                "seats\t%d",
                ""));

        ICMLogger.LogCategory.CACHE.setFormat(String.join("\n",
                "[CACHE]",
                "cache.secs\t%d",
                "cache.hit\t%s",
                ""));
        
        ICMLogger.LogCategory.TIMER.setFormat(String.join("\n",
                "",
                "[TIMER]%s",
                "",
                "[END OF REPORT]"));
        
        ICMLogger.LogCategory.CS_PROFILE.setFormat(String.join("\n",
                "[COUPON SELECTION]",
                "cs.likes\t%s",
                "cs.profile",
                "\tgender\t%s",
                "\tage\t%d",
                "\tincome\t%d",
                "cs.rate"));
        ICMLogger.LogCategory.CS_RATING.setFormat("\t%s\t%f");
        ICMLogger.LogCategory.CS_RANK1.setFormat(String.join("\n",
                "cs.rank",
                "\tc.id\ts.id\tcat\tshop\tcoupon\trating"));
        ICMLogger.LogCategory.CS_RANK2.setFormat("\t%d\t%d\t%s\t\t\t%f");
        
        ICMLogger.LogCategory.CS_SELECT1.setFormat(String.join("\n",
                "cs.select",
                "\tw\tf\tcid\tstatus\trating\trnd"));
        ICMLogger.LogCategory.CS_SELECT2.setFormat("\t%d\t%d\t%d\t%s\t%f\t%f");
        
        ICMLogger.LogCategory.PG.setFormat(String.join("\n",
                "",
                "[PRODUCT GENERATION]",
                "pg.cache.hit\t%s",
                "pg.response\t%s"));
        ICMLogger.LogCategory.PG_CONGESTION.setFormat(String.join("\n",
                "pg.congestion\t%s",
                "pg.routes"));
        ICMLogger.LogCategory.PG_ROUTE.setFormat(String.join("\n",
                "\t$%f",
                "\t\tstep\tmode\tservice\tlocation\tdetails\ttime\tlat\tlon"));
        ICMLogger.LogCategory.PG_STEP.setFormat("\t\t%d\t%s\t%s\t%s\t%s\t%s\t%f\t%f");
        ICMLogger.LogCategory.PG_PRODUCT1.setFormat(String.join("\n",
                "pg.products",
                "\tmode\tcg\tdt\tat\twt\ttt\tp-st\te-st\tdep\tarr"));
        ICMLogger.LogCategory.PG_PRODUCT2.setFormat(String.join("\n",
                "\t%s\t%d\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%s",
                "\t\tseq\tmode\ttt\twt"));
        ICMLogger.LogCategory.PG_PRODUCT3.setFormat("\t\t%d\t%s\t%s\t%s");
        
        ICMLogger.LogCategory.CA_EDT1.setFormat(String.join("\n",
                "",
                "[COUPON ASSIGNMENT]",
                "ca.edt",
                "\tcid\tcat\tshop\tcoupon\tedt"));
        ICMLogger.LogCategory.CA_EDT2.setFormat("\t%d\t%s\t%s\t%s\t%d");
        ICMLogger.LogCategory.CA_PRODUCT1.setFormat(String.join("\n",
                "ca.assign",
                "\tmode\tdt\tcount"));
        ICMLogger.LogCategory.CA_PRODUCT2.setFormat("\t%s\t%d\t%d");
        
        ICMLogger.LogCategory.PO_VOT.setFormat(String.join("\n",
                "",
                "[PRODUCT OPTIMIZATION]",
                "vot\tbeta_ivtt\tbeta_dt\tbeta_wt\tbeta_ovtt\tbeta_cg\tbeta_i\tasc_bus\tasc_mrt\tasc_staxi",
                "\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s"));
        ICMLogger.LogCategory.PO_HURRY.setFormat(String.join("\n",
                "hurry\t0\t1\t2\t3",
                "\t%s",
                "vot dt\t%f"));
        ICMLogger.LogCategory.PO_INPUT.setFormat(String.join("\n",
                "input\t%s",
                "output\tmode\tdt\tic"));
        ICMLogger.LogCategory.PO_OUTPUT.setFormat("\t%s\t%d\t%s");
        
        ICMLogger.LogCategory.PR.setFormat(String.join("\n",
                "",
                "[PRODUCT REFINEMENT]",
                "products\tmode\tdt\tnew dt"));
        ICMLogger.LogCategory.PR_DT.setFormat("\t%s\t%d\t%d");
        
        // TODO@KY: not enough time to build formats properly, but need logs
        ICMLogger.LogCategory.XXX.setFormat("%s");
    }

}
