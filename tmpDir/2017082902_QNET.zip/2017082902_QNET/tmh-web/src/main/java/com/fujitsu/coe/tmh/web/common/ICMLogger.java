package com.fujitsu.coe.tmh.web.common;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;

/**
 *
 * @author chuakayick
 */
public class ICMLogger {

    public enum LogCategory {

        REQUEST,
        CACHE,
        CS_PROFILE, CS_RATING, CS_RANK1, CS_RANK2, CS_SELECT1, CS_SELECT2,
        PG, PG_CONGESTION, PG_ROUTE, PG_STEP, PG_PRODUCT1, PG_PRODUCT2, PG_PRODUCT3,
        CA_EDT1, CA_EDT2, CA_PRODUCT1, CA_PRODUCT2,
        PO_VOT, PO_HURRY, PO_INPUT, PO_OUTPUT,
        PR, PR_DT,
        TIMER,
        XXX,
        CLOSE;   // flag to end the logger

        private String format;

        void setFormat(String format) {
            this.format = format;
        }

        String format(Object... params) {
            return String.format(format, params);
        }
    }

    static {
        ICMLogFormat.init();
    }
    private PrintWriter out;

    public ICMLogger(String logPath, String requestId) throws IOException {
        new File(logPath).mkdirs();
        out = new PrintWriter(new FileWriter(Paths.get(logPath, String.format("%s.txt", requestId)).toFile()));
    }

    public void log(LogCategory type, Object... params) {
        switch (type) {
            case CLOSE:
                out.close();
                out = null;
                break;
            default:
                out.println(type.format(params));
                out.flush();    // ensure written to file before any crash
                break;
        }
    }

}
