CREATE TABLE shop_logo
(
  shop_id integer NOT NULL,
  logo bytea,
  CONSTRAINT "shopFK" FOREIGN KEY (shop_id)
      REFERENCES shop (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
