SELECT
  type 
FROM
  user_info 
WHERE
  user_id = ?