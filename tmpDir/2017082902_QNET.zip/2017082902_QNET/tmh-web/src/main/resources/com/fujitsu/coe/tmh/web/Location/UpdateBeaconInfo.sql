UPDATE beacon_info
SET venue_id=?, lat=?, lon=?
WHERE beacon_id=?