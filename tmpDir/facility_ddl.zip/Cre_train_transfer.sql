CREATE TABLE train_transfer
(
  id serial NOT NULL,
  station_id integer,
  station_name character varying(50),
  line_from character varying(50),
  line_to character varying(50),
  access_duration integer,
  CONSTRAINT train_transfer_pkey PRIMARY KEY (id),
  CONSTRAINT "stationFK" FOREIGN KEY (station_id)
      REFERENCES train_station (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT train_transfer_station_id_line_from_line_to_key UNIQUE (station_id, line_from, line_to)
);
