package com.fujitsu.coe.tmh.web.product.route;

import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.route.sd.SDRouteFinder;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Finds egress routes from point A to B. Current implementation using SD.com
 *
 * @author unicenfujitsu
 */
public class RouteFinder {

    private ICMContext ctx;
    
    public RouteFinder(ICMContext ctx) {
        this.ctx = ctx;
    }
    
    /**
     * Returns a list of routes for multiple transport modes from the starting
     * to ending point.
     *
     * @param from starting point
     * @param to ending point
     * @return list of feasible routes
     * @throws IOException
     * @throws SQLException
     */
    public List<? extends Route> route(String from, String to) throws IOException, SQLException {
        // only one RouteFinder by SD now. Expecting maybe gothere.sg or JP RouteFinder in future.
        return new SDRouteFinder(ctx).route(from, to);  
    }
}
