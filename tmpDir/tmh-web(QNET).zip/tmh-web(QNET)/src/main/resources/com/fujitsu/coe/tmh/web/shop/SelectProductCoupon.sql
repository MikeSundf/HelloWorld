SELECT
  user_id
  , shop_id
  , coupon_id
  , redemption_time 
FROM
  product_coupon 
WHERE
  shop_id = ? 
ORDER BY
  user_id
  , coupon_id
  , redemption_time; 