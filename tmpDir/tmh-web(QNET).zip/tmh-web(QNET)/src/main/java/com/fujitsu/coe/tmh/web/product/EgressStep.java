package com.fujitsu.coe.tmh.web.product;


/**
 * Represents each step of an egress method.
 * 
 * @author ky
 */
public class EgressStep {
    private int seq;
    private String mode;
    private String service;
    private String location;
    private String details;
    private long time;  // duration of this step (ms)
    private long waitTime;  // waiting time for this step (ms)
    private double lat;
    private double lon;

    public EgressStep(int seq, String mode, String service, String location, String details, long time, long waitTime, double lat, double lon) {
        this.seq = seq;
        this.mode = mode;
        this.service = service;
        this.location = location;
        this.details = details;
        this.time = time;
        this.waitTime = waitTime;
        this.lat = lat;
        this.lon = lon;
    }

    public int getSeq() {
        return seq;
    }

    public String getMode() {
        return mode;
    }

    public String getService() {
        return service;
    }

    public String getLocation() {
        return location;
    }

    public String getDetails() {
        return details;
    }

    public long getTime() {
        return time;
    }

    public long getWaitTime() {
        return waitTime;
    }

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }
}
