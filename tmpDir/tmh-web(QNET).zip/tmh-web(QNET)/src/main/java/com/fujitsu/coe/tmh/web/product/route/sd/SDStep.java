package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * JSON model for root.taxi.is.j, root.bustrain.is and root.bus.is;
 * 
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDStep {
    
    private String title; // tt
    private String description; // dc
    private int index; // i
    private String busNumber; // bn
    private String svc; // sv
    private String vehicleType; // vt
    private boolean available; // av
    private String time; // st
    private String timeString; // t
    private String distance; // sd
    private String distanceString; // u
    
    private double lat; // y
    private double lon; // x;
    
    public SDStep() {
    }
    
    public void setI(int index) {
        this.index = index;
    }

    public void setTt(String title) {
        this.title = title;
    }

    public void setDc(String description) {
        this.description = description;
    }

    public void setBn(String busNumber) {
        this.busNumber = busNumber;
    }

    public void setSv(String svc) {
        this.svc = svc;
    }

    public void setVt(String vehicleType) {
        this.vehicleType = vehicleType.toUpperCase();
    }

    // sometimes this value is "1" instead of true/false
    public void setAv(String available) {
        this.available = "1".equals(available) || "true".equals(available);
    }

    public void setSt(String time) {
        this.time = time;
    }

    public void setT(String timeString) {
        this.timeString = timeString;
    }

    public void setSd(String distance) {
        this.distance = distance;
    }

    public void setU(String distanceString) {
        this.distanceString = distanceString;
    }
    
    public void setX(double lon) {
        this.lon = lon;
    }
    
    public void setY(double lat) {
        this.lat = lat;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getTimeString() {
        return timeString;
    }

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }

    public String getDescription() {
        return description;
    }
    
    public String getTime() {
        return time;
    }

    public String getTitle() {
        return title;
    }
    
    
}
