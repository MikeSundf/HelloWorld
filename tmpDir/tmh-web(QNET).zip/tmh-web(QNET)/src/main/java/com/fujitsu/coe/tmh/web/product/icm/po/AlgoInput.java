package com.fujitsu.coe.tmh.web.product.icm.po;

import java.util.List;

/**
 *
 * @author unicenfujitsu
 */
class AlgoInput {
    private AlgoUser user;
    private List<AlgoProduct> products;

    public AlgoInput(AlgoUser user, List<AlgoProduct> products) {
        this.user = user;
        this.products = products;
    }
    
    public AlgoUser getUser() {
        return user;
    }

    public List<AlgoProduct> getProducts() {
        return products;
    }
    
}
