package com.fujitsu.coe.tmh.web.product.icm.pg.fmod;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.icm.FmodDAO;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.pg.PGUtil;
import com.fujitsu.coe.tmh.web.util.Location;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kychua
 */
// TODO this class probably shouldn't be inside PG, since it involves product selection also. need to rearrange the class dependencies later.
public class FMODGateway {
    
    private static final Logger LOGGER = Logger.getLogger(FMODGateway.class.getName());
    private static final TypeReference<HashMap<String,Object>> MAP_TYPE = new TypeReference<HashMap<String,Object>>() {};
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    static {
        TIME_FORMAT.setTimeZone(TimeZone.getTimeZone("UTC"));
    }
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final String API_REGISTER = "registrationuser";
    private static final String API_REQUEST = "request";
    private static final String API_CONFIRM = "message";
    private static final String API_RESERVATION = "reservation";
    
    private ICMContext ctx;
    
    public FMODGateway(ICMContext ctx) {
        this.ctx = ctx;
    }

    public boolean register() throws IOException, SQLException {
        Map<String, Object> params = MapBuilder.create("sex", 0)
                .put("client_id", String.valueOf(ctx.user.getId()))
                .put("client_name", String.valueOf(ctx.user.getId()))
                .build();
        String url = String.format("%s/%s/?message=%s", 
                ctx.settings.get("fmod.endpoint"), API_REGISTER, encode(params));
        LOGGER.log(Level.INFO, "fmod/url {0}", url);
        String response = PGUtil.curl(url);
        LOGGER.log(Level.INFO, "fmod/response {0}", response);
        Map<String, Object> result = decode(response);
        return String.valueOf(result.get("code")).equals("000000");
    }
    
    public List<FMODProduct> request(Location origin, Location dest, int seats) throws IOException, SQLException {
        Map<String, Object> params = MapBuilder.create("client_id", String.valueOf(ctx.user.getId()))
                .put("origin_latitude", origin.getLat())
                .put("origin_longitude", origin.getLon())
                .put("destination_latitude", dest.getLat())
                .put("destination_longitude", dest.getLon())
                .put("departure_time_early", format(ctx.clock.now()))
                // as advised by Ikeda-san's email, dep-time-late should be same as early
                // .put("departure_time_late", format(add(ctx.clock.now(), 120)))
                .put("departure_time_late", format(ctx.clock.now()))
                .put("seat_num", seats)
                .put("same_sex_flag", "0")
                .put("optimization", "no")
                .put("arrival_time_early", "-1")
                .put("arrival_time_late", "-1")
                .put("current_time", format(ctx.clock.now()))
                .build();
        String url = String.format("%s/%s/?cid=%s&message=4,%s", 
                ctx.settings.get("fmod.endpoint"), API_REQUEST, ctx.user.getId(), encode(params));
        LOGGER.log(Level.INFO, "fmod/url {0}", url);
        String response = PGUtil.curl(url);
        LOGGER.log(Level.INFO, "fmod/response {0}", response);
        Map<String, Object> result = decode(response);
        if (!String.valueOf(result.get("code")).equals("000000")) {
            return null;
        }
        
        String requestId = String.valueOf(result.get("request_id"));
        List<Map<String,Object>> offers = (List<Map<String,Object>>)result.get("offer");
        List<FMODProduct> products = new ArrayList<>();
        FmodDAO dao = new FmodDAO(ctx.db);
        for (Map<String,Object> offer: offers) {
            FMODProduct product = new FMODProduct();
            product.setRequestId(requestId);
            product.setScheduleId(String.valueOf(offer.get("schedule_id")));
            product.setProductId(String.valueOf(offer.get("product_id")));
            product.setChoiceProbability((double)offer.get("choice_probability"));
            product.setServiceType((double)offer.get("service_type"));
            product.setPassengerNum((double)offer.get("passenger_num"));
            product.setFare((double)offer.get("fare"));
            product.setTravelDistance((double)offer.get("travel_distance"));
            product.setTravelTime((double)offer.get("travel_time"));
            product.setPickup(new Location((double)offer.get("pickup_latitude"), (double)offer.get("pickup_longitude")));
            product.setPickupEarly(parse(String.valueOf(offer.get("pickup_time_early"))));
            product.setPickupLate(parse(String.valueOf(offer.get("pickup_time_late"))));
            product.setDropoff(new Location((double)offer.get("dropoff_latitude"), (double)offer.get("dropoff_longitude")));
            product.setDropoffEarly(parse(String.valueOf(offer.get("dropoff_time_early"))));
            product.setDropoffLate(parse(String.valueOf(offer.get("dropoff_time_late"))));
            products.add(product);
            dao.insert(ctx.reqId, product);
        }
        return products;
    }
    
    public boolean confirm(long productId) throws IOException, SQLException {
        FmodDAO dao = new FmodDAO(ctx.db);
        FMODProduct product = dao.getFMODProduct(productId);

        // send confirm request
        Map<String, Object> accept = MapBuilder.create("product_id", product.getProductId())
                .put("schedule_id", product.getScheduleId())
                .put("pickup_time", format(product.getPickupEarly()))
                .put("dropoff_time", format(product.getDropoffEarly()))
                .build();
        
        Map<String, Object> params = MapBuilder.create("client_id", String.valueOf(ctx.user.getId()))
                .put("request_id", product.getRequestId())
                .put("current_time", format(ctx.clock.now()))
                .put("accept", accept)
                .build();
        String url = String.format("%s/%s/?cid=%s&message=6,%s", 
                ctx.settings.get("fmod.endpoint"), API_CONFIRM, ctx.user.getId(), encode(params));
        LOGGER.log(Level.INFO, "fmod/url {0}", url);
        String response = PGUtil.curl(url);
        LOGGER.log(Level.INFO, "fmod/response {0}", response);
        Map<String, Object> result = decode(response);
        if (!String.valueOf(result.get("code")).equals("000000")) {
            return false;
        }
        
        // extract vehicle assigned
        params = MapBuilder.create("client_id", String.valueOf(ctx.user.getId()))
                .put("client_id", String.valueOf(ctx.user.getId()))
                .put("current_time", format(ctx.clock.now()))
                .build();
        url = String.format("%s/%s/?cid=%s&message=95,%s", 
                ctx.settings.get("fmod.endpoint"), API_RESERVATION, ctx.user.getId(), encode(params));
        LOGGER.log(Level.INFO, "fmod/url {0}", url);
        response = PGUtil.curl(url);
        LOGGER.log(Level.INFO, "fmod/response {0}", response);
        result = decode(response);
        if (!String.valueOf(result.get("code")).equals("000000")) {
            return false;
        }
        
        // TODO: KY for now assume last reservation is the latest. To be correct, can match schedule_id from confirmation response
        // TODO: if exception is thrown here, FMOD remains reserved but ICM will rollback.
        List<Map<String, Object>> reservations = (List<Map<String, Object>>) result.get("reservations");
        if (reservations.isEmpty()) {
            throw new IllegalStateException("reservations.isEmpty()");  // where is my reservation
        }
        Map<String,Object> reservation = reservations.get(reservations.size() - 1);
        String vId = reservation.get("vehicle_id").toString();
        int seats = (int)Double.parseDouble(reservation.get("seat_num").toString());
        
        int updated = ctx.db.update("UPDATE product_egress SET details=? WHERE product_id=? AND step=2 AND mode='STAXI'", 
                String.format("%d%d%03d", seats, ctx.user.getId(), Integer.parseInt(vId)), productId);
        if (updated != 1) {
            throw new IllegalStateException("updated!=1");  // where is my product_egress
        }
                
        return true;
    }
    
    private String encode(Map<String, Object> params) throws IOException {
        try {
            return URLEncoder.encode(MAPPER.writeValueAsString(params), "UTF-8");
        } catch (JsonProcessingException | UnsupportedEncodingException ex) {
            throw new IOException(ex);
        }
    }
    
    private Map<String, Object> decode(String response) throws IOException {
        return MAPPER.readValue(response, MAP_TYPE);
    }
    
    private Date add(Date date, int mins) {
        return new Date(date.getTime() + TimeUnit.MINUTES.toMillis(mins));
    }
    
    private String format(Date date) {
        return TIME_FORMAT.format(new java.util.Date(date.getTime()));
    }
    
    private Date parse(String dateStr) throws IOException {
        try {
            return new Date(TIME_FORMAT.parse(dateStr));
        } catch (ParseException ex) {
            throw new IOException(ex);
        }
    }
}
