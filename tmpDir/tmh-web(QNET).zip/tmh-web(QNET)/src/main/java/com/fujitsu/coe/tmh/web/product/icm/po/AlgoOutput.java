package com.fujitsu.coe.tmh.web.product.icm.po;

/**
 *
 * @author unicenfujitsu
 */
class AlgoOutput {
    private int product;
    private int incentive;

    public int getIndex() {
        return product;
    }

    public boolean isIncentive() {
        return incentive == 1;
    }

    public void setProduct(int product) {
        this.product = product;
    }

    public void setIncentive(int incentive) {
        this.incentive = incentive;
    }
    
}
