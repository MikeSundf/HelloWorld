package com.fujitsu.coe.tmh.web.UserManagement;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.tmh.web.CouponDistribution.LaunchService;
import com.fujitsu.coe.tmh.web.common.ErrorFactory;
import com.fujitsu.coe.tmh.web.common.MapBuilder;
import com.fujitsu.coe.tmh.web.common.SystemSettings;
import static com.fujitsu.coe.tmh.web.common.TimeUtil.toTS;
import com.fujitsu.coe.tmh.web.common.AdminType;
import com.fujitsu.coe.tmh.web.common.ValidationCheck;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.jasypt.util.password.StrongPasswordEncryptor;
import com.fujitsu.coe.tmh.web.common.LogManage;
import static com.fujitsu.coe.tmh.web.common.ParamConstants.*;
import com.fujitsu.coe.tmh.web.common.SysClock;
import static com.fujitsu.coe.tmh.web.common.ValidationCheck.*;
import java.util.LinkedHashMap;

/**
 * Authentication service - login/logout.
 * 
 * @author ky
 */
@Path("/")
@ApplicationScoped
public class AuthService {

    String classname = AuthService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    private transient HttpSession session;
    @Inject
    private SysClock clock;
    @Inject
    private SystemSettings settings;
    @Inject
    private ActionLogger aLogger;
    @Inject
    private LaunchService launchService;
    private final StrongPasswordEncryptor encryptor;
    @Inject
    private LogManage logger;
    @Inject
    private AdminType adminUtil;

    public AuthService() {
        encryptor = new StrongPasswordEncryptor();
    }

    /**
     * ログイン
     * @param user_id
     * @param password
     * @return
     * @throws SQLException 
     * @author Qnet)gotoh
     */
    @POST
    @Path("/login")
    @Produces(MediaType.APPLICATION_JSON)
    public Map login(
            @FormParam("user_id") String user_id,
            final @FormParam("password") String password) throws SQLException {
        aLogger.log(user_id, "LOGIN", user_id, String.format("[user_id=%s]", user_id));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", password=" + password + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("") || password == null || password.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // user_idはユーザIDなのかメールアドレスなのか
        String email;
        if(!(ValidationCheck.checkEmail(user_id, LOG_OUTPUT_OFF))){
            // ユーザIDの場合
            if(!(ValidationCheck.checkUserId(user_id))){
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
            // メールアドレス取得
            long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?",user_id);
            if(recoredCount == 0){
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
                return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
            }
            email = db.queryForString("SELECT email FROM user_info WHERE user_id=?", user_id);
        }else{
            // メールアドレスの場合
            email = user_id;
            long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE email=?",email);
            if(recoredCount == 0){
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
                return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
            }
            // ユーザID取得
            user_id = db.queryForString("SELECT user_id FROM user_info WHERE email=?", email);
        }

        // バリデーションチェック
        if(!(ValidationCheck.checkPassword(password))){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }    

        // 種別取得
        long regcnt = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?", user_id);
        if(regcnt == 0){
            logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
            return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
        }
        int type = adminUtil.getUserType(user_id);

        // 権限確認
        if(type != USER_INFO_TYPE_USER){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        
        // システムセッティングの"login.disabled"がtrueか？
        if (Boolean.valueOf(settings.get("login.disabled", "false"))) {
            logger.log(Level.WARNING, classname, methodName, DISABLED_LOGIN_MSG);
            return ErrorFactory.createError(DISABLED_LOGIN_CODE, DISABLED_LOGIN_MSG);
        }
        
        // 現在時刻よりサスペンド時刻の方が大きいか？
        if(isSuspended(email)){
            logger.log(Level.WARNING, classname, methodName, SUSPENDED_ACCOUNT_MSG);
            return ErrorFactory.createError(SUSPENDED_ACCOUNT_CODE, SUSPENDED_ACCOUNT_MSG);
        }

        // パスワードが一致するか？
        String password_db = db.queryForString("SELECT password FROM user_info WHERE email=?", email);
        if (password.equals(password_db)) {
            // 最終ログイン時刻を更新
            try{
                db.update("UPDATE user_info SET last_login_time=? WHERE email=?", toTS(clock.now()), email);
                logger.log(Level.FINE, classname, methodName, "UPDATE user_info:[last_login_time]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
                return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.build("ok", true);
        } else {
            checkSuspension(user_id);
            logger.log(Level.WARNING, classname, methodName, INVALID_USERNAME_MSG);
            return ErrorFactory.createError(INVALID_USERNAME_CODE, INVALID_USERNAME_MSG);
        }   
    }

    private boolean isSuspended(String email) throws SQLException {
        return (db.queryForLong("SELECT COUNT(*) FROM user_info WHERE email=? AND suspended_until > NOW()", email) > 0);
    }
    
    private void checkSuspension(String user_id) throws SQLException {
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();

        try{
            db.update("INSERT INTO user_login_failure(user_id) VALUES(?)", user_id);
            logger.log(Level.FINE, classname, methodName, "INSERT user_login_failure:[user_id=" + user_id + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
        }
        
        // default: if there are 3 failed attempts in the last 10 mins, suspend for 30 mins.
        String[] lfSettings = settings.get("login.failure", "3/10/30").split("/");
        int failSetting = Integer.parseInt(lfSettings[0]);
        int lastMins = Integer.parseInt(lfSettings[1]);
        int suspendFor = Integer.parseInt(lfSettings[2]);
        if (failSetting == 0) { // disable auto account suspension
            return;
        }
        // count failed logins in past x minutes
        long failCount = db.queryForLong("SELECT COUNT(*) FROM user_login_failure WHERE user_id=? AND created_time > (NOW() - (? * INTERVAL '1 MINUTE'))", user_id, lastMins);
        // if exceed y, suspend for z minutes
        if (failCount >= failSetting) {
            try{
                db.update("UPDATE user_info SET suspended_until=(NOW() + (? * INTERVAL '1 MINUTE')) WHERE user_id=?", suspendFor, user_id);
                logger.log(Level.FINE, classname, methodName, "UPDATE user_info:[suspended_until]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
            }
            aLogger.log("SUSPEND", user_id, String.format("[settings=%d/%d/%d]", failSetting, lastMins, suspendFor));
        }
    }

    /**
     * ログアウト
     * @param user_id
     * @return
     * @throws SQLException 
     * @author Qnet)gotoh
     */
    @GET
    @Path("/logout")
    @Produces(MediaType.APPLICATION_JSON)
    public Map logout(@QueryParam("user_id") String user_id) throws SQLException {
        aLogger.log(user_id, "LOGOUT", null, null);
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(user_id))){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }


    @GET
    @Path("/encrypt")
    @Produces(MediaType.TEXT_PLAIN)
    public String encryptPassword(@QueryParam("p") String plain) {
        return encryptor.encryptPassword(plain);
    }

    @GET
    @Path("/status")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> status() {
        return MapBuilder.create("mode", clock.getMode())
                .put("now", new java.util.Date(clock.now().getTime()).toString())
                .build();
    }
    
    /**
     * Just a method for H&H screen (and future screens to ping for login and
     * trigger a 403 on the app if necessary.
     *
     * @return ok:true if is logged in
     * @throws SQLException
     */
    @GET
    @Path("/ping")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> ping() throws SQLException {
        return MapBuilder.build("ok", true);
    }

    /**
     * 管理者登録
     * @param user_id
     * @param password
     * @return
     * @throws SQLException 
     * @author Qnet)gotoh
     */
    @POST
    @Path("/operator_login")
    @Produces(MediaType.APPLICATION_JSON)
    public Map loginOperator(
            @FormParam("user_id") String user_id,
            final @FormParam("password") String password) throws SQLException {
        aLogger.log(user_id, "LOGIN", user_id, String.format("[user_id=%s]", user_id));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", password=" + password + "]");

        Map<String,List<Map<String,Object>>> response = new LinkedHashMap<>();
        if(response == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("") || password == null || password.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // user_idはユーザIDなのかメールアドレスなのか
        String email;
        if(!(ValidationCheck.checkEmail(user_id, LOG_OUTPUT_OFF))){
            // ユーザIDの場合
            if(!(ValidationCheck.checkUserId(user_id))){
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
            // メールアドレス取得
            long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?",user_id);
            if(recoredCount == 0){
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
                return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
            }
            email = db.queryForString("SELECT email FROM user_info WHERE user_id=?", user_id);
        }else{
            // メールアドレスの場合
            email = user_id;
            long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE email=?",email);
            if(recoredCount == 0){
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
                return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
            }
            // ユーザID取得
            user_id = db.queryForString("SELECT user_id FROM user_info WHERE email=?", email);
        }
        
        // バリデーションチェック
        if(!(ValidationCheck.checkPassword(password))){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }    
        
        // システムセッティングの"login.disabled"がtrueか？
        if (Boolean.valueOf(settings.get("login.disabled", "false"))) {
            logger.log(Level.WARNING, classname, methodName, DISABLED_LOGIN_MSG);
            return ErrorFactory.createError(DISABLED_LOGIN_CODE, DISABLED_LOGIN_MSG);
        }
        
        // 現在時刻よりサスペンド時刻の方が大きいか？
        if(isSuspended(email)){
            logger.log(Level.WARNING, classname, methodName, SUSPENDED_ACCOUNT_MSG);
            return ErrorFactory.createError(SUSPENDED_ACCOUNT_CODE, SUSPENDED_ACCOUNT_MSG);
        }

        // 管理者種別取得
        int type = adminUtil.getUserType(user_id);
        
        // 管理者種別はシステム管理者、開催地管理者、店舗管理者以外か？
        if(type != USER_INFO_TYPE_SYSTEM &&
           type != USER_INFO_TYPE_VENUE &&
           type != USER_INFO_TYPE_SHOP ){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }

        // 管理配下のものがあるか？
        List<Integer> venue_list = new ArrayList<>();
        List<Integer> shop_list = new ArrayList<>();
        boolean venue_manage_flag = false;
        boolean shop_manage_flag = false;
        List<Map<String,Object>> list = new ArrayList<>();
        response.put("venue_shop", list);
        if(type == USER_INFO_TYPE_VENUE){
            // 開催地管理者の場合
            // 管理配下の開催地リスト取得
            db.query("SELECT manage_id FROM authority_info WHERE user_id=?", (rs) -> {
                Map<String,Object> data = new LinkedHashMap<>();
                venue_list.add(Integer.parseInt(rs.getString(1)));
                data.put("venue_id", Integer.parseInt(rs.getString(1)));
                list.add(data);
            }, user_id);            

            // 管理配下の開催地リストで有効な開催地を引く
            for(int i=0; i < venue_list.size(); i++){
                long recoredCount = db.queryForLong("SELECT COUNT(*) FROM venue WHERE venue_id=? AND enable_flag=TRUE",venue_list.get(i));
                if(recoredCount > 0){
                    // 管理配下のものがあった
                    venue_manage_flag = true;
                    break;
                }
            }
            // 管理配下のものがない場合ログインさせない
            if(!venue_manage_flag){
                logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } else if(type == USER_INFO_TYPE_SHOP){
            // 店舗管理者の場合
            // 管理配下の店舗リスト取得
            db.query("SELECT manage_id FROM authority_info WHERE user_id=?", (rs) -> {
                Map<String,Object> data = new LinkedHashMap<>();
                shop_list.add(Integer.parseInt(rs.getString(1)));
                data.put("shop_id", Integer.parseInt(rs.getString(1)));
                list.add(data);
            }, user_id);            

            // 管理配下の店舗リストで有効な店舗を引く
            for(int i=0; i < shop_list.size(); i++){
                long recoredCount = db.queryForLong("SELECT COUNT(*) FROM shop WHERE shop_id=? AND enable_flag=TRUE",shop_list.get(i));
                if(recoredCount > 0){
                    // 管理配下のものがあった
                    shop_manage_flag = true;
                    break;
                }
            }
            // 管理配下のものがない場合ログインさせない
            if(!shop_manage_flag){
                logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        }

        // パスワードが一致するか？
        String password_db = db.queryForString("SELECT password FROM user_info WHERE email=?", email);
        if (password.equals(password_db)) {
            // 最終ログイン時刻を更新
            try{
                db.update("UPDATE user_info SET last_login_time=? WHERE email=?", toTS(clock.now()), email);
                logger.log(Level.FINE, classname, methodName, "UPDATE user_info:[last_login_time]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
                return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
            logger.log(Level.FINE, classname, methodName, "END");
            if(type == USER_INFO_TYPE_SYSTEM){
                return MapBuilder.build("ok", true);
            } else {
                return response;
            }
        } else {
            checkSuspension(user_id);
            logger.log(Level.WARNING, classname, methodName, INVALID_USERNAME_MSG);
            return ErrorFactory.createError(INVALID_USERNAME_CODE, INVALID_USERNAME_MSG);
        }
    }    
   
    /**
     * ユーザリスト取得
     * @param admin_id
     * @return
     * @throws SQLException 
     * @author Qnet)gotoh
     */
    @GET
    @Path("/user_list")
    @Produces(MediaType.APPLICATION_JSON)
    public Map getUserList(
            @QueryParam("admin_id") String admin_id) throws SQLException {

        aLogger.log(admin_id, "GETUSERLIST", admin_id, String.format("[admin_id=%s]", admin_id));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + admin_id + "]");
        
        // リスト生成
        Map<String,List<Map<String,Object>>> response = new LinkedHashMap<>();
        if(response == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // 必須パラメータチェック
        if (admin_id == null || admin_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(admin_id))){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 種別取得
        int admin_type = adminUtil.getUserType(admin_id);
        // 開催地管理者以上か？
        if (admin_type != USER_INFO_TYPE_SYSTEM &&
            admin_type != USER_INFO_TYPE_VENUE){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        
        // 最大ユーザリスト取得数
        int getuserlist_max_int = Integer.parseInt(settings.get("maxnum.getuserlist", DB_DEFAULT_MAX_NUM));
        
        // データベース参照
        long ListCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE type=?", USER_INFO_TYPE_USER);
        
        // 登録数は最大ユーザリスト取得数より大きいか？
        if (getuserlist_max_int < ListCount) {
            logger.log(Level.WARNING, classname, methodName, LIMIT_GET_MSG);
            return ErrorFactory.createError(LIMIT_GET_CODE, LIMIT_GET_MSG);
        }

        // ユーザリスト取得
        List<Map<String,Object>> list = new ArrayList<>();
        response.put("user_list", list);
        db.query("SELECT user_id FROM user_info WHERE type=?", (rs_user) -> {
            Map<String,Object> data = new LinkedHashMap<>();
            String user_id = rs_user.getString(1);
            db.query("SELECT age_group, gender FROM user_profile WHERE user_id=?", (rs) -> {
                data.put("user_id", user_id);
                data.put("ageGroup", rs.getString(1));
                data.put("gender", rs.getString(2));
                db.query("SELECT pref_key, pref_value FROM user_preference WHERE user_id=?", (rs_upr) -> {
                    data.put(rs_upr.getString(1), rs_upr.getString(2));
                },user_id); 
            }, user_id);
            list.add(data);
        }, USER_INFO_TYPE_USER);
        logger.log(Level.FINE, classname, methodName, "END");
        return response;
    }
}
