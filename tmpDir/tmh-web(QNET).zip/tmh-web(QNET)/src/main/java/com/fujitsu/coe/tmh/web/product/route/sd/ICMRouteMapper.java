package com.fujitsu.coe.tmh.web.product.route.sd;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts SD.com route to ICM route.
 * This class is stateful and thus not thread-safe.
 * 
 * @author kychua
 */
public class ICMRouteMapper {

    // 17 min, 1 h 4 m
    private static final Pattern TRAVEL_TIME_PATTERN = Pattern.compile("((\\d+)\\sh\\s)?(\\d+)\\sm\\w*");
    // Walk towards Promenade (CC4).
    private static final Pattern WALK_TO_TRAIN_PATTERN = Pattern.compile("Walk (towards|to) (.+)\\s\\(.*");
    // Walk to Bus Stop @ Telok Blangah Rd, vivocity (B14141)
    private static final Pattern WALK_TO_BUS_PATTERN = Pattern.compile("Walk (towards|to) Bus Stop @ (.+?)\\. \\(B(.+?)\\).*");
    // Walk to End.
    private static final Pattern WALK_TO_END_PATTERN = Pattern.compile("Walk to End\\.");
    // Circle Line at Promenade (CC4)
    private static final Pattern TRAIN_STATION_PATTERN = Pattern.compile("(.+?) at (.+?) \\(.*");
    // Board the train towards Dhoby Ghaut, 3 stops later alight at Dhobby Ghaut (NS24 / NE6 / CC1).
    private static final Pattern TRAIN_DIRECTION_PATTERN = Pattern.compile("Board the train towards (.+?),.*");
    // Take Bus RWS8 (B14141)
    private static final Pattern BUS_NUM_PATTERN = Pattern.compile("Take Bus (.+?) \\(B(.+?)\\)");
    // 2 Stops later alight at Telok Blangah Road, bef Seah Im Road. (B14139)
    private static final Pattern BUS_ALIGHT_PATTERN = Pattern.compile("\\d+ Stops later alight at (.+?)\\. \\(B(.+?)\\)");
    // Board the train towards Harbour Front, 4 stops later alight at HarbourFront (NE1 / CC29).
    private static final Pattern TRAIN_ALIGHT_PATTERN = Pattern.compile(".* stops later alight at (.+?) \\(.*");

    private List<ICMRoute> routes;
    private SDDictionary dictionary;
    
    public ICMRouteMapper() {
        routes = new ArrayList<>();
        dictionary = new SDDictionary();
    }
    
    public List<ICMRoute> map(SDRouteResults results) {
        if (!results.hasRoutes()) {
            return routes;
        }
        // TODO potentially parallelizable, with ArrayList sync access
        process(results.getBus(), results.getEnd());
        process(results.getBustrain(), results.getEnd());
        processTaxi(results);
        return routes;
    }
    
    // TODO method too long, may need to break for maintainability
    private void process(SDBusTrainRoute route, SDStartEnd end) {
        ICMRoute icmRoute = new ICMRoute(Double.parseDouble(route.getTotal().getCost()));
        List<SDStep> steps = route.getSteps();
        if (steps.isEmpty()) {
            return;
        }
        end.setDc(end.getDescription().replace(". ", ", "));
        for (int i = 0; i < steps.size(); i++) {
            SDStep step = steps.get(i);
            if ("WALKING".equals(step.getVehicleType())) {
                // the first walk step doesn't have lat/lon, it's OK. later ICM will rewrite it to user's current location
                ICMStep icmStep = new ICMStep("WALK", step.getLat(), step.getLon(), Double.parseDouble(step.getTime()));
                
                // process alighting
                String location = null;
                String details = null;
                if (i > 0) {
                    SDStep prev = steps.get(i - 1);
                    if ("BUS".equals(prev.getVehicleType())) {
                        Matcher matcher = BUS_ALIGHT_PATTERN.matcher(prev.getDescription());
                        if (matcher.matches()) {
                            location = dictionary.fixLocation(matcher.group(1));
                            details = matcher.group(2);
                        }
                    } else if ("TRAIN".equals(prev.getVehicleType())) {
                        Matcher matcher = TRAIN_ALIGHT_PATTERN.matcher(prev.getDescription());
                        if (matcher.matches()) {
                            location = matcher.group(1);
                        }
                    }
                }
                
                // walk to next step
                Matcher busMatcher = WALK_TO_BUS_PATTERN.matcher(step.getDescription());
                Matcher trainMatcher = WALK_TO_TRAIN_PATTERN.matcher(step.getDescription());
                Matcher endMatcher = WALK_TO_END_PATTERN.matcher(step.getDescription());
                if (busMatcher.matches()) {
                    icmStep.setInstruction(dictionary.fixLocation(busMatcher.group(2)), location, details);
                } else if (trainMatcher.matches()) {
                    icmStep.setInstruction(dictionary.fixLocation(trainMatcher.group(2)) + " Station", location, details);
                } else if (endMatcher.matches()) {
                    icmStep.setInstruction(end.getDescription(), location, details);
                }
                
                icmRoute.addStep(icmStep);
            } else if ("TRAIN".equals(step.getVehicleType())) {
                // TODO combine ICM step creation
                ICMStep icmStep = new ICMStep("TRAIN", step.getLat(), step.getLon(), Double.parseDouble(step.getTime()));

                Matcher matcher = TRAIN_STATION_PATTERN.matcher(step.getTitle());
                if (!matcher.matches()) continue;
                String line = matcher.group(1);
                String station = matcher.group(2);
                matcher = TRAIN_DIRECTION_PATTERN.matcher(step.getDescription());
                if (!matcher.matches()) continue;
                String direction = matcher.group(1);
                icmStep.setInstruction(line, dictionary.fixLocation(station) + " Station", dictionary.fixLocation(direction));
                icmRoute.addStep(icmStep);
            } else if ("BUS".equals(step.getVehicleType())) {
                // TODO combine ICM step creation
                ICMStep icmStep = new ICMStep("BUS", step.getLat(), step.getLon(), Double.parseDouble(step.getTime()));
                Matcher matcher = BUS_NUM_PATTERN.matcher(step.getTitle());
                if (!matcher.matches()) continue;
                String service = matcher.group(1).replace(",", "/");
                String stopCode = matcher.group(2);
                String location = null;
                matcher = BUS_ALIGHT_PATTERN.matcher(steps.get(Math.max(0, i - 1)).getDescription());
                if (matcher.matches()) {
                    location = dictionary.fixLocation(matcher.group(1));
                } else {
                    matcher = WALK_TO_BUS_PATTERN.matcher(steps.get(i - 1).getDescription());
                    if (!matcher.matches()) continue;
                    location = dictionary.fixLocation(matcher.group(2));
                }
                icmStep.setInstruction(service, location, stopCode);
                icmRoute.addStep(icmStep);
            }
        }
        
        // add ending point
        ICMStep icmStep = new ICMStep("ARRIVE", end.getLat(), end.getLon());
        icmStep.setInstruction(null, "destination", null);
        icmRoute.addStep(icmStep);
        
        routes.add(icmRoute);
    }
    
    private void processTaxi(SDRouteResults results) {
        SDTaxiRouteDetail route = results.getTaxi().getDetail();
        double fare = route.getTaxiFare(0).getValue();
        ICMRoute icmRoute = new ICMRoute(fare);
        
        SDStartEnd start = results.getStart();
        ICMStep startStep = new ICMStep("WALK", start.getLat(), start.getLon());
        startStep.setInstruction(null, null, null);
        icmRoute.addStep(startStep);
        
        // later ICM will rewrite this to a taxi stand
        ICMStep taxiStep = new ICMStep("TAXI", 0, 0, getDuration(route.getTotal().getTimeString()));
        taxiStep.setInstruction(null, start.getTitle(), null);
        icmRoute.addStep(taxiStep);
        
        SDStartEnd end = results.getEnd();
        ICMStep endStep = new ICMStep("ARRIVE", end.getLat(), end.getLon());
        endStep.setInstruction(null, end.getDescription(), null);
        icmRoute.addStep(endStep);
        
        routes.add(icmRoute);
    }
    
    private double getDuration(String timeString) { // in minutes
        Matcher matcher = TRAVEL_TIME_PATTERN.matcher(timeString);
        if (!matcher.matches()) {
            return -1;
        }
        int hr = (matcher.group(2) == null) ? 0 : Integer.parseInt(matcher.group(2));
        int min = Integer.parseInt(matcher.group(3));
        return (hr * 60) + min;
    }
    
}
