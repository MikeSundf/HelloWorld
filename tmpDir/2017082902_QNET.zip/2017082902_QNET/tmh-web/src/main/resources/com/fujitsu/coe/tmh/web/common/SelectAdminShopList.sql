SELECT COUNT(*) 
from
  shop 
  inner join authority_info 
    on authority_info.manage_id = shop.shop_id 
    AND authority_info.user_id = ? 
    AND shop.shop_id = ?