CREATE TABLE product_coupon
(
  id serial NOT NULL,
  user_id character varying(45) NOT NULL,
  product_id integer NOT NULL,
  shop_id integer,
  coupon_id integer NOT NULL,
  seq smallint,
  spent numeric(6,2) DEFAULT NULL::numeric,
  ref character varying(100) DEFAULT NULL::character varying,
  expiry_time timestamp without time zone NOT NULL DEFAULT now(),
  redemption_time timestamp without time zone,
  CONSTRAINT product_coupon_pkey PRIMARY KEY (id),
  CONSTRAINT "couponFK" FOREIGN KEY (coupon_id)
      REFERENCES coupon (coupon_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "productFK" FOREIGN KEY (product_id)
      REFERENCES product (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "shopFK" FOREIGN KEY (shop_id)
      REFERENCES shop (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "userInfoFK" FOREIGN KEY (user_id)
      REFERENCES user_info (user_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
