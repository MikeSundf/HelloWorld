/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.util;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.res.ClasspathResource;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;

/**
 *
 * @author qnet8733
 */
public class AdminType {

    @Inject
    private JdbcTemplate db;
    @Inject
    @ClasspathResource("CountVenueList.sql")
    private String sqlCountAdminVenueList;
    @Inject
    @ClasspathResource("SelectAdminShopList.sql")
    private String sqlSelectAdminShopList;
    @Inject
    @ClasspathResource("SelectUserInfoType.sql")
    private String sqlSelectUserInfoType;
    @Inject
    @ClasspathResource("SelectAdminInfo.sql")
    private String sqlSelectAdminInfo;
    @Inject
    @ClasspathResource("SelectAdminInfoType.sql")
    private String sqlSelectAdminInfoType;
    @Inject
    @ClasspathResource("CountAdminInfo.sql")
    private String sqlCountAdminInfo;

    /**
     * admin_infoの種別を取得する
     *
     * @param adminID
     * @return
     * @throws SQLException
     */
    public int getAdminType(String adminID) throws SQLException {
        // 管理者IDの権限種別を取得
        final List<Integer> types = new ArrayList();
        db.query(sqlSelectAdminInfoType, (rs) -> {
            types.add(rs.getInt(1));
        }, adminID);
        // 管理者IDのadmin_infoがなかった場合は -1 を返す
        if (types.isEmpty()) {
            return -1;
        }
        // 管理者IDのadmin_infoがあった場合は先頭の値を返す
        return types.get(0);
    }

    /**
     * admin_infoの種別を取得する
     *
     * @param adminID
     * @return
     * @throws SQLException
     */
    public int getAdminInfo(String adminID) throws SQLException {
        int type = 0;

        Map<String, Object> user = new HashMap<String, Object>();
        db.query(sqlSelectAdminInfo, (rs) -> {
            user.put("user_id", rs.getString("user_id"));
            user.put("type", rs.getInt("type"));
            user.put("manage_id", rs.getInt("manage_id"));
        }, adminID);

        if (user.size() > 0) {
            type = (int) user.get("type");
        }

        return type;
    }

    public boolean checkAuth(String adminID, int shopID) throws SQLException {

        long type = this.getAdminInfo(adminID);
        boolean enableFlag = true;

        //システム管理者は配下チェックなし
        long count = 1;

        //開催地管理者権限
        if (type == ParamConstants.ADMIN_TYPE_VENUE) {

            try {
                count = db.queryForLong(sqlCountAdminVenueList, adminID, shopID);
            } catch (Exception e) {
                //nullだとエラーになるため
                count = 0;
            }

            //0件の場合は管理配下の店舗ではない
            if (count < 1) {
                return false;
            }

        }

        //店舗管理者権限
        if (type == ParamConstants.ADMIN_TYPE_SHOP) {
            try {
                count = db.queryForLong(sqlSelectAdminShopList, adminID, shopID);
            } catch (Exception e) {
                //nullだとエラーになるため
                count = 0;
            }
        }

        //admin_infoにレコードがない場合は、ユーザもしくはシステム管理者
        if (type == 0) {
            try {
                type = this.getUserType(adminID);
                //ユーザの場合は0（権限なし）を返却
                if (type == ParamConstants.USER_INFO_TYPE_USER) {
                    count = 0;
                }
            } catch (Exception e) {
                //nullだとエラーになるため
                count = 0;
            }
        }

        //0件の場合は管理配下の店舗ではない
        if (count < 1) {
            return false;
        } else {
            return true;
        }

    }

    /**
     * ユーザ種別取得 user_infoのtypeを取得する
     */
    public int getUserType(String user_id) throws SQLException {
        // ユーザIDのユーザ種別を取得
        final List<Integer> types = new ArrayList();
        db.query(sqlSelectUserInfoType, (rs) -> {
            types.add(rs.getInt(1));
        }, user_id);

        if (types.size() < 1) {
            return 0;
        } else {
            return types.get(0);
        }
    }

    /**
     * 管理対象チェック
     */
    private boolean isManage(String admin_id, Integer type, Integer manage_id) throws SQLException {
        // admin_infoテーブルを検索
        final List<Integer> counts = new ArrayList();
        db.query(sqlCountAdminInfo, (rs) -> {
            counts.add(rs.getInt(1));
        }, admin_id, type, manage_id);
        // ヒットしたレコードがあればtrue、なければfalseを返す
        return counts.get(0) != 0;
    }

    /**
     * 管理対象開催地チェック
     */
    public boolean isManageVenue(String admin_id, Integer venue_id) throws SQLException {
        return isManage(admin_id, ADMIN_TYPE_VENUE, venue_id);
    }

//    /**
//     * 管理対象店舗チェック
//     */
//    private boolean isManageShop(String admin_id, Integer shop_id) throws SQLException {
//        return isManage(admin_id, ADMIN_TYPE_SHOP, shop_id);
//    }

}
