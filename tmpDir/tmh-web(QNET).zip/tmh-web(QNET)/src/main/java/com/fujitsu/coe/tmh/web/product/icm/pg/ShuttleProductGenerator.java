package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.EgressStep;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.ICMRequest;
import com.fujitsu.coe.tmh.web.product.icm.Ruler;
import com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger;
import com.fujitsu.coe.tmh.web.util.Location;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.fromTS;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toMS;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toTS;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author kychua
 */
public class ShuttleProductGenerator {

    private ICMContext ctx;
    private ICMRequest request;

    public ShuttleProductGenerator(ICMContext ctx, ICMRequest request) {
        this.ctx = ctx;
        this.request = request;
    }

    // TODO icm logging
    public List<Product> generate() throws SQLException, IOException {
        Set<Egress.Mode> supportedModes = PGUtil.getSupportedModes(ctx);
        if (!supportedModes.contains(Egress.Mode.SHUTTLE)) {
            return Collections.emptyList();
        }

        // identify shuttle
        Shuttle shuttle = chooseShuttle();
        if (shuttle == null) {
            return Collections.emptyList();
        }
        
        // generate onward journey
        ICMRequest onwardReq = new ICMRequest();
        onwardReq.setFrom(shuttle.getStopName());
        onwardReq.setFromLocation(shuttle.getStopLocation());
        onwardReq.setTo(request.getTo());
        onwardReq.setToLocation(request.getToLocation());
        SDProductGenerator sdGenerator = new SDProductGenerator(ctx, onwardReq);
        List<Product> sdProducts = sdGenerator.generate(1); // i just want the now products
        
        // calculate at
        String[] bpSetting = ctx.settings.get("shuttle.origin" + ctx.user.getVenue(), "1.292919, 103.857651").split(",");   // lat, lon
        Location boardingPoint = new Location(Double.parseDouble(bpSetting[0]), Double.parseDouble(bpSetting[1]));
        long fmat = (long)Math.ceil(PGUtil.getAccessTime(request.getFromLocation(), boardingPoint) * TimeUnit.MINUTES.toMillis(1));     // milliseconds
        
        // create products by prepending shuttle
        CongestionLevel cgLevel = new CongestionLevel(ctx);
        List<Product> products = new ArrayList<>();
        for (Product sdProduct: sdProducts) {
            for (Date departure: shuttle.getDepartures()) {
                // calculate dt
                int dt = (int)TimeUnit.MILLISECONDS.toMinutes(departure.getTime() - ctx.clock.now().getTime() - fmat);
                if (dt <= 0) continue;  // not feasible
                
                Product product = new Product(sdProduct, Egress.Mode.SHUTTLE, cgLevel.get(Egress.Mode.SHUTTLE, ctx.clock.now().getTime() + toMS(dt)));
                List<EgressStep> steps = product.getEgress().getSteps();
                for (EgressStep step: steps) {
                    step.setSeq(step.getSeq() + 2);
                }
                // TODO fill in nulls/0s
                steps.add(0, new EgressStep(1, "WALK", null, null, null, fmat, 0, request.getFromLocation().getLat(), request.getFromLocation().getLon()));
                steps.add(1, new EgressStep(2, "SHUTTLE", null, "Suntec Convention Centre Level 1", 
                        String.format("%d%03d%d%s", request.getSeats(), ctx.user.getId(), shuttle.getId(), shuttle.getRoute()), 
                        TimeUnit.MINUTES.toMillis(shuttle.getTt()), 0, boardingPoint.getLat(), boardingPoint.getLon()));
                EgressStep originalFirstWalk = steps.get(2);
                steps.set(2, new EgressStep(3, "WALK", null, shuttle.getName(), null, originalFirstWalk.getTime(), originalFirstWalk.getWaitTime(), 
                        shuttle.getStopLocation().getLat(), shuttle.getStopLocation().getLon()));
                
                product.setDt(dt);
                product.setAt(sdProduct.getAt() + (int)TimeUnit.MILLISECONDS.toMinutes(fmat + originalFirstWalk.getTime()));
                product.setTt(shuttle.getTt() + sdProduct.getTt());
                product.setWt(sdProduct.getWt());
                product.reschedule();
                if (Math.abs(product.getEgress().getDep().getTime() - departure.getTime()) < 60000) {   // 1 minute
                    product.getEgress().setDep(departure);  // lets ignore a minute/second rounding!
                }
                products.add(product);
            }
        }
        return products;
    }

    /*
     * There are many ways to choose a shuttle, each with its own advantages and dis-.
     * 1. Measure euclidean distance between each shuttle end point and home location. Pick nearest. (distance threshold may be used to call N/A)
     * 2. Run standard SD generator, look at last MRT alighted and get find nearest shuttle endpoint (based on MRT stops)
     * 3. Run standard SD generator, look at MRT line & direction taken to choose route (but how to pick endpoint?)
     * 3. Use postal code prefix and map each zone to a shuttle stop (some zones may be N/A)
     * etc...
     */
    private Shuttle chooseShuttle() throws SQLException {
        // Method 1
        double[] onwardDistance = new double[]{Double.MAX_VALUE};
        Shuttle[] shuttle = new Shuttle[1];
        ctx.log(ICMLogger.LogCategory.XXX, "\n[SHUTTLE SELECTION]");
        ctx.db.query("SELECT * FROM shuttle_stop", (rs) -> {
            Location stopLocation = new Location(rs.getDouble("lat"), rs.getDouble("lon"));
            double distance = Ruler.distance(request.getToLocation(), stopLocation);
            ctx.log(ICMLogger.LogCategory.XXX, String.format("%s\t%f", rs.getString("name"), distance));
            if (distance < onwardDistance[0]) {
                onwardDistance[0] = distance;
                shuttle[0] = new Shuttle(rs.getInt("id"), rs.getString("route"), rs.getString("name"), 
                        rs.getInt("travel_duration"), rs.getString("stop_name"), stopLocation);
            }
        });

        // TODO: optimization may be performed here, e.g. filter shuttles where onwardDistance > distance(boarding-point, destination)

        if (shuttle[0] == null) {
            ctx.log(ICMLogger.LogCategory.XXX, "Chosen shuttle\tn/a");
        } else {
            ctx.log(ICMLogger.LogCategory.XXX, String.format("Chosen shuttle\t%s", shuttle[0].getName()));
            ctx.db.query("SELECT * FROM shuttle_schedule WHERE route=? AND departure_time BETWEEN ? AND ?", (rs) -> {
                shuttle[0].addDeparture(fromTS(rs.getTimestamp("departure_time")));
                ctx.log(ICMLogger.LogCategory.XXX, String.format("\tDepature\t%s", rs.getTimestamp("departure_time")));
            }, shuttle[0].getRoute(), toTS(ctx.clock.now()), new java.sql.Timestamp(ctx.clock.now().getTime() + TimeUnit.HOURS.toMillis(2)));
        }
        
        return shuttle[0];
    }

    private class Shuttle {

        private int id;
        private String route;
        private String name;
        private int tt;
        private String stopName;
        private Location stopLocation;
        private List<Date> departures;

        public Shuttle(int id, String route, String name, int tt, String stopName, Location stopLocation) {
            this.id = id;
            this.route = route;
            this.name = name;
            this.tt = tt;
            this.stopName = stopName;
            this.stopLocation = stopLocation;
            this.departures = new ArrayList<>();
        }

        public int getId() {
            return id;
        }

        public String getRoute() {
            return route;
        }

        public String getName() {
            return name;
        }

        public Location getStopLocation() {
            return stopLocation;
        }

        public void addDeparture(Date departure) {
            this.departures.add(departure);
        }

        public List<Date> getDepartures() {
            return departures;
        }

        public int getTt() {
            return tt;
        }

        public String getStopName() {
            return stopName;
        }
    }
}
