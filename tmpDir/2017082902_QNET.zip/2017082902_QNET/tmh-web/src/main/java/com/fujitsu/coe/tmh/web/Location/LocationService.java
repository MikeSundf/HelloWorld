package com.fujitsu.coe.tmh.web.Location;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.common.AdminType;
import com.fujitsu.coe.tmh.web.common.ErrorFactory;
import com.fujitsu.coe.tmh.web.common.IdExistCheck;
import com.fujitsu.coe.tmh.web.common.LogManage;
import com.fujitsu.coe.tmh.web.common.MapBuilder;
import static com.fujitsu.coe.tmh.web.common.ParamConstants.*;
import com.fujitsu.coe.tmh.web.common.SystemSettings;
import com.fujitsu.coe.tmh.web.common.ValidationCheck;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.logging.Level;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * 位置情報サービス
 */
@Path("/Location")
@ApplicationScoped
public class LocationService {

    String classname = LocationService.class.getName();

    @Inject
    @ClasspathResource("DeleteBeaconInfo.sql")
    private String sqlDeleteBeaconInfo;
    @Inject
    @ClasspathResource("DeleteBeaconInfo2.sql")
    private String sqlDeleteBeaconInfo2;
    @Inject
    @ClasspathResource("CreateBeaconInfo.sql")
    private String sqlCreateBeaconInfo;
    @Inject
    @ClasspathResource("UpdateBeaconInfo.sql")
    private String sqlUpdateBeaconInfo;
    @Inject
    @ClasspathResource("CreateBeaconFacility.sql")
    private String sqlCreateBeaconFacility;
    @Inject
    @ClasspathResource("UpdateBeaconFacility.sql")
    private String sqlUpdateBeaconFacility;
    @Inject
    @ClasspathResource("GetBeaconInfo.sql")
    private String sqlGetBeaconInfo;
    @Inject
    @ClasspathResource("GetBeaconInfo2.sql")
    private String sqlGetBeaconInfo2;
    @Inject
    @ClasspathResource("GetBeaconFacility.sql")
    private String sqlGetBeaconFacility;
    @Inject
    private JdbcTemplate db;
    @Inject
    private SystemSettings settings;
    @Inject
    private LogManage logger;
    @Inject
    private IdExistCheck idExist;
    @Inject
    private AdminType adminUtil;

    /**
     * ビーコンIDの対応表を削除
     *
     * @param adminID
     * @param beaconId
     * @author Qnet)hanada
     * @return
     */
    @POST
    @Path("/deleteBeaconInfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map deleteBeaconInfo(@FormParam("admin_id") @DefaultValue("") String adminID, @FormParam("id") @DefaultValue("") String beaconId) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id=%s, id=%s]", adminID, beaconId);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        /**
         * 必須チェック
         */
        if (adminID.equals("") || beaconId.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.isBeaconId(beaconId);
        if (validate == false) {
            validateErr.add("id");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        int result = 0;

        try {

            /**
             * 権限チェック システム管理者　もしくは　開催地管理者の配下ならばOK
             */
            boolean isAuth = false;
            isAuth = adminUtil.checkAuthBeacon(adminID, beaconId);

            if (isAuth == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            //存在確認
            int info = idExist.getRecordCount("beacon_info", "beacon_id", beaconId, null);
            int facility = idExist.getRecordCount("beacon_facility", "beacon_id", beaconId, null);
            if (info > 0 && facility > 0 ) {
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s, %s]", sqlDeleteBeaconInfo,beaconId, beaconId));
                //削除
                result = db.update(sqlDeleteBeaconInfo, beaconId, beaconId);
            } else if(info > 0 && facility < 1){
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sqlDeleteBeaconInfo2,beaconId));
                //削除
                result = db.update(sqlDeleteBeaconInfo2, beaconId);
            }else{
                result = 1;
                logger.log(Level.WARNING, classname, methodName, "beacon_id has already been deleted.");
            }

        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        //SQLの戻り値チェック
        if (result < 1) {
            logger.log(Level.SEVERE, classname, methodName, SQL_ERROR_CODE + " delete failed, " + SQL_ERROR_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } else {
            String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
            logger.log(Level.FINE, classname, methodName, outParam);
            logger.log(Level.FINE, classname, methodName, "END");
            //正常
            return MapBuilder.build("ok", true);
        }

    }

    /**
     * ビーコンIDの対応表を設定
     *
     * @param admin_id
     * @param beacon_id
     * @param venue_id
     * @param lat
     * @param lon
     * @param facility_type
     * @param facility_id
     * @author QNET gotoh
     * @return
     */
    @POST
    @Path("/setBeaconInfo")
    @Produces(MediaType.APPLICATION_JSON)
    public Map setBeaconInfo(
            @FormParam("admin_id") String admin_id,
            @FormParam("id") String beacon_id,
            @FormParam("venue_id") @DefaultValue("-1") int venue_id,
            @FormParam("lat") @DefaultValue("-1") float lat,
            @FormParam("lon") @DefaultValue("-1") float lon,
            @FormParam("facility_type[]") List<String> facility_type,
            @FormParam("facility_id[]") List<Integer> facility_id
    ) throws SQLException {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + admin_id + ", beacon_id=" + beacon_id + ", venue_id=" + venue_id + ", lat=" + lat + ", lon=" + lon + "]");

        // 必須パラメータチェック
        if (admin_id == null || admin_id.equals("") || beacon_id == null || beacon_id.equals("") || venue_id == -1 || lat == -1 || lon == -1) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(admin_id);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkBeaconId(beacon_id);
        if (validate == false) {
            validateErr.add("beacon_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(venue_id));
        if (validate == false) {
            validateErr.add("venue_id");
        }

        int res;
        if (lat != -1) {
            res = ValidationCheck.checkLatLon(lat, LATITUDE);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(lat);
            } else if (res != 0) {
                validateErr.add("lat");
            }
        }

        if (lon != -1) {
            res = ValidationCheck.checkLatLon(lon, LONGITUDE);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lon = ValidationCheck.roundUpLatLon(lon);
            } else if (res != 0) {
                validateErr.add("lon");
            }
        }

        validate = ValidationCheck.checkFacility(facility_type, facility_id);
        if (validate == false) {
            validateErr.add("facility_type,facility_id");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 登録数上限チェック
        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM beacon_info");
        if (recoredCount >= Integer.parseInt(settings.get("maxnum.setbeaconlist", DB_DEFAULT_MAX_NUM))) {
            logger.log(Level.WARNING, classname, methodName, LIMIT_SET_REGISTER_MSG);
            return ErrorFactory.createError(LIMIT_SET_REGISTER_CODE, LIMIT_SET_REGISTER_MSG);
        }

        // 権限チェック
        boolean type;
        int userType;
        try {
            // 権限チェック1　開催地管理者以上か
            userType = adminUtil.getUserType(admin_id);
            if (userType != USER_INFO_TYPE_SYSTEM && userType != USER_INFO_TYPE_VENUE) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            // 権限チェック2 自分の配下か
            type = adminUtil.checkAuth(admin_id, venue_id);
            if (type == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            // SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // beacon_infoデータベース設定
        if (db.queryForString("SELECT beacon_id FROM beacon_info WHERE beacon_id=?", beacon_id) == null) {
            try {
                db.update(sqlCreateBeaconInfo, beacon_id, venue_id, lat, lon);
                logger.log(Level.FINE, classname, methodName, "INSERT beacon_info:[beacon_id=" + beacon_id + ", venue_id=" + venue_id + ", lat=" + lat + ", lon=" + lon + "]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
                return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
        } else {
            try {
                db.update(sqlUpdateBeaconInfo, venue_id, lat, lon, beacon_id);
                logger.log(Level.FINE, classname, methodName, "UPDATE beacon_info:[beacon_id=" + beacon_id + ", venue_id=" + venue_id + ", lat=" + lat + ", lon=" + lon + "]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
                return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
        }

        // beacon_facilityデータベース設定
        for (int i = 0; i < facility_type.size(); i++) {
            if (db.queryForString("SELECT beacon_id FROM beacon_facility WHERE beacon_id=? AND facility_type =?", beacon_id, facility_type.get(i)) == null) {
                try {
                    db.update(sqlCreateBeaconFacility, beacon_id, facility_type.get(i), facility_id.get(i));
                    logger.log(Level.FINE, classname, methodName, "INSERT beacon_facility:[beacon_id=" + beacon_id + ",facility_type=" + facility_type.get(i) + ",facility_id=" + facility_id.get(i) + "]");
                } catch (SQLException sqle) {
                    logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
                    return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                }
            } else {
                try {
                    db.update(sqlUpdateBeaconFacility, facility_id.get(i), beacon_id, facility_type.get(i));
                    logger.log(Level.FINE, classname, methodName, "UPDATE beacon_facility:[beacon_id=" + beacon_id + ",facility_type=" + facility_type.get(i) + ",facility_id=" + facility_id.get(i) + "]");
                } catch (SQLException sqle) {
                    logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
                    return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                }
            }
        }

        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     * ビーコンIDの対応表を取得
     *
     * @param admin_id
     * @param venue_id
     * @param lat
     * @param lon
     * @param number
     * @author QNET gotoh
     * @return
     */
    @GET
    @Path("/getBeaconInfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map getBeaconInfo(
            @QueryParam("admin_id") @DefaultValue("") String admin_id,
            @QueryParam("venue_id") @DefaultValue("-1") int venue_id,
            @QueryParam("lat") @DefaultValue("-1") float lat,
            @QueryParam("lon") @DefaultValue("-1") float lon,
            @QueryParam("number") @DefaultValue("0") int number
    ) throws SQLException {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + admin_id + ", venue_id=" + venue_id + ", lat=" + lat + ", lon=" + lon + ", number=" + number + "]");

        // 必須パラメータチェック
        if (admin_id.equals("") || venue_id == -1) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(admin_id);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(venue_id));
        if (validate == false) {
            validateErr.add("venue_id");
        }

        int res;
        if (lat != -1) {
            res = ValidationCheck.checkLatLon(lat, LATITUDE);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(lat);
            } else if (res != 0) {
                validateErr.add("lat");
            }
        }

        if (lon != -1) {
            res = ValidationCheck.checkLatLon(lon, LONGITUDE);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lon = ValidationCheck.roundUpLatLon(lon);
            } else if (res != 0) {
                validateErr.add("lon");
            }
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(number));
        if (validate == false) {
            validateErr.add("number");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 権限チェック
        boolean type;
        int userType;
        try {
            // 権限チェック1　開催地管理者以上か
            userType = adminUtil.getUserType(admin_id);
            if (userType != USER_INFO_TYPE_SYSTEM && userType != USER_INFO_TYPE_VENUE) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            // 権限チェック2 自分の配下か
            type = adminUtil.checkAuth(admin_id, venue_id);
            if (type == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            // SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // データベース参照
        final Map<String, Object> response = new LinkedHashMap<>();
        final ArrayList<Map> beaconInf_tmp = new ArrayList<>();
        final ArrayList<Map> beaconInf = new ArrayList<>();

        // 緯度経度情報の有無判定
        // beacon_info部設定
        if(lat != -1 && lon != -1){
            // 緯度経度情報あり
            db.query(sqlGetBeaconInfo, (rs) -> {
                final Map<String, Object> beacon_info = new LinkedHashMap<>();
                beacon_info.put("beacon_id", rs.getString(1));
                beacon_info.put("lat", rs.getFloat(2));
                beacon_info.put("lon", rs.getFloat(3));
                beaconInf_tmp.add(beacon_info);
            }, lat, lon, venue_id);
        } else {
            // 緯度経度情報なし
            db.query(sqlGetBeaconInfo2, (rs) -> {
                final Map<String, Object> beacon_info = new LinkedHashMap<>();
                beacon_info.put("beacon_id", rs.getString(1));
                beacon_info.put("lat", rs.getFloat(2));
                beacon_info.put("lon", rs.getFloat(3));
                beaconInf_tmp.add(beacon_info);
            },venue_id);
        }

        // beacon_facility部設定
        for (int i = 0; i < beaconInf_tmp.size(); i++) {
            final ArrayList<Map> facility_list = new ArrayList<>();
            final Map<String, Object> facility_info = new LinkedHashMap<>();
            db.query(sqlGetBeaconFacility, (rs2) -> {
                final Map param = new LinkedHashMap();
                param.put("facility_type", rs2.getString(1));
                param.put("facility_id", rs2.getInt(2));
                facility_list.add(param);
            }, beaconInf_tmp.get(i).get("beacon_id"));
            facility_info.put("facility", facility_list);
            beaconInf_tmp.get(i).putAll(facility_info);
        }

        // 出力数分のビーコン情報を抽出
        if(number != 0){
            for(int i=0; i<number && i<beaconInf_tmp.size(); i++){
                beaconInf.add(beaconInf_tmp.get(i));
            }
        }

        // 取得数上限チェック
        if (beaconInf.size() > Integer.parseInt(settings.get("maxnum.getbeaconlist", DB_DEFAULT_MAX_NUM))) {
            logger.log(Level.WARNING, classname, methodName, LIMIT_GET_MSG);
            return ErrorFactory.createError(LIMIT_GET_CODE, LIMIT_GET_MSG);
        }

        response.put("beaconInf", beaconInf);
        logger.log(Level.FINE, classname, methodName, "END");
        return response;
    }
}
