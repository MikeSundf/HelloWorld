SELECT 
from
  coupon 
WHERE
 coupon_id=?