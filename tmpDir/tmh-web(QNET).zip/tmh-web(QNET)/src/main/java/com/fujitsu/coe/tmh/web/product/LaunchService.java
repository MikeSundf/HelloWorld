package com.fujitsu.coe.tmh.web.product;

import com.fujitsu.coe.ss.fac.CheckRole;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.user.ActionLogger;
import com.fujitsu.coe.tmh.web.user.LogLocation;
import com.fujitsu.coe.tmh.web.user.User;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.sql.SQLException;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author unicenfujitsu
 */
@Path("/")
@ApplicationScoped
@CheckRole("user")
public class LaunchService {

    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private ActionLogger aLogger;
    @Inject
    @ClasspathResource("GetCurrentProduct.sql")
    private String sqlGetCurrentProduct;
        
    @GET
    @Path("/launch")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String, Object> launch() throws SQLException {
        aLogger.log("LAUNCH", null, null);
        return launch(user.getId(), user.getVenue());
    }
    
    public Map<String, Object> launch(String userId, int venue) throws SQLException {
        // check for profile screen
        String postalCode = db.queryForString("SELECT postal_code FROM user_info WHERE id=?", userId);
        if (postalCode == null || postalCode.isEmpty()) {
            return MapBuilder.build("screen", "profile");
        }
        
        // check for current product
        final long[] holder = new long[1];
        db.query(sqlGetCurrentProduct, (rs) -> {
            holder[0] = rs.getLong(1);
        }, userId, venue);

        if (holder[0] == 0) {
            return MapBuilder.build("screen", "offer");
        } else {
            return MapBuilder.build("screen", "coupon");
        }
    }
}
