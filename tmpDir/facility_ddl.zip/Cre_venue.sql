CREATE TABLE venue
(
  id serial NOT NULL,
  name character varying(100),
  lat numeric(10,5),
  lon numeric(10,5),
  enable_flag boolean,
  PRIMARY KEY (id)
);
