package com.fujitsu.coe.tmh.web.product.icm.cs;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Coupon;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author unicenfujitsu
 */
public class RandomCouponSelector {

    private ICMContext ctx;
    
    public RandomCouponSelector(ICMContext ctx) {
        this.ctx = ctx;
    }
    
    public List<Coupon> select() throws SQLException {
        return ctx.db.query("SELECT c.id, s.name, c.title, c.description, s.address, s.location, s.map_hint, s.tel, c.terms, c.expiry_duration FROM coupon c INNER JOIN shop s ON c.shop_id=s.id WHERE s.venue_id=? ORDER by random() LIMIT 6", (rs) -> {
            return new Coupon(rs.getLong("id"), rs.getString("name"), rs.getString("title"), 
                    rs.getString("description"), rs.getString("address"), rs.getString("location"), 
                    rs.getString("map_hint"), rs.getString("tel"), rs.getString("terms"), 
                    new Date(ctx.clock.now().getTime() + TimeUnit.MINUTES.toMillis(rs.getInt("expiry_duration"))), false, false);
        }, ctx.user.getVenue());
    }
}
