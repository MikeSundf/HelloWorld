package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * JSON model for taxi.is.tf, bustrain.td and bus.td;
 * 
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDRouteTotal {
    private String distance; // tl
    private String cost; // tr
    private double time;    // tc
    // cannot use tc for taxi; shows 0.33376330532213 for 17 min, 0.23580882352941 for 12 min
    private String timeString; // tm

    public void setTl(String distance) {
        this.distance = distance;
    }

    public void setTr(String cost) {
        this.cost = cost;
    }
    
    public void setTc(double time) {
        this.time = time;
    }

    public void setTm(String timeString) {
        this.timeString = timeString;
    }

    public String getCost() {
        return cost;
    }
    
    public double getTime() {
        return time;
    }

    public String getTimeString() {
        return timeString;
    }
}
