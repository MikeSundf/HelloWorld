SELECT time,lat,lon,location FROM user_location WHERE user_id=? ORDER BY time DESC limit 1

