﻿# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import os.path
import plot_error_norm
import sys

def main():

    args = sys.argv
#    print args
#    print len(args)

    algo_type = 0
    row_size = 0
    
    # algorithm type
    if len(args) > 1:
        algo_type = int(args[1])
        print("algorithm: %d" % algo_type)

    # algorithm type
    if len(args) > 2:
        row_size = int(args[2])
        print("row_size: %d" % row_size)

    filepath = ""

    for l in range(5):
        if(algo_type != 0):
            if(algo_type != (l + 1)):
                continue

        algo_str = "algo1"
        if(l == 1):
            algo_str = "algo2"
        if(l == 2):
            algo_str = "algo3"
        if(l == 3):
            algo_str = "algo4"
        if(l == 4):
            algo_str = "algo5"

        for i in range(100):
            user_str = "user_%d" % (i)
            
            for k in range(2):
                assort_str = "fixed"
                if(k == 1):
                    assort_str = "random"
                        
                for j in range(2):
                    param_str = "err1"
                    if(j == 1):
                        param_str = "err_all_attr"
                    
                    filepath = "./" + algo_str + "/" + user_str + "/" + assort_str + "/" + param_str + "/param_error_norm.csv"
#                    print filepath
                    if(os.path.exists(filepath) == False):
                        print ("cannot find file: %s" % filepath)
                        break

                    title = user_str + "," + algo_str + "," + assort_str + "," + param_str
                    plot_error_norm.plot(filepath, title, row_size)


if __name__ == "__main__":
    
    main()
    
