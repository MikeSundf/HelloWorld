CREATE TABLE train_station
(
  id serial NOT NULL,
  code character varying(10)[] NOT NULL,
  name character varying(100) NOT NULL,
  venue_id integer NOT NULL,
  lat numeric(10,5),
  lon numeric(10,5),
  CONSTRAINT train_station_pkey PRIMARY KEY (id),
  CONSTRAINT "venueFK" FOREIGN KEY (venue_id)
      REFERENCES venue (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
