package com.fujitsu.coe.tmh.web.common;

import java.nio.file.Path;

/**
 * Represents a path, that can easily create variations of the path with the
 * same prefix.
 *
 * @author unicenfujitsu
 */
public class PathPrefix {

    private final Path parent;
    private final String prefix;
    private final String ext;

    public PathPrefix(Path parent, String prefix, String ext) {
        this.parent = parent;
        this.prefix = prefix;
        this.ext = ext;
    }

    public Path getPath(String variation) {
        return parent.resolve(String.format("%s%s%s", prefix, variation, ext));
    }
}
