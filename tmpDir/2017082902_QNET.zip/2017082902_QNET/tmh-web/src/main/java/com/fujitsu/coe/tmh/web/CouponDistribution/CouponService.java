package com.fujitsu.coe.tmh.web.CouponDistribution;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.common.SysClock;
import com.fujitsu.coe.tmh.web.UserManagement.ActionLogger;
import com.fujitsu.coe.tmh.web.UserManagement.User;
import com.fujitsu.coe.tmh.web.common.AdminType;
import com.fujitsu.coe.tmh.web.common.ErrorFactory;
import com.fujitsu.coe.tmh.web.common.IdExistCheck;
import static com.fujitsu.coe.tmh.web.common.ParamConstants.*;
import com.fujitsu.coe.tmh.web.common.MapBuilder;
import com.fujitsu.coe.tmh.web.common.SystemSettings;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.fujitsu.coe.tmh.web.common.LogManage;
import com.fujitsu.coe.tmh.web.common.ValidationCheck;
import java.util.LinkedHashMap;
import org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64;

/**
 * Services related to the coupon. E.g. listing, redemption, details.
 *
 * @author ky
 */
@Path("/coupon")
@ApplicationScoped
public class CouponService {

    String classname = CouponService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private SysClock clock;
    @Inject
    private ActionLogger aLogger;

    @Inject
    @ClasspathResource("UpdateCouponFlag.sql")
    private String sqlUpdateCouponFlag;
    @Inject
    @ClasspathResource("CreateCouponInfo_1.sql")
    private String sqlCreateCouponInfo1;
    @Inject
    @ClasspathResource("CreateCouponInfo_2.sql")
    private String sqlCreateCouponInfo2;
    @Inject
    @ClasspathResource("UpdateCouponInfo.sql")
    private String sqlUpdateCouponInfo;
    @Inject
    @ClasspathResource("SelectShopCategory.sql")
    private String sqlSelectShopCategory;
    @Inject
    @ClasspathResource("UpdateCouponReadingHistory.sql")
    private String sqlUpdateCouponReadingHistory;
    @Inject
    @ClasspathResource("SelectCouponShopInfo.sql")
    private String sqlSelectCouponShopInfo;
    @Inject
    @ClasspathResource("SelectVenue.sql")
    private String sqlSelectVenue;
    @Inject
    @ClasspathResource("CreateProductCoupon.sql")
    private String sqlCreateProductCoupon;
    @Inject
    @ClasspathResource("CreateCouponActivity.sql")
    private String sqlCreateCouponActivity;
    @Inject
    @ClasspathResource("SelectCouponInfo.sql")
    private String sqlSelectCouponInfo;
    @Inject
    @ClasspathResource("CreateCouponLogo.sql")
    private String sqlCreateCouponLogo;
    @Inject
    @ClasspathResource("UpdateCouponLogo.sql")
    private String sqlUpdateCouponLogo;
    @Inject
    @ClasspathResource("GetCouponListSystem1.sql")
    private String sqlGetCouponListSystem1;
    @Inject
    @ClasspathResource("GetCouponListSystem2.sql")
    private String sqlGetCouponListSystem2;
    @Inject
    @ClasspathResource("GetCouponListSystem3.sql")
    private String sqlGetCouponListSystem3;
    @Inject
    @ClasspathResource("GetCouponListSystem4.sql")
    private String sqlGetCouponListSystem4;
    @Inject
    @ClasspathResource("GetCouponListVenue1.sql")
    private String sqlGetCouponListVenue1;
    @Inject
    @ClasspathResource("GetCouponListVenue2.sql")
    private String sqlGetCouponListVenue2;
    @Inject
    @ClasspathResource("GetCouponListVenue3.sql")
    private String sqlGetCouponListVenue3;
    @Inject
    @ClasspathResource("GetCouponListVenue4.sql")
    private String sqlGetCouponListVenue4;
    @Inject
    @ClasspathResource("GetCouponListShop.sql")
    private String sqlGetCouponListShop;
    @Inject
    private SystemSettings settings;
    @Inject
    private AdminType adminUtil;
    @Inject
    private LogManage logger;
    @Inject
    private IdExistCheck idExist;

    /**
     * クーポン詳細表示 (API No.30)
     *
     * @param user [IN] ユーザID
     * @param coupon [IN] クーポンID
     * @return 管理対象店舗情報リスト
     * @auther Qnet)mikami
     */
    @GET
    @Path("/detail_coupon")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> getCouponDetail(
            @QueryParam("user_id") String user,
            @QueryParam("coupon_id") Long coupon
    ) throws SQLException {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user + ", coupon_id=" + coupon + "]");

        // 必須パラメータチェック
        if (user == null || user.equals("") || coupon == null) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(user))
                || !(ValidationCheck.checkIntegerId(String.valueOf(coupon)))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(user) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
            // クーポンIDチェック
            if (idExist.validateCouponId(coupon) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }

            /**
             * 権限チェック　ユーザのみ
             */
            int auth = adminUtil.getUserType(user);
            if (auth != USER_INFO_TYPE_USER) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // クーポン使用済み状態を取得
        int count;
        try {
            count = idExist.getRecordCount("product_coupon", "user_id", user, " AND coupon_id=".concat(String.valueOf(coupon)));
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        Boolean redeemed = (count > 0);
        // クーポン詳細情報を取得
        final byte shop_logo[][] = null;
        final byte coupon_logo[][] = null;
        String sql
                = "SELECT ".concat(
                        "a.coupon_id, ").concat(
                                "b.name, ").concat(
                                "a.title, ").concat(
                                "a.description, ").concat(
                                "b.address, ").concat(
                                "b.location, ").concat(
                                "b.map_hint, ").concat(
                                "b.tel, ").concat(
                                "a.terms, ").concat(
                                "a.expiry_duration, ").concat(
                                "a.expiry_date, ").concat(
                                "c.logo, ").concat(
                                "d.logo ").concat(
                                "FROM ").concat(
                                "coupon a ").concat(
                                "INNER JOIN ").concat(
                                "shop b ").concat(
                                "ON a.shop_id=b.shop_id ").concat(
                                "LEFT JOIN ").concat(
                                "shop_logo c ").concat(
                                "ON a.shop_id=c.shop_id ").concat(
                                "LEFT JOIN ").concat(
                                "coupon_logo d ").concat(
                                "ON a.coupon_id=d.coupon_id ").concat(
                                "WHERE ").concat(
                                "a.enable_flag=? AND ").concat(
                                "a.coupon_id=?");
        final Map<String, Object> res = new LinkedHashMap<>();
        try {
            db.query(sql, (rs) -> {
                res.put("id", rs.getLong(1));
                res.put("name", rs.getString(2));
                res.put("title", rs.getString(3));
                res.put("description", rs.getString(4));
                res.put("address", rs.getString(5));
                res.put("location", rs.getString(6));
                res.put("map_hint", rs.getString(7));
                res.put("tel", rs.getString(8));
                res.put("terms", rs.getString(9));
                res.put("expiry_duration", rs.getInt(10));
                res.put("expiry_time", rs.getString(11));
                res.put("redeemed", redeemed);
                if (rs.getBytes(12) != null) {
                    res.put("shop_logo", rs.getBytes(12));
                }
                if (rs.getBytes(13) != null) {
                    res.put("coupon_logo", rs.getBytes(13));
                }
            }, ENABLE_FLAG, coupon);
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        // クーポン利用状況DBを新規登録
        try {
            db.update("INSERT INTO user_coupon_activity(user_id, coupon_id, activity_type, time) VALUES(?, ?, ?, NOW())", user, coupon, GET_DETAIL);
            logger.log(Level.FINE, classname, methodName, "INSERT user_coupon_activity:[user_id=" + user + ", coupon_id=" + coupon + ", activity_type=" + GET_DETAIL + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        // 取得したクーポンをリターン
        logger.log(Level.FINE, classname, methodName, "END");
        return res;
    }

    /**
     * クーポンリスト取得 (API No.25)
     *
     * @param admin_id [IN] 管理者ID
     * @param venue_id [IN] 開催地ID
     * @param shop_id [IN] 店舗ID
     * @return クーポン情報リスト
     * @auther Qnet)gotoh
     */
    @GET
    @Path("/list")
    @Produces(MediaType.APPLICATION_JSON)
    public Map getCouponList(@QueryParam("admin_id") String admin_id,
            @QueryParam("venue_id") @DefaultValue("0") int venue_id,
            @QueryParam("shop_id") @DefaultValue("0") int shop_id) throws SQLException {
        aLogger.log(admin_id, "COUPON_LIST", admin_id, String.format("[admin_id=%s] [venue_id=%d] [shop_id=%d]", admin_id, venue_id, shop_id));

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + admin_id + ", venue_id=" + venue_id + ", shop_id=" + shop_id + "]");

        // クーポンリスト配列生成
        Map<String, List<Map>> response = new LinkedHashMap<>();
        if (response == null) {
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // 必須パラメータチェック
        if (admin_id == null || admin_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(admin_id))
                || !(ValidationCheck.checkIntegerId(String.valueOf(venue_id)))
                || !(ValidationCheck.checkIntegerId(String.valueOf(shop_id)))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 開催地IDパラメタありの場合は開催地IDをチェック
        if (venue_id != 0) {
            if (idExist.validateaVenueId(venue_id) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
        }

        // 店舗IDパラメタありの場合は店舗IDをチェック
        if (shop_id != 0) {
            if (idExist.validateShopId(shop_id) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
        }

        // 種別取得
        int type = adminUtil.getUserType(admin_id);

        // 管理配下のものがあるか？
        List<Integer> venue_list = new ArrayList<>();
        List<Integer> shop_list = new ArrayList<>();
        boolean venue_manage_flag = false;
        boolean shop_manage_flag = false;
        if (type == USER_INFO_TYPE_VENUE) {
            // 開催地管理者の場合
            // 管理配下の開催地リスト取得
            db.query("SELECT manage_id FROM authority_info WHERE user_id=?", (rs) -> {
                venue_list.add(Integer.parseInt(rs.getString(1)));
            }, admin_id);

            if (venue_id != 0) {
                // 入力情報の開催地IDは管理配下か
                for (int i = 0; i < venue_list.size(); i++) {
                    if (venue_id == venue_list.get(i)) {
                        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM venue WHERE venue_id=? AND enable_flag=TRUE", venue_list.get(i));
                        if (recoredCount > 0) {
                            // 管理配下
                            venue_manage_flag = true;
                            break;
                        }
                    }
                }
                // 管理配下でない場合取得不可
                if (!venue_manage_flag) {
                    logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                    return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
                }
                venue_manage_flag = false;
            }
            if (shop_id != 0) {
                // 入力情報の店舗IDは管理配下か
                long venue_id_for_shop_id = db.queryForLong("SELECT venue_id FROM shop WHERE shop_id = ?", shop_id);
                for (int i = 0; i < venue_list.size(); i++) {
                    if (venue_id_for_shop_id == venue_list.get(i)) {
                        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM venue WHERE venue_id=? AND enable_flag=TRUE", venue_list.get(i));
                        if (recoredCount > 0) {
                            // 管理配下
                            venue_manage_flag = true;
                            break;
                        }
                    }
                }
                // 管理配下でない場合取得不可
                if (!venue_manage_flag) {
                    logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                    return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
                }
            }
        } else if (type == USER_INFO_TYPE_SHOP) {
            // 店舗管理者の場合
            // 管理配下の店舗リスト取得
            db.query("SELECT manage_id FROM authority_info WHERE user_id=?", (rs) -> {
                shop_list.add(Integer.parseInt(rs.getString(1)));
            }, admin_id);

            if (venue_id != 0) {
                // 入力情報の開催地IDは管理している店舗の開催地IDか
                for (int i = 0; i < shop_list.size(); i++) {
                    long venue_id_for_shop_id = db.queryForLong("SELECT venue_id FROM shop WHERE shop_id = ?", shop_list.get(i));
                    if (venue_id_for_shop_id == venue_id) {
                        // 管理配下
                        shop_manage_flag = true;
                        break;
                    }
                }
                // 入力情報の開催地IDは管理している店舗の開催地IDでない場合取得不可
                if (!shop_manage_flag) {
                    logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                    return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
                }
                shop_manage_flag = false;
            }
            if (shop_id != 0) {
                // 管理配下の店舗リストで有効な店舗を引く
                for (int i = 0; i < shop_list.size(); i++) {
                    if (shop_id == shop_list.get(i)) {
                        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM shop WHERE shop_id=? AND enable_flag=TRUE", shop_list.get(i));
                        if (recoredCount > 0) {
                            // 管理配下のものがあった
                            shop_manage_flag = true;
                            break;
                        }
                    }
                }
                // 管理配下でない場合取得不可
                if (!shop_manage_flag) {
                    logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                    return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
                }
            }
        }

        // クーポンリスト取得
        List<Map> coupons = new ArrayList<>();
        response.put("coupons", coupons);
        switch (type) {
            // ユーザ
            case USER_INFO_TYPE_USER:
                logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);

            // システム管理者
            case USER_INFO_TYPE_SYSTEM:
                // 開催地IDと店舗ID両方指定
                if ((venue_id != 0) && (shop_id != 0)) {
                    db.query(sqlGetCouponListSystem1, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, venue_id, shop_id, ENABLE_FLAG);
                    // 店舗IDのみ指定
                } else if ((venue_id == 0) && (shop_id != 0)) {
                    try {
                        db.query(sqlGetCouponListSystem2, (rs) -> {
                            Map<String, Object> data = new LinkedHashMap<>();
                            data.put("shop_id", rs.getInt(1));
                            data.put("coupon_id", rs.getInt(2));
                            data.put("name", rs.getString(3));
                            data.put("title", rs.getString(4));
                            data.put("description", rs.getString(5));
                            data.put("terms", rs.getString(6));
                            data.put("max_available", rs.getInt(7));
                            data.put("expiry_duration", rs.getString(8));
                            data.put("expiry_date", rs.getString(9));
                            data.put("money_level", rs.getLong(10));
                            data.put("coupon_value", rs.getLong(11));
                            data.put("category", rs.getString(12));
                            data.put("price_category", rs.getInt(13));
                            data.put("discount_category", rs.getString(14));
                            coupons.add(data);
                        }, shop_id, ENABLE_FLAG);
                    } catch (SQLException sqle) {
                        logger.thrownLog(Level.INFO, classname, methodName, "", sqle);
                    }
                    // 開催地IDのみ指定
                } else if ((venue_id != 0) && (shop_id == 0)) {
                    db.query(sqlGetCouponListSystem3, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, venue_id, ENABLE_FLAG);
                    // 指定なし
                } else {
                    db.query(sqlGetCouponListSystem4, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, ENABLE_FLAG);
                }
                break;

            // 開催地管理者
            case USER_INFO_TYPE_VENUE:
                // 開催地IDと店舗ID両方指定
                if ((venue_id != 0) && (shop_id != 0)) {
                    db.query(sqlGetCouponListVenue1, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, venue_id, shop_id, ENABLE_FLAG);
                    // 店舗IDのみ指定
                } else if ((venue_id == 0) && (shop_id != 0)) {
                    db.query(sqlGetCouponListVenue2, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, shop_id, ENABLE_FLAG);
                    // 開催地IDのみ指定
                } else if ((venue_id != 0) && (shop_id == 0)) {
                    db.query(sqlGetCouponListVenue3, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, venue_id, ENABLE_FLAG);
                    // 指定なし(自開催地ID配下)
                } else {
                    for (int i = 0; i < venue_list.size(); i++) {
                        db.query(sqlGetCouponListVenue4, (rs) -> {
                            Map<String, Object> data = new LinkedHashMap<>();
                            data.put("shop_id", rs.getInt(1));
                            data.put("coupon_id", rs.getInt(2));
                            data.put("name", rs.getString(3));
                            data.put("title", rs.getString(4));
                            data.put("description", rs.getString(5));
                            data.put("terms", rs.getString(6));
                            data.put("max_available", rs.getInt(7));
                            data.put("expiry_duration", rs.getString(8));
                            data.put("expiry_date", rs.getString(9));
                            data.put("money_level", rs.getLong(10));
                            data.put("coupon_value", rs.getLong(11));
                            data.put("category", rs.getString(12));
                            data.put("price_category", rs.getInt(13));
                            data.put("discount_category", rs.getString(14));
                            coupons.add(data);
                        }, venue_list.get(i), ENABLE_FLAG);
                    }
                }
                break;

            // 店舗管理者
            case USER_INFO_TYPE_SHOP:
                // 店舗IDのみ指定
                if (shop_id != 0) {
                    // 店舗IDのみ指定
                    db.query(sqlGetCouponListShop, (rs) -> {
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("shop_id", rs.getInt(1));
                        data.put("coupon_id", rs.getInt(2));
                        data.put("name", rs.getString(3));
                        data.put("title", rs.getString(4));
                        data.put("description", rs.getString(5));
                        data.put("terms", rs.getString(6));
                        data.put("max_available", rs.getInt(7));
                        data.put("expiry_duration", rs.getString(8));
                        data.put("expiry_date", rs.getString(9));
                        data.put("money_level", rs.getLong(10));
                        data.put("coupon_value", rs.getLong(11));
                        data.put("category", rs.getString(12));
                        data.put("price_category", rs.getInt(13));
                        data.put("discount_category", rs.getString(14));
                        coupons.add(data);
                    }, shop_id, ENABLE_FLAG);
                } else {
                    // 店舗ID指定なし(自店舗ID配下)
                    for (int i = 0; i < shop_list.size(); i++) {
                        db.query(sqlGetCouponListShop, (rs) -> {
                            Map<String, Object> data = new LinkedHashMap<>();
                            data.put("shop_id", rs.getInt(1));
                            data.put("coupon_id", rs.getInt(2));
                            data.put("name", rs.getString(3));
                            data.put("title", rs.getString(4));
                            data.put("description", rs.getString(5));
                            data.put("terms", rs.getString(6));
                            data.put("max_available", rs.getInt(7));
                            data.put("expiry_duration", rs.getString(8));
                            data.put("expiry_date", rs.getString(9));
                            data.put("money_level", rs.getLong(10));
                            data.put("coupon_value", rs.getLong(11));
                            data.put("category", rs.getString(12));
                            data.put("price_category", rs.getInt(13));
                            data.put("discount_category", rs.getString(14));
                            coupons.add(data);
                        }, shop_list.get(i), ENABLE_FLAG);
                    }
                }
                break;

            // その他
            default:
                logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return response;
    }

    /**
     * クーポン利用 (API No.29)
     *
     * @param user [IN] ユーザID(必須)
     * @param coupon [IN] クーポンID(必須)
     * @param spent [IN] 消費額
     * @param passcode [IN] パスコード
     * @return 管理対象店舗情報リスト
     * @auther Qnet)mikami
     */
    @POST
    @Path("/redeem_coupon")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> redeemCoupon(
            @FormParam("user_id") String user,
            @FormParam("coupon_id") @DefaultValue("-1") Long coupon,
            @FormParam("spent") @DefaultValue("0") Double spent,
            @FormParam("passcode") @DefaultValue("") String passcode
    ) throws SQLException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user + ", coupon_id=" + coupon + ", spent=" + spent + ", passcode=" + passcode + "]");

        // 必須パラメータチェック
        if (user == null || user.equals("") || coupon < 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(user))
                || !(ValidationCheck.checkIntegerId(String.valueOf(coupon)))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(user) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
            // 対象クーポンIDチェック
            if (idExist.validateCouponId(coupon) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 消費額チェック
        int res = -1;
        res = ValidationCheck.checkDecimal(spent, 6, 2);
        if (res == NUM_DECIMAL_OVER) {
            //小数部の最大桁数超えの場合は四捨五入する
            spent = ValidationCheck.roundUpNum(spent, 2);
        } else if (res != 0) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        // パスコードチェック
        if (ValidationCheck.checkStr45(passcode) == false) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * 権限チェック　ユーザのみ
         */
        try {
            int auth = adminUtil.getUserType(user);
            if (auth != USER_INFO_TYPE_USER) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // クーポンの店舗IDを取得する
        Integer[] shop = new Integer[1];
        try {
            db.query(sqlSelectCouponInfo, (rs) -> {
                shop[0] = rs.getInt("shop_id");
            }, coupon);
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        // クーポン残枚数チェック
        long available = db.queryForLong("SELECT available FROM coupon WHERE coupon_id=?", coupon);
        if (available <= 0) {
            logger.log(Level.WARNING, classname, methodName, SHORTAGE_COUPON_MSG);
            return ErrorFactory.createError(SHORTAGE_COUPON_CODE, SHORTAGE_COUPON_MSG);
        }

        // クーポン使用チェック
        try {
            //// クーポンおすすめチェック【フェールセーフ】
            //if (idExist.getRecordCount("product_coupon", "coupon_id", coupon, " AND user_id=".concat(user)) == 0) {
            //    return ErrorFactory.createError(1002, "System error.");
            //}
            // クーポン使用済みチェック
            int count = idExist.getRecordCount("product_coupon", "coupon_id", coupon, " AND user_id='".concat(user).concat("' AND redemption_time IS NOT NULL"));
            if (count > 0) {
                logger.log(Level.WARNING, classname, methodName, USER_ALREADY_COUPON_MSG);
                return ErrorFactory.createError(USER_ALREADY_COUPON_CODE, USER_ALREADY_COUPON_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        // クーポンのパスコードチェック
        try {
            String pass = getCouponPasscode(coupon);
            if (pass != null) {
                if (passcode == null) {
                    logger.log(Level.WARNING, classname, methodName, INVALID_PASSCODE_MSG);
                    return ErrorFactory.createError(INVALID_PASSCODE_CODE, INVALID_PASSCODE_MSG);
                } else if (!(passcode.equals(pass))) {
                    logger.log(Level.WARNING, classname, methodName, INVALID_PASSCODE_MSG);
                    return ErrorFactory.createError(INVALID_PASSCODE_CODE, INVALID_PASSCODE_MSG);
                }
                //} else if ( passcode != null ) {
                //    // DBのパスコードはnullなのにパスコードパラメタ指定があればエラー【フェールセーフ】
                //    logger.log(Level.WARNING, classname, methodName, INVALID_PASSCODE_MSG);
                //    return ErrorFactory.createError(USER_ALREADY_COUPON_CODE, INVALID_PASSCODE_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // クーポン使用DBを更新(クーポン使用時間、消費額)
        // クーポンDBを更新(残枚数)
        // クーポン利用状況DBを新規登録
        try {
            db.update("INSERT INTO product_coupon(user_id, shop_id, coupon_id, spent, redemption_time) VALUES(?,?,?,?,NOW())", user, shop[0], coupon, spent);
            logger.log(Level.FINE, classname, methodName, "INSERT product_coupon:[user_id=" + user + ", shop_id=" + shop[0] + ", coupon_id=" + coupon + ", spent=" + spent + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        try {
            db.update("UPDATE coupon SET available=available-1 WHERE coupon_id=?", coupon);
            logger.log(Level.FINE, classname, methodName, "UPDATE coupon:[coupon_id=" + coupon + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPADTE error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        try {
            db.update("INSERT INTO user_coupon_activity(user_id, coupon_id, activity_type, time) VALUES(?, ?, ?, NOW())", user, coupon, REDEEM);
            logger.log(Level.FINE, classname, methodName, "INSERT user_coupon_activity:[user_id=" + user + ", coupon_id=" + coupon + ", activity_type=" + REDEEM + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 正常終了
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     * クーポンパスコード取得
     *
     * @param coupon_id
     * @return
     * @throws SQLException
     * @author Qnet)mikami
     */
    private String getCouponPasscode(Long coupon_id) throws SQLException {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        // クーポンID発行店舗の店舗DBからパスコードを取得
        final List<String> passcode = new ArrayList();
        db.query("SELECT passcode FROM shop WHERE shop_id=(SELECT shop_id FROM coupon WHERE coupon_id=?)", (rs) -> {
            passcode.add(rs.getString(1));
        }, coupon_id);
        logger.log(Level.FINE, classname, methodName, "SELECT shop:[coupon_id=" + coupon_id + "]");
        // クーポン発行店舗のpasscode値を返す
        return passcode.get(0);
    }

    /**
     * おすすめクーポン取得
     *
     * @param userID
     * @param venueID
     * @param lat
     * @param lon
     * @param time
     * @author Qnet)hanada
     * @param hungry
     * @return
     */
    @GET
    @Path("/coupon")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map getCoupon(
            @QueryParam("user_id") String userID,
            @QueryParam("venue_id") @DefaultValue("-1") int venueID,
            @QueryParam("lat") @DefaultValue("-1") float lat,
            @QueryParam("lon") @DefaultValue("-1") float lon,
            @QueryParam("time") String time,
            @QueryParam("hungry") @DefaultValue("-1") int hungry) {
        try {
            aLogger.log(userID, "COUPON_RECCOMEND", String.valueOf(userID), String.format("[venue_id=%d] [lat=%f] [lon=%f] [time=%s] [hungry=%d]", venueID, lat, lon, time, hungry));
        } catch (Exception ex) {
        }

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = "InputParam:[admin_id=" + userID + ", venue_id=" + venueID + ", lat=" + lat + ", lon=" + lon + ", time=" + time + ", hungry=" + hungry + "]";
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        //必須チェック
        if (userID == null || userID.equals("") || venueID == -1 || time == null || time.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(userID);
        if (validate == false) {
            validateErr.add("user_id");
        }

        validate = (ValidationCheck.checkIntegerId(String.valueOf(venueID)));
        if (validate == false) {
            validateErr.add("venue_id");
        }

        int res = -1;
        if (lat != -1) {//経度　-90～90
            res = ValidationCheck.checkLatLon(lat, LATITUDE);
            if (res == NUM_DECIMAL_OVER) {
                //小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(lat);
            } else if (res != 0) {
                validateErr.add("lat");
            }
        }

        if (lon != -1) {//緯度　-180～180
            res = ValidationCheck.checkLatLon(lon, LONGITUDE);
            if (res == NUM_DECIMAL_OVER) {
                //小数部の最大桁数超えの場合は四捨五入する
                lon = ValidationCheck.roundUpLatLon(lon);
            } else if (res != 0) {
                validateErr.add("lon");
            }
        }

        if (hungry != -1 && hungry != 0 && hungry != 1 && hungry != 2) {
            validateErr.add("hungry");
        }

        validate = ValidationCheck.checkDate(time);
        if (validate == false) {
            validateErr.add("time");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        List<Object> coupons = new ArrayList<>();
        try {

            /**
             * 権限チェック　ユーザのみ
             */
            int auth = adminUtil.getUserType(userID);
            if (auth != USER_INFO_TYPE_USER) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            final Float[] pos = new Float[2];
            if (lat < 0 || lon < 0) {
                db.query(sqlSelectVenue, (rs) -> {
                    pos[0] = rs.getFloat("lat");
                    pos[1] = rs.getFloat("lon");
                }, venueID);
                lat = pos[0];
                lon = pos[1];
            }

            ICMContext cntxt = new ICMContext(db, settings, clock, null, logger);
            CSAlgoGateway gateWay = new CSAlgoGateway(cntxt);
            int[] recommend = gateWay.recommend(userID, venueID, lat, lon, time, hungry);

            //取得数数条件チェック
            if (Integer.parseInt(settings.get("maxnum.getcouponlist", DB_DEFAULT_MAX_NUM)) < recommend.length) {
                logger.log(Level.SEVERE, classname, methodName, LIMIT_GET_CODE + " " + LIMIT_GET_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(LIMIT_GET_CODE, LIMIT_GET_MSG);
            }

            if (recommend.length < 1) {
                logger.log(Level.FINE, classname, methodName, "recommend coupon is 0.");
                logger.log(Level.FINE, classname, methodName, "END");
                return MapBuilder.create("coupon", coupons).build();
            }

            //SQLの作成
            String sql = sqlSelectCouponShopInfo;
            for (int i = 0; i < recommend.length; i++) {
                sql = sql + " c.coupon_id = " + recommend[i] + " OR ";
            }

            if (sql.length() > 0) {
                sql = sql.substring(0, sql.length() - 3);
            }

            List<String> updateSql_value = new ArrayList<>();
            List<String> updateSql_ca_value = new ArrayList<>();
            Throwable[] err = new Throwable[1];
            int[] errFlag = new int[1];
            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", sql));
            db.query(sql, (rs) -> {
                try {
                    Map<String, Object> info = new HashMap<>();
                    info.put("id", rs.getLong("coupon_id"));
                    info.put("name", rs.getString("name"));
                    info.put("title", rs.getString("title"));
                    info.put("description", rs.getString("description"));
                    info.put("address", rs.getString("address"));
                    info.put("location", rs.getString("location"));
                    info.put("map_hint", rs.getString("map_hint"));
                    info.put("tel", rs.getString("tel"));
                    info.put("terms", rs.getString("terms"));
                    info.put("expiry_duration", rs.getInt("expiry_duration"));
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    java.util.Date expity = format.parse(rs.getString("expiry_date"));
                    String expiry_time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(expity);
                    info.put("expiry_time", expiry_time);
                    if (rs.getString("redemption_time") == null) {
                        info.put("redeemed", false);
                    } else {
                        info.put("redeemed", true);
                    }
                    info.put("shop_logo", rs.getBytes("logo"));
                    info.put("expected_dwell_time", rs.getInt("expected_dwell_time"));
                    info.put("coupon_value", rs.getInt("coupon_value"));
                    coupons.add(info);
                    updateSql_value.add(String.format("('%s', %d, %d)", userID, rs.getInt("shop_id"), rs.getLong("coupon_id")));

                    java.util.Date NOW = new java.util.Date();
                    String createTime = new java.sql.Timestamp(NOW.getTime()).toString();
                    updateSql_ca_value.add(String.format("('%s', %d, 0, '%s')", userID, rs.getLong("coupon_id"), createTime));

                } catch (SQLException | ParseException ex) {
                    err[0] = ex;
                    errFlag[0] = 1;
                }
            });

            if (errFlag[0] == 1) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "Exception. ", err[0]);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
            }

            if (coupons.size() > 0) {

                String updateSql = sqlCreateProductCoupon;
                String updateCASql = sqlCreateCouponActivity;
                String updateCASql2 = "";
                for (int i = 0; i < updateSql_value.size(); i++) {
                    updateCASql2 = updateCASql2 + " " + updateSql_ca_value.get(i) + ", ";
                }
                if (updateCASql2.length() > 0) {
                    updateCASql2 = updateCASql2.substring(0, updateCASql2.length() - 2);
                }

                //update user_coupon_activity
                updateSql = updateCASql + updateCASql2;
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", updateSql));
                int result = db.update(updateSql);
                //SQLの戻り値チェック
                if (result < 1) {
                    //SQL失敗
                    throw new SQLException("update failed.");
                }
            }else{
                logger.log(Level.FINE, classname, methodName, "couponID[" + Arrays.toString(recommend) + "] not find.");
            }
            
            if (logger.settinglogLevel > 4) {
                // 変換
                ObjectMapper objectMapper = new ObjectMapper();
                String json = objectMapper.writeValueAsString(coupons);
                String outParam = "outputParam[" + json + "]";
                logger.log(Level.FINE, classname, methodName, outParam);
            }
            logger.log(Level.FINE, classname, methodName, "END");
        } catch (JsonProcessingException ex) {
            //ログ出力なので何もしない
        } catch (SQLException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, ex);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } catch (IOException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "IO Exception. ", ex);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        } catch ( Exception ex){
            logger.thrownLog(Level.SEVERE, classname, methodName, SYSTEM_ERROR_MSG, ex);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);            
        }

        return MapBuilder.create("coupon", coupons).build();
    }

    /**
     * クーポン情報設定
     *
     * @param adminID
     * @param shopID
     * @param couponID
     * @param title
     * @param description
     * @param terms
     * @param remarks
     * @param availableNum
     * @param issueNum
     * @param expiryNum
     * @param expiryTime
     * @param moneyLevel
     * @param value
     * @param category
     * @param priceCotegory
     * @param discountCategory
     * @author Qnet)hanada
     * @return
     */
    @POST
    @Path("/setInfo")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map setCoupon(@FormParam("admin_id") String adminID,
            @FormParam("shop_id") @DefaultValue("-1") int shopID,
            @FormParam("coupon_id") @DefaultValue("-1") Long couponID,
            @FormParam("title") String title,
            @FormParam("description") String description,
            @FormParam("terms") String terms,
            @FormParam("remarks") String remarks,
            @FormParam("available_number") @DefaultValue("-1") Long availableNum,
            @FormParam("issue_number") @DefaultValue("-1") Long issueNum,
            @FormParam("expiry_duration") @DefaultValue("-1") int expiryNum,
            @FormParam("expiry_time") String expiryTime,
            @FormParam("money_level") @DefaultValue("-1") Double moneyLevel,
            @FormParam("coupon_value") @DefaultValue("-1") Double value,
            @FormParam("category") String category,
            @FormParam("price_category") @DefaultValue("-1") int priceCotegory,
            @FormParam("discount_category") @DefaultValue("-1") int discountCategory,
            @FormParam("logo") String logo
    ) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        logger.log(Level.FINE, classname, methodName, "START");
        String inputParam = "inputParam[admin_id=" + adminID + ", shop_id=" + shopID
                + ", coupon_id=" + couponID + ", title=" + title
                + ", description=" + description + ", terms=" + terms
                + ", remarks=" + remarks + ", issue_number=" + issueNum
                + ", available_number=" + availableNum + ", expiry_duration=" + expiryNum
                + ", expiry_time=" + expiryTime + ", money_level=" + moneyLevel
                + ", coupon_value=" + value + ", category=" + category
                + ", price_category=" + priceCotegory + ", discount_category=" + discountCategory + "]";
        logger.log(Level.FINE, classname, methodName, inputParam);

        int result = 0;
        boolean enableFlag = true;

        /**
         * 必須チェック キー指定なし
         */
        if (adminID == null || shopID < 0 || title == null || description == null
                || terms == null || issueNum < 0 || moneyLevel < 0 || value < 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * 必須チェック　キー指定あり
         */
        if (adminID.equals("") || title.equals("") || description.equals("") || terms.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        if (couponID != -1) {
            validate = ValidationCheck.checkLong(String.valueOf(couponID));
            if (validate == false) {
                validateErr.add("coupon_id");
            }
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(availableNum));
        if (validate == false) {
            validateErr.add("available_number");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(expiryNum));
        if (validate == false) {
            validateErr.add("expiry_duration");
        }

        int res = -1;
        res = ValidationCheck.checkDecimal(moneyLevel, 6, 2);
        if (res == NUM_DECIMAL_OVER) {
            //小数部の最大桁数超えの場合は四捨五入する
            moneyLevel = ValidationCheck.roundUpNum(moneyLevel, 2);
        } else if (res != 0) {
            validateErr.add("money_level");
        }

        res = ValidationCheck.checkDecimal(value, 6, 2);
        if (res == NUM_DECIMAL_OVER) {
            //小数部の最大桁数超えの場合は四捨五入する
            value = ValidationCheck.roundUpNum(value, 2);
        } else if (res != 0) {
            validateErr.add("coupon_value");
        }

        validate = ValidationCheck.checkStr45(category);
        if (validate == false) {
            validateErr.add("category");
        }

        validate = ValidationCheck.checkStr100(remarks);
        if (validate == false) {
            validateErr.add("remarks");
        }

        validate = ValidationCheck.checkStr100(title);
        if (validate == false) {
            validateErr.add("title");
        }

        validate = ValidationCheck.checkStr2000(terms);
        if (validate == false) {
            validateErr.add("terms");
        }

        validate = ValidationCheck.checkStr300(description);
        if (validate == false) {
            validateErr.add("description");
        }

        validate = ValidationCheck.checkDate(expiryTime);
        if (validate == false) {
            validateErr.add("expiryTime");
        }

        String[] pCategory = {"-1", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        boolean find = Arrays.asList(pCategory).contains(String.valueOf(priceCotegory));
        if (find == false) {
            validateErr.add("price_category");
        }

        String[] dCategory = {"-1", "0", "1", "2", "3", "4", "5", "6"};
        find = Arrays.asList(dCategory).contains(String.valueOf(discountCategory));
        if (find == false) {
            validateErr.add("discount_category");
        }

        //クーポン追加
        if (couponID < 0) {
            //残枚数が未設定の場合は、発行数と一致させる
            if (availableNum < 0) {
                availableNum = issueNum;
            }

            //有効枚数が未設定の場合は、0
            if (expiryNum < 0) {
                expiryNum = 0;
            }
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        try {

            int count = idExist.getRecordCountAll("coupon", null);
            int maxCount = Integer.parseInt(settings.get("maxnum.setcouponlist", "-1"));
            //登録数条件チェック
            if (maxCount > 0 && maxCount <= count) {
                logger.log(Level.SEVERE, classname, methodName, LIMIT_SET_REGISTER_CODE + " " + LIMIT_SET_REGISTER_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(LIMIT_SET_REGISTER_CODE, LIMIT_SET_REGISTER_MSG);
            }

            //店舗管理者以上が自身の管理範囲内で実行可能。
            boolean isAuth = adminUtil.checkAuth(adminID, shopID);
            //falseの場合は管理配下の店舗ではない
            if (isAuth == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            //時間をタイムスタン型に変換する
            java.sql.Timestamp stamp = null;
            if (expiryTime != null && !expiryTime.equals("")) {
                try {
                    java.util.Date format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(expiryTime);
                    stamp = new java.sql.Timestamp(format.getTime());
                } catch (ParseException pEx) {
                    logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
                    return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
                }
            }

            String regex = "";
            String sql = "";
            Pattern p;
            Matcher m;
            String sqlWhere = "WHERE";
            //変更
            if (couponID > -1) {

                String str = sqlUpdateCouponInfo;

                //カテゴリ指定あり
                if (category != null && !category.equals("")) {
                    regex = sqlWhere;
                    p = Pattern.compile(regex);
                    m = p.matcher(str);
                    sql = "," + " category='" + category + "' " + sqlWhere;
                    str = m.replaceFirst(sql);
                }

                if (priceCotegory > 0) {
                    regex = sqlWhere;
                    p = Pattern.compile(regex);
                    m = p.matcher(str);
                    sql = "," + " price_category=" + priceCotegory + " " + sqlWhere;
                    str = m.replaceFirst(sql);
                }

                if (discountCategory > 0) {
                    regex = sqlWhere;
                    p = Pattern.compile(regex);
                    m = p.matcher(str);
                    sql = "," + " discount_category=" + discountCategory + " " + sqlWhere;
                    str = m.replaceFirst(sql);
                }

                if (availableNum > 0) {
                    regex = sqlWhere;
                    p = Pattern.compile(regex);
                    m = p.matcher(str);
                    sql = "," + " available=" + availableNum + " " + sqlWhere;
                    str = m.replaceFirst(sql);
                }

                if (expiryTime != null && !expiryTime.equals("")) {
                    regex = sqlWhere;
                    p = Pattern.compile(regex);
                    m = p.matcher(str);
                    sql = "," + " expiry_date='" + expiryTime + "' " + sqlWhere;
                    str = m.replaceFirst(sql);
                }

                if (expiryNum > 0) {
                    regex = sqlWhere;
                    p = Pattern.compile(regex);
                    m = p.matcher(str);
                    sql = "," + " expiry_duration=" + expiryNum + " " + sqlWhere;
                    str = m.replaceFirst(sql);
                }

                str = str + "";

                db.query("SELECT  coupon_id FROM  coupon WHERE  coupon_id = ? FOR UPDATE", (rs) -> {
                }, couponID);

                //クーポン情報の登録
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", str));
                result = db.update(str,
                        title,
                        description,
                        terms,
                        remarks,
                        issueNum,
                        moneyLevel,
                        value,
                        enableFlag,
                        couponID
                );

                //ロゴ情報登録
                if (logo != null && !logo.equals("")) {
                    try {
                        byte[] image = Base64.decodeBase64(logo.getBytes());
                        db.update(sqlUpdateCouponLogo, image, couponID, image, couponID, couponID);
                    } catch (Exception e) {
                        logger.thrownLog(Level.SEVERE, classname, methodName, "failed logo insert.", e);
                        logger.log(Level.FINE, classname, methodName, "END");
                        return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                    }
                }
            }

            //追加
            if (couponID < 0) {

                String str = sqlCreateCouponInfo1;
                String str2 = sqlCreateCouponInfo2;

                //カテゴリ指定なし
                if (category == null || category.equals("")) {
                    category = db.queryForString(sqlSelectShopCategory, shopID);
                }

                //プライスカテゴリなし
                if (priceCotegory > 0) {
                    str = str + ", price_category";

                    regex = "\\)\\Z";
                    p = Pattern.compile(regex);
                    m = p.matcher(str2);
                    sql = ", " + priceCotegory + " " + "\\)";
                    str2 = m.replaceFirst(sql);
                }

                //割引カテゴリなし
                if (discountCategory > 0) {
                    str = str + ", discount_category";

                    regex = "\\)\\Z";
                    p = Pattern.compile(regex);
                    m = p.matcher(str2);
                    sql = ", " + discountCategory + " " + "\\)";
                    str2 = m.replaceFirst(sql);
                }

                //クーポン情報の登録
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", str + str2));
                result = db.update(str + str2,
                        shopID,
                        title,
                        description,
                        terms,
                        remarks,
                        availableNum,
                        issueNum,
                        expiryNum,
                        stamp,
                        moneyLevel,
                        value,
                        enableFlag,
                        category
                );

                //ロゴ情報登録
                if (logo != null && !logo.equals("")) {
                    try {
                        byte[] image = Base64.decodeBase64(logo.getBytes());
                        long sId = db.queryForLong("SELECT currval('coupon_coupon_id_seq')");
                        db.update(sqlCreateCouponLogo, sId, image);
                    } catch (Exception e) {
                        logger.thrownLog(Level.SEVERE, classname, methodName, "failed logo insert.", e);
                        logger.log(Level.FINE, classname, methodName, "END");
                        return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                    }
                }
            }

        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.WARNING, classname, methodName, SQL_UPDATE_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_UPDATE_ERROR_MSG);
        }

        //SQLの戻り値チェック
        if (result < 1) {
            //SQL失敗
            logger.log(Level.SEVERE, classname, methodName, SQL_ERROR_CODE + " " + SQL_ERROR_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } else {
            //正常
            String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
            logger.log(Level.FINE, classname, methodName, outParam);
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.build("ok", true);
        }
    }

    /**
     * クーポン情報削除
     *
     * @param adminID
     * @param couponID
     * @author Qnet)hanada
     * @return
     */
    @POST
    @Path("/delete_coupon")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map deleteCoupon(@FormParam("admin_id") String adminID, @FormParam("coupon_id") @DefaultValue("-1") int couponID) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id:%s, coupon_id:%d]", adminID, couponID);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        /**
         * 必須チェック
         */
        if (adminID == null || adminID.equals("") || couponID < 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("user_id");
        }

        validate = ValidationCheck.checkLong(String.valueOf(couponID));
        if (validate == false) {
            validateErr.add("coupon_id");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        final Map<String, Object> response = new HashMap<>();
        int result = 0;
        boolean flag = false;
        try {

            //クーポンの店舗IDを取得する
            Integer[] shop = new Integer[1];
            db.query(sqlSelectCouponInfo, (rs) -> {
                shop[0] = rs.getInt("shop_id");
            }, couponID);

            if (shop[0] != null) {
                //店舗管理者以上が自身の管理範囲内で実行可能。
                boolean isAuth = adminUtil.checkAuth(adminID, shop[0]);
                //falseの場合は管理配下の店舗ではない
                if (isAuth == false) {
                    logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                    logger.log(Level.FINE, classname, methodName, "END");
                    return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
                }
                this.updateSql(couponID);
            }

        } catch (Exception sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
        logger.log(Level.FINE, classname, methodName, outParam);
        logger.log(Level.FINE, classname, methodName, "END");
        //正常
        return MapBuilder.build("ok", true);
    }

    /**
     * クーポン情報削除　クエリー発行
     *
     * @param couponID
     * @return
     * @author Qnet)hanada
     * @throws RuntimeException
     */
    @Transactional
    public int updateSql(int couponID) throws RuntimeException, SQLException {

        int result = 1;
        boolean flag = false;

        try {

            //クーポン削除
            result = db.update(sqlUpdateCouponFlag, flag, couponID);

            if (result < 1) {
                //クーポンIDがあるのに、結果が0の場合は異常
                throw new SQLException("can't find couponID[" + couponID + "]");
            }

        } catch (SQLException runEx) {
            throw runEx;
        }
        return result;

    }

    /**
     * クーポン閲覧履歴記録
     *
     * @param userID
     * @param couponID
     * @param startTime
     * @param endTime
     * @author Qnet)hanada
     * @return
     */
    @POST
    @Path("/watch")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map watchCoupon(@FormParam("user_id") String userID, @FormParam("coupon_id") @DefaultValue("-1") int couponID,
            @FormParam("reading_start_time") String startTime, @FormParam("reading_end_time") String endTime) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[user_id=%s, coupon_id=%d, reading_start_time=%s, reading_end_time=%s]", userID, couponID, startTime, endTime);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);
        try {
            aLogger.log(userID, "WATCH_COUPON", null, String.format("[username=%s] [coupon_id=%d] [reading_start_time=%s] [reading_end_time=%s]", userID, couponID, startTime, endTime));
        } catch (Exception ex) {
        }

        //必須項目チェック
        if (userID == null || couponID < 0 || startTime == null || endTime == null) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        //必須項目チェック
        if (userID.equals("") || startTime.equals("") || endTime.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(userID);
        if (validate == false) {
            validateErr.add("user_id");
        }

        validate = ValidationCheck.checkLong(String.valueOf(couponID));
        if (validate == false) {
            validateErr.add("coupon_id");
        }

        validate = ValidationCheck.checkDate(startTime);
        if (validate == false) {
            validateErr.add("reading_start_time");
        }

        validate = ValidationCheck.checkDate(endTime);
        if (validate == false) {
            validateErr.add("reading_end_time");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        final Map<String, Object> response = new HashMap<>();
        //閲覧時間を算出
        //時間をタイムスタン型に変換する
        java.sql.Timestamp stampStart = null;
        java.sql.Timestamp stampEnd = null;
        int total = 0;

        try {
            java.util.Date start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startTime);
            java.util.Date end = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endTime);
            stampStart = new java.sql.Timestamp(start.getTime());
            stampEnd = new java.sql.Timestamp(end.getTime());

            //閲覧時間を秒に変換
            total = (int) TimeUnit.MILLISECONDS.toSeconds(stampEnd.getTime() - stampStart.getTime());

        } catch (ParseException pEx) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        int result = 0;
        boolean flag = false;
        try {

            /**
             * 権限チェック　ユーザのみ
             */
            int auth = adminUtil.getUserType(userID);
            if (auth != USER_INFO_TYPE_USER) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s, %s, %s, %s, %d]", sqlUpdateCouponReadingHistory, userID, couponID, stampStart, stampEnd, total));
            result = db.update(sqlUpdateCouponReadingHistory, userID, couponID, stampStart, stampEnd, total);

        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        //0件の場合はUpdate失敗
        if (result < 1) {
            logger.log(Level.SEVERE, classname, methodName, SQL_ERROR_CODE + " " + SQL_ERROR_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } else {
            //正常
            String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
            logger.log(Level.FINE, classname, methodName, outParam);
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.build("ok", true);
        }
    }

    /**
     * ユーザ趣向学習
     *
     * @param adminID
     * @param startTime
     * @param endTime
     * @author Qnet)hanada
     * @return
     */
    @POST
    @Path("/learning")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map exeCouponLearning(@FormParam("admin_id") String adminID) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[adminID=%s]", adminID);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        Map<String, Object> result = new HashMap<>();
        long[] type = {0};

        boolean response = false;

        //必須チェック
        if (adminID == null) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        //必須チェック
        if (adminID.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        try {
            //権限チェック
            int adminType = 0;
            adminType = adminUtil.getUserType(adminID);

            if (adminType != USER_INFO_TYPE_SYSTEM) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            ICMContext cntxt = new ICMContext(db, settings, clock, null, logger);
            CSAlgoGateway gateWay = new CSAlgoGateway(cntxt);
            response = gateWay.learnCSL();

            if (response) {
                result = MapBuilder.build("ok", true);
            } else {
                result = ErrorFactory.createError(CS_ALGO_RESPONSE_ERR_CODE, CS_ALGO_RESPONSE_ERR_MSG);
            }
        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } catch (IOException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "IOException.", ex);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        String outParam = "outputParam[" + result.toString() + "]";
        logger.log(Level.FINE, classname, methodName, outParam);
        logger.log(Level.FINE, classname, methodName, "END");
        return result;

    }

}
