package com.fujitsu.coe.tmh.web.product.route.sd;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author chuakayick
 */
public class SDDictionary {
    private static final Pattern UNCAPPED = Pattern.compile(".+, ([a-z]).+");

    public String fixLocation(String input) {
        input = input.replaceAll("Dhobby Ghaut", "Dhoby Ghaut");
        input = input.replaceAll("Harbour Front", "HarbourFront");
        Matcher matcher = UNCAPPED.matcher(input);
        if (matcher.find()) {
            StringBuilder buf = new StringBuilder(input);
            int pos = matcher.start(1);
            buf.setCharAt(pos, Character.toUpperCase(input.charAt(pos)));
            return buf.toString();
        }
        return input;
    }
}
