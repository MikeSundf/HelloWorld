/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.shop;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.sim.VirtualTime;
import com.fujitsu.coe.tmh.web.user.LogLocation;
import com.fujitsu.coe.tmh.web.util.AdminType;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.IdExistCheck;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import com.fujitsu.coe.tmh.web.util.LogManage;
import com.fujitsu.coe.tmh.web.util.ParamConstants;
import com.fujitsu.coe.tmh.web.util.ValidationCheck;
import static com.fujitsu.coe.tmh.web.util.ValidationCheck.*;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ws.rs.GET;
import javax.ws.rs.QueryParam;
import org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64;

/**
 * 店舗情報
 *
 * @author qnet8733
 */
@Path("/")
@ApplicationScoped
public class ShopService {

    String classname = ShopService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    @ClasspathResource("CreateShopInfo_1.sql")
    private String sqlCreateShopInfo1;
    @Inject
    @ClasspathResource("CreateShopInfo_2.sql")
    private String sqlCreateShopInfo2;
    @Inject
    @ClasspathResource("UpdateShopInfo.sql")
    private String sqlUpdateShopInfo;
    @Inject
    @ClasspathResource("UpdateCouponFlag.sql")
    private String sqlUpdateCouponFlag;
    @Inject
    @ClasspathResource("UpdateShopFlag.sql")
    private String sqlUpdateShopFlag;
    @Inject
    @ClasspathResource("SelectProductCoupon.sql")
    private String sqlSelectProductCoupon;
    @Inject
    @ClasspathResource("SelectCouponReading.sql")
    private String sqlSelectCouponReading;
    @Inject
    @ClasspathResource("SelectShopEvaluation.sql")
    private String sqlSelectShopEvaluation;
    @Inject
    @ClasspathResource("SelectShopUserLocation.sql")
    private String sqlSelectShopUserLocation;
    @Inject
    @ClasspathResource("SelectUserData.sql")
    private String sqlSelectUserData;
    @Inject
    @ClasspathResource("SelectUserPreference.sql")
    private String sqlSelectUserPreference;
    @Inject
    @ClasspathResource("CreateShopLogo.sql")
    private String sqlCreateShopLogo;
    @Inject
    @ClasspathResource("UpdateShopLogo.sql")
    private String sqlUpdateShopLogo;
    @Inject
    private SystemSettings settings;
    @Inject
    private AdminType adminUtil;
    @Inject
    private LogManage logger;
    @Inject
    private IdExistCheck idExist;

    /**
     * 店舗リスト取得 (API No.22)
     *
     * @param admin [IN] 管理者ID(必須)
     * @param venue [IN] 開催地ID
     * @return 管理対象店舗情報リスト
     * @author Qnet)mikami
     */
    @GET
    @Path("/retail")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String, Object> getRetailList(
            @QueryParam("admin_id") String admin,
            @QueryParam("venue_id") @DefaultValue("0") Integer venue
    ) throws SQLException {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + admin + ", venue_id=" + venue + "]");

        // 必須パラメータチェック
        if (admin == null || admin.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(admin))
                || !(ValidationCheck.checkIntegerId(String.valueOf(venue)))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // パラメタチェック
        int user_type;
        try {
            // 管理者ID指定がユーザDBに存在しない場合はエラー
            if (idExist.validateUserId(admin) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
            // 開催地IDパラメタありの場合は開催地IDをチェック
            if (venue != 0) {
                if (idExist.validateaVenueId(venue) == false) {
                    logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                    return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
                }
            }

            // 管理者IDのユーザ種別がユーザの場合はエラー(NO_AUTHORITY_CODE：権限がない)
            user_type = adminUtil.getUserType(admin);
            if (user_type <= 0) {
                logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 有効な店舗のDB検索SQL
        String sql
                = "SELECT ".concat(
                        "shop_id, ").concat(
                                "name, ").concat(
                                "venue_id, ").concat(
                                "category, ").concat(
                                "address, ").concat(
                                "tel, ").concat(
                                "remarks, ").concat(
                                "location, ").concat(
                                "map_hint, ").concat(
                                "passcode, ").concat(
                                "gender_age_group, ").concat(
                                "lat, ").concat(
                                "lon ").concat(
                                "FROM ").concat(
                                "shop ").concat(
                                "WHERE ").concat(
                                "enable_flag=? ");
        // ユーザIDと管理種別による管理者情報DBのDB検索SQL
        String sql_admin_info
                = "SELECT ".concat(
                        "manage_id ").concat(
                                "FROM ").concat(
                                "admin_info ").concat(
                                "WHERE ").concat(
                                "user_id=? AND ").concat(
                                "type=?");
        // 管理者IDの権限毎に店舗情報リストを取得
        final Map<String, Object> response = new HashMap<>();
        final ArrayList<Map> retails;
        retails = new ArrayList<>();
        try {
            switch (user_type) {
                case USER_INFO_TYPE_SYSTEM: // システム管理者の場合
                    // システム管理者で開催地IDパラメタありの場合は開催地IDが一致する有効な店舗リストを取得
                    if (venue != 0) {
                        sql = sql.concat(" AND venue_id=?");
                        db.query(sql, (rs) -> {
                            final Map<String, Object> res = new HashMap<>();
                            res.put("shop_id", rs.getInt(1));
                            res.put("name", rs.getString(2));
                            res.put("venue_id", rs.getInt(3));
                            res.put("category", rs.getString(4));
                            res.put("address", rs.getString(5));
                            res.put("tel", rs.getString(6));
                            res.put("remarks", rs.getString(7));
                            res.put("location", rs.getString(8));
                            res.put("map_hint", rs.getString(9));
                            res.put("passcode", rs.getString(10));
                            res.put("gender_age_group", rs.getString(11));
                            res.put("lat", rs.getDouble(12));
                            res.put("lon", rs.getDouble(13));
                            retails.add(res);
                        }, ENABLE_FLAG, venue);
                        // システム管理者で開催地IDパラメタなしの場合は有効な全店舗リストを取得
                    } else {
                        db.query(sql, (rs) -> {
                            final Map<String, Object> res = new HashMap<>();
                            res.put("shop_id", rs.getInt(1));
                            res.put("name", rs.getString(2));
                            res.put("venue_id", rs.getInt(3));
                            res.put("category", rs.getString(4));
                            res.put("address", rs.getString(5));
                            res.put("tel", rs.getString(6));
                            res.put("remarks", rs.getString(7));
                            res.put("location", rs.getString(8));
                            res.put("map_hint", rs.getString(9));
                            res.put("passcode", rs.getString(10));
                            res.put("gender_age_group", rs.getString(11));
                            res.put("lat", rs.getDouble(12));
                            res.put("lon", rs.getDouble(13));
                            retails.add(res);
                        }, ENABLE_FLAG);
                    }
                    break;
                case USER_INFO_TYPE_VENUE: // 開催地管理者の場合
                    if (venue != 0) {
                        // 開催地IDパラメタありの場合はパラメタ指定開催地が管理対象でなければエラー(NO_AUTHORITY_CODE：権限がない)
                        if (adminUtil.isManageVenue(admin, venue) == false) {
                            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
                        }
                        // 開催地管理者で開催地IDパラメタありの場合はパラメタ指定開催地の店舗リストを取得
                        sql = sql.concat(" AND venue_id=?");
                        db.query(sql, (rs) -> {
                            final Map<String, Object> res = new HashMap<>();
                            res.put("shop_id", rs.getInt(1));
                            res.put("name", rs.getString(2));
                            res.put("venue_id", rs.getInt(3));
                            res.put("category", rs.getString(4));
                            res.put("address", rs.getString(5));
                            res.put("tel", rs.getString(6));
                            res.put("remarks", rs.getString(7));
                            res.put("location", rs.getString(8));
                            res.put("map_hint", rs.getString(9));
                            res.put("passcode", rs.getString(10));
                            res.put("gender_age_group", rs.getString(11));
                            res.put("lat", rs.getDouble(12));
                            res.put("lon", rs.getDouble(13));
                            retails.add(res);
                        }, ENABLE_FLAG, venue);
                    } else {
                        // 開催地管理者で開催地IDパラメタなしの場合は管理対象開催地の店舗リストを取得
                        sql = sql.concat(" AND venue_id IN (").concat(sql_admin_info).concat(")");
                        db.query(sql, (rs) -> {
                            final Map<String, Object> res = new HashMap<>();
                            res.put("shop_id", rs.getInt(1));
                            res.put("name", rs.getString(2));
                            res.put("venue_id", rs.getInt(3));
                            res.put("category", rs.getString(4));
                            res.put("address", rs.getString(5));
                            res.put("tel", rs.getString(6));
                            res.put("remarks", rs.getString(7));
                            res.put("location", rs.getString(8));
                            res.put("map_hint", rs.getString(9));
                            res.put("passcode", rs.getString(10));
                            res.put("gender_age_group", rs.getString(11));
                            res.put("lat", rs.getDouble(12));
                            res.put("lon", rs.getDouble(13));
                            retails.add(res);
                        }, ENABLE_FLAG, admin, ADMIN_TYPE_VENUE);
                    }
                    break;
                case USER_INFO_TYPE_SHOP: // 店舗管理者の場合
                default:
                    // 管理対象の店舗リストを取得
                    sql = sql.concat(" AND shop_id IN (").concat(sql_admin_info).concat(")");
                    db.query(sql, (rs) -> {
                        final Map<String, Object> res = new HashMap<>();
                        res.put("shop_id", rs.getInt(1));
                        res.put("name", rs.getString(2));
                        res.put("venue_id", rs.getInt(3));
                        res.put("category", rs.getString(4));
                        res.put("address", rs.getString(5));
                        res.put("tel", rs.getString(6));
                        res.put("remarks", rs.getString(7));
                        res.put("location", rs.getString(8));
                        res.put("map_hint", rs.getString(9));
                        res.put("passcode", rs.getString(10));
                        res.put("gender_age_group", rs.getString(11));
                        res.put("lat", rs.getDouble(12));
                        res.put("lon", rs.getDouble(13));
                        retails.add(res);
                    }, ENABLE_FLAG, admin, ADMIN_TYPE_SHOP);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        // 出力店舗数が店舗リスト取得数最大値以上の場合はエラー(LIMIT_GET_CODE：取得数の上限に達した)
        Integer maxnum = Integer.parseInt(settings.get("maxnum.getshoplist", DB_DEFAULT_MAX_NUM));
        if (retails.size() >= maxnum) {
            logger.log(Level.WARNING, classname, methodName, LIMIT_GET_MSG);
            return ErrorFactory.createError(LIMIT_GET_CODE, LIMIT_GET_MSG);
        }
        // 取得した店舗リストのMAPを返す
        response.put("shops", retails);
        logger.log(Level.FINE, classname, methodName, "END");
        return response;
    }

    /**
     * 店舗評価 (API No.32)
     *
     * @param user_id [IN] ユーザID(必須)
     * @param shop_id [IN] 店舗ID(必須)
     * @param evaluation [IN] 評価値(必須)
     * @return 処理結果
     * @auther Qnet)mikami
     */
    @POST
    @Path("/rate_retail")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String, Object> rateRetail(@FormParam("user_id") String user_id,
            @FormParam("shop_id") Integer shop_id,
            @FormParam("evaluation") @DefaultValue("0") Integer evaluation) throws SQLException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", shop_id=" + shop_id + ", evaluation=" + evaluation + "]");

        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(user_id) == false) {
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
            // 店舗IDチェック
            if (idExist.validateShopId(shop_id) == false) {
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        // 評価値チェック
        if (ValidationCheck.checkEvaluation(evaluation) == false) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // DB取得
        try {
            // 種別取得
            long regcnt = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?", user_id);
            if (regcnt == 0) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
                return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
            }
            long admin_type = db.queryForLong("SELECT type FROM user_info WHERE user_id=?", user_id);
            // 権限確認
            if (admin_type != USER_INFO_TYPE_USER) {
                logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 評価結果DBを新規登録して正常終了
        try {
            db.update("INSERT INTO shop_evaluation(user_id, shop_id, value, time) VALUES(?,?,?,NOW())", user_id, shop_id, evaluation);
            logger.log(Level.FINE, classname, methodName, "INSERT user_info:[user_id=" + user_id + ", shop_id=" + shop_id + ", evaluation=" + evaluation + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     * 店舗情報設定
     *
     * @param adminID
     * @param shopID
     * @param shopName
     * @param venueID
     * @param category
     * @param address
     * @param tel
     * @param remarks
     * @param location
     * @param map_hint
     * @param passcode
     * @param utilityValue
     * @param ageGroup
     * @param lat
     * @param lon
     * @param logo
     * @return
     */
    @POST
    @Path("/retailInfo")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @VirtualTime
    public Map setRetail(@FormParam("admin_id") String adminID,
            @FormParam("shop_id") @DefaultValue("0") int shopID,
            @FormParam("name") String shopName,
            @FormParam("venue_id") @DefaultValue("-1") int venueID,
            @FormParam("category") String category,
            @FormParam("address") String address,
            @FormParam("tel") @DefaultValue("") String tel,
            @FormParam("remarks") @DefaultValue("") String remarks,
            @FormParam("location") String location,
            @FormParam("map_hint") String map_hint,
            @FormParam("passcode") String passcode,
            @FormParam("utility_value") @DefaultValue("") Double utilityValue,
            @FormParam("gender_age_group") @DefaultValue("") String ageGroup,
            @FormParam("lat") @DefaultValue("-1") Float lat,
            @FormParam("lon") @DefaultValue("-1") Float lon,
            @FormParam("logo") String logo
    ) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id:%s, shop_id:%d, name:%s, venue_id:%d, category:%s, address:%s, tel:%s, remarks:%s, location:%s, map_hint:%s, passcode:%s, utility_value:%f, gender_age_group:%s]", adminID, shopID, shopName, venueID, category, address, tel, remarks, location, map_hint, passcode, utilityValue, ageGroup);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        //必須チェック キーがない場合
        if (adminID == null || shopName == null || category == null || venueID < 0
                || address == null || location == null || map_hint == null || passcode == null) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        //必須チェック　キーはあるがブランクの場合
        if (adminID.equals("") || shopName.equals("") || category.equals("")
                || address.equals("") || location.equals("") || map_hint.equals("") || passcode.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(shopID));
        if (validate == false) {
            validateErr.add("shop_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(venueID));
        if (validate == false) {
            validateErr.add("venue_id");
        }

        validate = ValidationCheck.checkStr100(shopName);
        if (validate == false) {
            validateErr.add("shopName");
        }

        validate = ValidationCheck.checkStr45(category);
        if (validate == false) {
            validateErr.add("category");
        }

        validate = ValidationCheck.checkStr100(address);
        if (validate == false) {
            validateErr.add("address");
        }

        validate = ValidationCheck.checkStr45(tel);
        if (validate == false) {
            validateErr.add("tel");
        }

        validate = ValidationCheck.checkStr100(remarks);
        if (validate == false) {
            validateErr.add("remarks");
        }

        validate = ValidationCheck.checkStr120(location);
        if (validate == false) {
            validateErr.add("location");
        }

        validate = ValidationCheck.checkStr120(map_hint);
        if (validate == false) {
            validateErr.add("map_hint");
        }

        validate = ValidationCheck.checkStr45(passcode);
        if (validate == false) {
            validateErr.add("passcode");
        }

        validate = ValidationCheck.checkStr120(ageGroup);
        if (validate == false) {
            validateErr.add("age_group");
        }

        int res = -1;
        if (lat != -1) {
            res = ValidationCheck.checkLatLon(lat);
            if (res == NUM_DECIMAL_OVER) {
                //小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(lat);
            } else if (res != 0) {
                validateErr.add("lat");
            }
        }

        if (lon != -1) {
            res = ValidationCheck.checkLatLon(lon);
            if (res == NUM_DECIMAL_OVER) {
                //小数部の最大桁数超えの場合は四捨五入する
                lon = ValidationCheck.roundUpLatLon(lon);
            } else if (res != 0) {
                validateErr.add("lon");
            }
        }

        if (shopID == 0 && (logo == null || logo.equals(""))) {
            validateErr.add("logo");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        //店舗IDが存在しない場合は登録、存在する場合は変更とする。
        int result = 0;
        boolean type = false;
        boolean enableFlag = true;

        try {

            //権限が開催地管理者以上かをチェックする
            int auth = adminUtil.getUserType(adminID);
            if (auth == USER_INFO_TYPE_SYSTEM || auth == USER_INFO_TYPE_VENUE) {
                type = true;
            } else {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            if (shopID != 0) {
                //権限チェック 開催地管理者以上で自分の配下か
                type = adminUtil.checkAuth(adminID, shopID);
            }

            if (type == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            // 開催地IDが自分の配下か
            if (auth == USER_INFO_TYPE_VENUE && adminUtil.isManageVenue(adminID, venueID) == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);                
            }
        
            int count = idExist.getRecordCountAll("shop", null);
            int maxCount = Integer.parseInt(settings.get("maxnum.setshoplist", "-1"));
            //登録数条件チェック
            if (maxCount > 0 && maxCount <= count) {
                logger.log(Level.SEVERE, classname, methodName, LIMIT_SHOP_REGISTER_CODE + " " + LIMIT_SHOP_REGISTER_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(LIMIT_SHOP_REGISTER_CODE, LIMIT_SHOP_REGISTER_MSG);
            }

            //店舗IDが指定されている場合
            if (shopID != 0) {
                String str = sqlUpdateShopInfo;

                /**
                 * オプションパラメータの設定
                 */
                if (tel != null && !tel.equals("")) {
                    str = String.format(str + " %s='%s', ", "tel", tel);
                }

                if (remarks != null && !remarks.equals("")) {
                    str = String.format(str + " %s='%s', ", "remarks", remarks);
                }

                if (ageGroup != null && !ageGroup.equals("")) {
                    str = String.format(str + " %s='%s', ", "gender_age_group", ageGroup);
                }

                if (lon > 0) {
                    str = String.format(str + " %s=%f, ", "lon", lon);
                }

                if (lat > 0) {
                    str = String.format(str + " %s=%f, ", "lat", lat);
                }

                if (str.length() > 0) {
                    str = str.substring(0, str.length() - 2);
                }

                str = str + " WHERE shop_id = " + shopID;

                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", str)
                        + " Param:[" + shopName + ", " + venueID + ", "
                        + category + ", " + address + ", " + location + ", " + map_hint + ", "
                        + passcode + ", " + enableFlag + "]");

                db.query("SELECT  shop_id FROM  shop WHERE  shop_id = ? FOR UPDATE", (rs) -> {
                }, shopID);

                result = db.update(str,
                        shopName, venueID, category, address,
                        location, map_hint, passcode, enableFlag);

                //ロゴ情報登録
                if (logo != null && !logo.equals("")) {
                    try {
                        String regex2 = "^.*,";
                        Pattern p2 = Pattern.compile(regex2);
                        Matcher m2 = p2.matcher(logo);
                        String data = m2.replaceFirst("");

                        byte[] image = Base64.decodeBase64(data.getBytes());
                        db.update(sqlUpdateShopLogo, image, shopID);
                    } catch (Exception e) {
                        logger.thrownLog(Level.SEVERE, classname, methodName, "failed logo insert.", e);
                        logger.log(Level.FINE, classname, methodName, "END");
                        return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                    }
                }
            }

            //店舗IDが指定されていない場合
            if (shopID == 0) {
                /**
                 * オプションパラメータの設定
                 */
                String regex = "";
                String sql = "";
                Pattern p;
                Matcher m;
                String str = sqlCreateShopInfo1;
                String str2 = sqlCreateShopInfo2;

                List<Object> option = new ArrayList<>();
                if (tel != null && !tel.equals("")) {
                    str = str + ", tel";
                    option.add("'" + tel + "'");
                    //str2 = this.createSQL(str2, "'" + tel + "'");
                }

                if (remarks != null && !remarks.equals("")) {
                    str = str + ", remarks";
                    //str2 = this.createSQL(str2, "'" + remarks + "'");
                    option.add("'" + remarks + "'");
                }

                if (ageGroup != null && !ageGroup.equals("")) {
                    str = str + ", gender_age_group ";
                    //str2 = this.createSQL(str2, "'" + ageGroup + "'");
                    option.add("'" + ageGroup + "'");
                }

                if (lon > 0) {
                    str = str + ", lon";
                    //str2 = this.createSQL(str2, lon);
                    option.add(lon.toString());
                }

                if (lat > 0) {
                    str = str + ", lat";
                    //str2 = this.createSQL(str2, lat);
                    option.add(lat.toString());
                }
                String[] arr = new String[option.size()];
                option.toArray(arr);
                String separator = " , ";
                str2 = str2 + ", " + String.join(separator, arr) + ")";

                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", (str + str2))
                        + " Param:[" + shopName + ", " + venueID + ", "
                        + category + ", " + address + ", " + location + ", " + map_hint + ", "
                        + passcode + ", " + enableFlag + "]");

                //店舗情報登録
                result = db.update(str + str2,
                        shopName,
                        venueID,
                        category,
                        address,
                        location,
                        map_hint,
                        passcode,
                        enableFlag);

                //ロゴ情報登録
                if (logo != null && !logo.equals("")) {
                    try {
                        String regex2 = "^.*,";
                        Pattern p2 = Pattern.compile(regex2);
                        Matcher m2 = p2.matcher(logo);
                        String data = m2.replaceFirst("");

                        byte[] image = Base64.decodeBase64(data.getBytes());
                        long sId = db.queryForLong("SELECT currval('shop_shop_id_seq')");
                        db.update(sqlCreateShopLogo, sId, image);
                    } catch (Exception e) {
                        logger.thrownLog(Level.SEVERE, classname, methodName, "failed logo insert.", e);
                        logger.log(Level.FINE, classname, methodName, "END");
                        return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                    }
                }

            }
        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.WARNING, classname, methodName, SQL_UPDATE_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_UPDATE_ERROR_MSG);
        }

        //SQLの戻り値チェック
        if (result < 1) {
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } else {
            //正常
            Map<String, Object> resuponse = MapBuilder.build("ok", true);
            logger.log(Level.FINE, classname, methodName, "OutputParam:[" + resuponse.toString() + "]");
            logger.log(Level.FINE, classname, methodName, "END");
            return resuponse;
        }
    }

    @POST
    @Path("/delete_retail")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @VirtualTime
    @Transactional
    public Map deleteRetail(@FormParam("admin_id") String adminID, @FormParam("shop_id") @DefaultValue("-1") int shopID) {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id:%s, shop_id:%d]", adminID, shopID);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        /**
         * 必須チェック
         */
        if (adminID == null || adminID.equals("") || shopID < 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(shopID));
        if (validate == false) {
            validateErr.add("shop_id");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        //開催地管理者以上が自身の管理範囲内で実行可能。
        final Map<String, Object> response = new HashMap<>();
        int result = 0;
        boolean flag = false;
        boolean type = false;
        int userType = 0;
        try {

            //権限チェック1　開催地管理者以上か
            userType = adminUtil.getUserType(adminID);
            if (userType != ParamConstants.USER_INFO_TYPE_SYSTEM && userType != ParamConstants.USER_INFO_TYPE_VENUE) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            //権限チェック2 自分の配下か
            type = adminUtil.checkAuth(adminID, shopID);
            if (type == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
            this.updateSql(shopID);
        } catch (SQLException sqlEx) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, sqlEx);
            logger.log(Level.FINE, classname, methodName, "END");
            //SQL失敗
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        String outParam = "outputParam[" + MapBuilder.build("ok", true).toString() + "]";
        logger.log(Level.FINE, classname, methodName, outParam);
        logger.log(Level.FINE, classname, methodName, "END");
        //正常
        return MapBuilder.build("ok", true);

    }

    /**
     * 店舗情報削除
     *
     * @param venueID
     * @return
     * @throws RuntimeException
     */
    @VirtualTime
    public int updateSql(int shopID) throws SQLException {

        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        int result = 0;
        boolean flag = false;

        try {

            //クーポン削除
            //結果が0の場合は許容
            logger.log(Level.FINE, classname, methodName,
                    String.format("SQL:[%s] Param:[%s, %d]", (sqlUpdateCouponFlag), flag, shopID));
            result = db.update(sqlUpdateCouponFlag, flag, shopID);

            //店舗削除
            if (shopID != 0) {
                result = db.update(sqlUpdateShopFlag, flag, shopID);
                if (result < 1) {
                    //shopIDがあるのに、結果が0の場合は異常
                    throw new SQLException("can't find shopID[" + shopID + "].");
                }
            }

        } catch (SQLException runEx) {
            throw runEx;
        }
        return result;

    }

    /**
     *
     * 店舗利用履歴確認
     *
     * 管理者ID、店舗ID、取得開始日時、取得終了日時を入力情報として、該当店舗にてどんなユーザが
     * どのクーポンを利用したか、どう店舗を評価したかの履歴データをリストで出力する。 正常終了した場合はユーザID、性別、年齢層、興味のあるカテゴリ、
     * クーポン使用履歴、クーポン閲覧履歴、店舗評価履歴のリストを返し、異常終了した場合はエラーコードを返す。
     * 店舗管理者以上が自身の管理範囲内で実行可能。
     *
     * @param adminID
     * @param shopID
     * @param startTime
     * @param endTime
     * @return
     */
    @GET
    @Path("/retail_record")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @VirtualTime
    @Transactional
    public Map getRetailRecord(@QueryParam("admin_id") String adminID,
            @QueryParam("shop_id") @DefaultValue("-1") int shopID,
            @QueryParam("start_time") String startTime,
            @QueryParam("end_time") String endTime
    ) {
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        String inputParam = String.format("InputParam:[admin_id=%s, shop_id=%d, start_time=%s, end_time=%s]", adminID, shopID, startTime, endTime);
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, inputParam);

        //必須項目チェック
        if (adminID == null || adminID.equals("") || shopID < 0
                || startTime == null || startTime.equals("") || endTime == null || endTime.equals("")) {
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        /**
         * バリデーションチェック
         */
        List<Object> validateErr = new ArrayList<>();
        boolean validate = checkUserId(adminID);
        if (validate == false) {
            validateErr.add("admin_id");
        }

        validate = ValidationCheck.checkIntegerId(String.valueOf(shopID));
        if (validate == false) {
            validateErr.add("shop_id");
        }

        validate = checkDate(startTime);
        if (validate == false) {
            validateErr.add("reading_start_time");
        }

        validate = checkDate(endTime);
        if (validate == false) {
            validateErr.add("reading_end_time");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        int result = 0;
        boolean flag = false;
        boolean type = false;

        try {

            //権限チェック 開催地管理者以上で自分の配下か
            type = adminUtil.checkAuth(adminID, shopID);
            if (type == false) {
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }

            Map<String, List> response = new HashMap<>();
            List<Object> couponUse = new ArrayList<>();
            List<Object> history = new ArrayList<>();
            List<Object> location = new ArrayList<>();
            List<Object> evaluation = new ArrayList<>();
            List<Object> nullList = new ArrayList<>();
            List<Object> records = new ArrayList<Object>();

            String rowName = "";
            String baseRowName = "";
            String joinRowName = "";

            //クーポン利用の取得
            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%d]", sqlSelectProductCoupon, shopID));
            List<Integer> couponList = new ArrayList<>();
            db.query(sqlSelectProductCoupon, (ResultSet rs) -> {
                Map<String, Object> resultQuery = new HashMap<>();
                resultQuery.put("user_id", rs.getString("user_id"));
                resultQuery.put("coupon_id", rs.getInt("coupon_id"));
                resultQuery.put("time", rs.getString("redemption_time"));
                couponList.add(rs.getInt("coupon_id"));
                couponUse.add(resultQuery);
            }, shopID);

            //ユーザごとにまとめる
            List<Object> couponUseList = new ArrayList<Object>();
            rowName = "history_coupon_use";
            couponUseList = this.collectDateList(couponUse, rowName);

            if (couponUseList.size() > 0) {
                //履歴の取得
                String couponReadingSql = sqlSelectCouponReading + " WHERE ";
                for (int i = 0; i < couponList.size(); i++) {
                    couponReadingSql = couponReadingSql + " coupon_id = " + couponList.get(i) + " OR ";
                }
                if (couponReadingSql.length() > 0) {
                    couponReadingSql = couponReadingSql.substring(0, couponReadingSql.length() - 3);
                    couponReadingSql = couponReadingSql + " ORDER BY user_id, coupon_id, reading_start_time";
                }

                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", couponReadingSql));
                db.query(couponReadingSql, (ResultSet rs) -> {
                    Map<String, Object> resultQuery = new HashMap<>();
                    resultQuery.put("user_id", rs.getString("user_id"));
                    resultQuery.put("coupon_id", rs.getInt("coupon_id"));
                    resultQuery.put("time", rs.getString("reading_start_time"));
                    history.add(resultQuery);
                });
            }

            List<Object> histories = new ArrayList<>();
            rowName = "history_coupon_refer";
            histories = this.collectDateList(history, rowName);

            baseRowName = "history_coupon_use";
            joinRowName = "history_coupon_refer";
            records = joinDateList(histories, couponUseList, joinRowName, baseRowName);

            //ユーザロケーション
            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%d]", sqlSelectShopUserLocation, shopID));
            db.query(sqlSelectShopUserLocation, (ResultSet rs) -> {
                Map<String, Object> resultQuery = new HashMap<>();
                resultQuery.put("user_id", rs.getString("user_id"));
                resultQuery.put("time", rs.getString("time"));
                location.add(resultQuery);
            }, shopID);

            List<Object> locations = new ArrayList<>();
            rowName = "history_visit";
            locations = this.collectDateList(location, rowName);

            baseRowName = "history_visit";
            joinRowName = "history_visit";
            records = joinDateList(locations, records, joinRowName, baseRowName);

            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%d]", sqlSelectShopEvaluation, shopID));
            db.query(sqlSelectShopEvaluation, (ResultSet rs) -> {
                Map<String, Object> resultQuery = new HashMap<>();
                resultQuery.put("user_id", rs.getString("user_id"));
                resultQuery.put("evaluation", rs.getInt("value"));
                resultQuery.put("time", rs.getString("time"));
                evaluation.add(resultQuery);
            }, shopID);

            List<Object> evaluations = new ArrayList<>();
            rowName = "history_evaluation";
            evaluations = this.collectDateList(evaluation, rowName);

            baseRowName = "history_evaluation";
            joinRowName = "history_evaluation";
            records = joinDateList(evaluations, records, joinRowName, baseRowName);

            //登録数条件チェック
            int maxCount = Integer.parseInt(settings.get("maxnum.getretailrecord", "-1"));
            if (maxCount > 0 && maxCount < records.size()) {
                logger.log(Level.SEVERE, classname, methodName, LIMIT_GET_CODE + " " + LIMIT_GET_MSG);
                return ErrorFactory.createError(LIMIT_GET_CODE, LIMIT_GET_MSG);
            }

            //該当データなし
            if (records.size() < 1) {
                response.put("records", records);
                String outParam = "outputParam[" + response.toString() + "]";
                logger.log(Level.FINE, classname, methodName, outParam);
                logger.log(Level.FINE, classname, methodName, "END");
                return response;
            }

            String sqlUserData = sqlSelectUserData + " WHERE ";
            String sqlUserProference = sqlSelectUserPreference + " WHERE ";

            List<String> userList = new ArrayList<>();
            for (Object record : records) {
                Map<String, Object> map = (Map<String, Object>) record;
                userList.add((String) map.get("user_id"));
                sqlUserData = sqlUserData + " user_id = '" + (String) map.get("user_id") + "' OR ";
                sqlUserProference = sqlUserProference + " user_id = '" + (String) map.get("user_id") + "' OR ";
            }

            if (sqlUserData.length() > 0) {
                sqlUserData = sqlUserData.substring(0, sqlUserData.length() - 3);
                sqlUserData = sqlUserData + " ORDER BY user_id";

                sqlUserProference = sqlUserProference.substring(0, sqlUserProference.length() - 3);
                sqlUserProference = sqlUserProference + " ORDER BY user_id, pref_key";
            }

            //ユーザ情報の取得
            List<Object> userDataList = new ArrayList<>();
            List<Object> userDataAgeList = new ArrayList<>();
            List<Object> userDataGenderList = new ArrayList<>();

            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", sqlUserData));
            db.query(sqlUserData, (ResultSet rs) -> {
                Map<String, Object> resultQuery = new HashMap<>();
                resultQuery.put("user_id", rs.getString("user_id"));
                resultQuery.put("agegroup", rs.getString("age_group"));
                userDataAgeList.add(resultQuery);
                resultQuery = new HashMap<>();
                resultQuery.put("user_id", rs.getString("user_id"));
                resultQuery.put("gender", rs.getString("gender"));
                userDataGenderList.add(resultQuery);
            });

            baseRowName = "agegroup";
            joinRowName = "agegroup";
            records = joinDateList(userDataAgeList, records, joinRowName, baseRowName);
            baseRowName = "gender";
            joinRowName = "gender";
            records = joinDateList(userDataGenderList, records, joinRowName, baseRowName);

            List<Object> proference = new ArrayList<>();
            logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s]", sqlUserProference));
            db.query(sqlUserProference, (ResultSet rs) -> {
                Map<String, Object> resultQuery = new HashMap<>();
                resultQuery.put("user_id", rs.getString("user_id"));
                resultQuery.put("pref_key", rs.getString("pref_key"));
                resultQuery.put("pref_value", rs.getString("pref_value"));
                proference.add(resultQuery);
            });
            List<Object> proferences = new ArrayList<>();
            rowName = "categories";
            proferences = this.collectDateList(proference, rowName);

            baseRowName = "categories";
            joinRowName = "categories";
            records = joinDateList(proferences, records, joinRowName, baseRowName);

            response.put("records", records);

            try {
                if (logger.settinglogLevel > 4) {
                    // 変換
                    ObjectMapper objectMapper = new ObjectMapper();
                    String json = objectMapper.writeValueAsString(response);
                    String outParam = "outputParam[" + json + "]";
                    logger.log(Level.FINE, classname, methodName, outParam);
                }
            } catch (JsonProcessingException jex) {
            }
            logger.log(Level.FINE, classname, methodName, "END");
            return response;
        } catch (SQLException ex) {
            //SQL失敗
            logger.thrownLog(Level.SEVERE, classname, methodName, SQL_ERROR_MSG, ex);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        } catch (Exception ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, SYSTEM_ERROR_CODE + " " + SYSTEM_ERROR_MSG, ex);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

    }

    private List<Object> collectDateList(List<Object> dataList, String rowName) {

        Map<String, Object> calm = new HashMap<>();
        List<String> userIdList = new ArrayList<>();
        List<Object> preList = new ArrayList<>();
        List<Object> histories = new ArrayList<Object>();
        int findCount = -1;

        for (int i = 0; i < dataList.size(); i++) {

            Map<String, Object> rs = (Map<String, Object>) dataList.get(i);

            // キーとしてユーザIDを取得する
            String userID = (String) rs.get("user_id");

            //以下の処理で配下にuserIDは不要のため削除する
            rs.remove("user_id");

            //userIDを保持
            findCount = userIdList.indexOf(userID);
            userIdList.add(userID);

            //初期化
            calm = new HashMap<>();
            preList = new ArrayList<>();

            //同じuserIDがないか
            if (findCount < 0) {
                //userIDと一致するデータはない
                preList.add(rs);
                calm.put("user_id", userID);
                calm.put(rowName, preList);
                histories.add(calm);
            } else {
                //userIDと一致するデータがほかにある
                //最後に追加する
                List<Object> sameDate = (List<Object>) ((Map<String, Object>) histories.get(histories.size() - 1)).get(rowName);
                sameDate.add(rs);
            }
        }
        return histories;
    }

    private List<Object> joinDateList(List<Object> joinDataList, List<Object> baseDataList,
            String joinRowName, String baseRowName) throws Exception {

        // ハッシュテーブル
        Map<Object, Map<String, Object>> hashTable = new HashMap<Object, Map<String, Object>>();
        Map<String, Object> joinMap;
        Map<String, Object> calm;
        List<Object> response = new ArrayList<>();
        List<Object> nullList = new ArrayList<>();

        for (int i = 0; i < joinDataList.size(); ++i) {
            joinMap = (Map<String, Object>) joinDataList.get(i);

            // userIDを取得する
            Object key = joinMap.get("user_id");

            // userIDをキーとして、結合するテーブルを登録する。
            hashTable.put(key, joinMap);
        }

        Map<String, Object> baseMap;
        for (int i = 0; i < baseDataList.size(); ++i) {

            calm = new HashMap<>();
            baseMap = (Map<String, Object>) baseDataList.get(i);

            String userID = (String) baseMap.get("user_id");

            // userIDをキーとして、ハッシュテーブルから取得する。
            joinMap = hashTable.get(userID);
            if (joinMap != null) {
                // ベースに追加したいテーブルを追加する
                calm.put(joinRowName, joinMap.get(joinRowName));

            } else {
                // ベースにからの配列を追加する
                calm.put(joinRowName, nullList);
            }
            calm.put("user_id", userID);
            if (baseMap.get(baseRowName) == null) {
                baseMap.put(baseRowName, calm.get(joinRowName));
                response.add(baseMap);
            } else {
                calm.put(baseRowName, baseMap.get(baseRowName));
                response.add(calm);
            }

        }

        return response;
    }

    private String createSQL(String joinSql, Object value) {
        String regex = "";
        String sql = "";
        Pattern p;
        Matcher m;

        regex = "\\)\\Z";
        p = Pattern.compile(regex);
        m = p.matcher(joinSql);
        sql = ", " + value + " " + "\\)";
        joinSql = m.replaceFirst(sql);
        return joinSql;
    }
}
