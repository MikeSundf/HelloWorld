package com.fujitsu.coe.tmh.web;

import com.fujitsu.coe.tmh.web.common.ErrorFactory;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author unicenfujitsu
 */
@Provider
public class AppExceptionHandler implements ExceptionMapper<AppException> {

    @Override
    public Response toResponse(AppException e) {
        return Response.status(Response.Status.OK)
                .entity(ErrorFactory.createError(e))
                .type(MediaType.APPLICATION_JSON).build();
    }

}
