 enable_flag = ? AND shop_id = ?
ORDER BY
  shop_id