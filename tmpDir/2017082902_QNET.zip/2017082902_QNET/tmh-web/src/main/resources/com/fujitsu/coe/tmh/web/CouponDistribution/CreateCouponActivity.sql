INSERT 
INTO user_coupon_activity(user_id, coupon_id, activity_type, "time") 
VALUES 
