package com.fujitsu.coe.tmh.web;

import com.fujitsu.coe.ss.fac.ForbiddenException;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * Allows services to throw Forbidden exceptions, which automatically generates
 * a Forbidden JSON response as per client/server interface.
 *
 * @author ky
 */
@Provider
public class ForbiddenExceptionHandler implements ExceptionMapper<ForbiddenException> {

    @Override
    public Response toResponse(ForbiddenException exception) {
        return Response.status(Status.FORBIDDEN)
                .entity(ErrorFactory.createError(403, "Forbidden"))
                .type(MediaType.APPLICATION_JSON).build();
    }

}
