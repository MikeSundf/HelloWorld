package com.fujitsu.coe.tmh.web.user;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;
import javax.servlet.http.HttpServletRequest;

/**
 * Implementation of the LogLocation annotation.
 * 
 * @author ky
 */
@Interceptor
@LogLocation
public class LogLocationInterceptor {

    private static final Logger LOGGER = Logger.getLogger(LogLocationInterceptor.class.getName());
    @Inject
    private HttpServletRequest request;
    @Inject
    private User user;
    @Inject
    private JdbcTemplate db;

    @AroundInvoke
    public Object logLocation(InvocationContext ctx) throws Exception {
        _logLocation(); // TODO: if user is performing a login, the session is not set yet. May have to trigger another log location just for after login.
        logBeacons();
        return ctx.proceed();
    }
    
    private void _logLocation() throws SQLException {
        if (user == null || !user.isLoggedIn()) {
            return;
        }
        String location = request.getHeader("X-Location");
        if (location == null) {
            return;
        }
        LOGGER.info(String.format("Logging location for user %d [%s]", user.getId(), location));
        String[] tokens = location.split(" ");
        double lat = Double.parseDouble(tokens[0]);
        double lon = Double.parseDouble(tokens[1]);
        double accuracy = (tokens.length > 2) ? Double.parseDouble(tokens[2]) : -1;
        db.update("INSERT INTO user_location(user_id, lat, lon, accuracy) VALUES(?, ?, ?, ?)", user.getId(), lat, lon, accuracy);
        request.setAttribute("locationId", db.queryForLong("SELECT LASTVAL()"));    // TODO: need transaction? or connection isolated guaranteed?
    }
    
    private void logBeacons() throws SQLException {
        if (user == null || !user.isLoggedIn()) {
            return;
        }
        String location = request.getHeader("X-Beacon");
        if (location == null) {
            return;
        }
        
        db.update("INSERT INTO user_location(user_id, accuracy, location) VALUES(?, ?, ?)", user.getId(), 2, location);
        // TODO no association to beacons from user action log...
    }
}
