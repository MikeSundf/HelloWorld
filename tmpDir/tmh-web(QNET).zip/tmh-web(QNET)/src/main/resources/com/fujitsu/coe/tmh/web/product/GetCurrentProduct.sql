SELECT selected_product FROM assortment 
WHERE user_id=? 
AND venue_id=? 
AND selected_product IS NOT NULL 
AND selected_time >= current_date
ORDER BY selected_time DESC 
LIMIT 1
