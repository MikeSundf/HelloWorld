INSERT INTO user_location(user_id, time, lat, lon, accuracy) VALUES(?,?,?,?,?)
