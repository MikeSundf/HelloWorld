package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.tmh.web.util.Location;

/**
 *
 * @author kychua
 */
public class ICMRequest {
    private String from;
    private Location fromLocation;
    private String to;
    private Location toLocation;
    private int hurry;
    private int hungry;
    private int seats;

    public String getFrom() {
        return from;
    }

    public Location getFromLocation() {
        return fromLocation;
    }

    public String getTo() {
        return to;
    }

    public Location getToLocation() {
        return toLocation;
    }

    public int getHurry() {
        return hurry;
    }

    public int getHungry() {
        return hungry;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setFromLocation(Location fromLocation) {
        this.fromLocation = fromLocation;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public void setToLocation(Location toLocation) {
        this.toLocation = toLocation;
    }

    public void setHurry(int hurry) {
        this.hurry = hurry;
    }

    public void setHungry(int hungry) {
        this.hungry = hungry;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }
    
}
