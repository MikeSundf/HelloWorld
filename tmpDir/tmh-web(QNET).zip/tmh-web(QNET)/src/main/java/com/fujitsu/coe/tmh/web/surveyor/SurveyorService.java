package com.fujitsu.coe.tmh.web.surveyor;

import com.fujitsu.coe.ss.fac.CheckRole;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.tmh.web.product.icm.po.CouponValuator;
import com.fujitsu.coe.tmh.web.user.LogLocation;
import com.fujitsu.coe.tmh.web.user.User;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import java.sql.SQLException;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author chuakayick
 */
@Path("/surveyor")
@ApplicationScoped
@CheckRole("user")
public class SurveyorService {
    
    private static final String FT_KEY = "field-test-redemption";
    @Inject
    private User user;
    @Inject
    private SystemSettings settings;
    @Inject
    private JdbcTemplate db;
    
    @POST
    @Path("/redeem")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @Transactional
    public Map<String, Object> redeem(@FormParam("code") String code, @FormParam("elapsed") long elapsed) throws SQLException {
        // check passcode
        String[] passcodes = settings.get("surveyor.passcode").split(" ");
        for (String passcode: passcodes) {
            if (passcode.equals(code)) {
                passcodes = null;   // double use as flag for correct passcode
                break;
            }
        }
        if (passcodes != null) {
            return MapBuilder.build("ok", false);
        }
        
        // check previous redemption
        String redeemed = db.queryForString("SELECT pref_value FROM user_preference WHERE pref_key=? AND user_id=?", FT_KEY, user.getId());
        if (redeemed != null) {
            String[] details = redeemed.split(",");
            return MapBuilder.create("ok", true)
                    .put("redeemed", Long.parseLong(details[0]))
                    .put("elapsed", Long.parseLong(details[1]))
                    .put("cash", Double.parseDouble(details[2]))
                    .put("userId", user.getId())
                    .build();
        }
        
        // to save user: elapsed, current time, calculated cash, passcode used
        long currentTime = System.currentTimeMillis();
        double cash = 2;
        
        db.update("INSERT INTO user_preference(user_id, pref_key, pref_value) VALUES(?, ?, ?)", 
                user.getId(), FT_KEY, String.format("%d,%d,%s,%s", currentTime, elapsed, cash, code));
        
        return MapBuilder.create("ok", true)
                .put("cash", cash)
                .put("userId", user.getId())
                .build();
    }

    /*
    // The below was redemption for SCC-FT1. KWM-FT1 has additional last-minute requirement to differentiate participants by referral (surveyor/leaflet ad/banner)
    @POST
    @Path("/redeem")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @Transactional
    public Map<String, Object> redeem(@FormParam("code") int code, @FormParam("elapsed") long elapsed) throws SQLException {
        // check passcode
        int passcode = Integer.parseInt(settings.get("surveyor.passcode"));
        if (passcode != code) {
            return MapBuilder.build("ok", false);
        }
        
        // check previous redemption
        String redeemed = db.queryForString("SELECT pref_value FROM user_preference WHERE pref_key=? AND user_id=?", FT_KEY, user.getId());
        if (redeemed != null) {
            String[] details = redeemed.split(",");
            return MapBuilder.create("ok", true)
                    .put("redeemed", Long.parseLong(details[0]))
                    .put("elapsed", Long.parseLong(details[1]))
                    .put("cash", Double.parseDouble(details[2]))
                    .put("userId", user.getId())
                    .build();
        }
        
        // to save user: elapsed, current time, calculated cash
        long currentTime = System.currentTimeMillis();
        long dwellTime = TimeUnit.MILLISECONDS.toMinutes(elapsed);
        double cash = CouponValuator.getValue((int)dwellTime);
        
        db.update("INSERT INTO user_preference(user_id, pref_key, pref_value) VALUES(?, ?, ?)", 
                user.getId(), FT_KEY, String.format("%d,%d,%s", currentTime, elapsed, cash));
        
        return MapBuilder.create("ok", true)
                .put("cash", cash)
                .put("userId", user.getId())
                .build();
    }
    */
}
