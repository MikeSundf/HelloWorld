SELECT c.shop_id, c.coupon_id, s.name, c.title, c.description, c.terms, c.max_available, c.expiry_duration, c.expiry_date, c.money_level, c.coupon_value, c.category, c.price_category, c.discount_category
FROM coupon c
INNER JOIN shop s ON c.shop_id=s.shop_id
WHERE c.shop_id=? AND c.enable_flag=?