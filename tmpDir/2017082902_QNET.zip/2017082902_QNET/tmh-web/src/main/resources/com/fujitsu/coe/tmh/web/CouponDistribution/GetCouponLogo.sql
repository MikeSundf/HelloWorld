SELECT sl.logo FROM shop_logo sl
INNER JOIN coupon c ON sl.id=c.id AND sl.type='COUPON'
INNER JOIN product_coupon pc ON pc.coupon_id=c.id
INNER JOIN product p ON pc.product_id=p.id 
INNER JOIN assortment a ON a.id=p.assortment_id 
WHERE pc.id=? AND a.user_id=?