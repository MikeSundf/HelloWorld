--*DataTitle coupon
--*Captions 店舗ID,タイトル,カテゴリ,説明,用例,備考,残枚数,発行上限数,有効分,利用想定時間,有効期限,クーポン対象商品額,クーポン割引金額,価格カテゴリ,割引カテゴリ,有効フラグ
SELECT
  shop_id
  , title
  , category
  , description
  , terms
  , remarks
  , available
  , max_available
  , expiry_duration
  , expected_dwell_time
  , expiry_date
  , money_level
  , coupon_value
  , price_category
  , discount_category
  , enable_flag 
FROM
  coupon 
WHERE
  coupon_id = ? 
ORDER BY
  coupon_id
