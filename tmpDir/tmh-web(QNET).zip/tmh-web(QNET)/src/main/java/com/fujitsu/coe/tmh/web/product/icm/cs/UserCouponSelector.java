package com.fujitsu.coe.tmh.web.product.icm.cs;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Coupon;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.*;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.TimeUnit;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.*;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author chuakayick
 */
public class UserCouponSelector {

    private static final String[] INTERESTS = {"beauty", "dining", "electronics", "fashion", "grocery", "lifestyle", "maternity", "sport", "sportswear", "travel"};
    private static final String ICM_REWARD_CATEGORY = "icm";
    private enum SelectStatus { SELECTED, REJECTED, CAT_USED, COUPON_USED }
    private ICMContext ctx;

    public UserCouponSelector(ICMContext ctx) {
        this.ctx = ctx;
    }

    public List<Coupon> select(int hurry, int hungry) throws SQLException {
        // get user preference
        ctx.timer.start("cs.pref");
        // TODO: workaround to fix key mismatch between ProfileService and CS.
        List<String> likes = ctx.db.query("SELECT pref_key FROM user_preference WHERE user_id=? AND pref_value='true'", (rs) -> {
            return rs.getString("pref_key");
        }, ctx.user.getId());

        int[] profile = new int[3];
        ctx.db.query("SELECT gender, age_group, income_group FROM user_profile WHERE user_id=?", (rs) -> {
            profile[0] = (rs.getString("gender") == null) ? 'M' : rs.getString("gender").charAt(0);
            profile[1] = rs.getInt("age_group");
            profile[2] = rs.getInt("income_group");
        }, ctx.user.getId());
        AlgoUser algoUser = new AlgoUser(hurry, hungry, (char) profile[0], profile[1], profile[2], new HashSet<>(likes));
        ctx.timer.stop();
        ctx.log(CS_PROFILE, String.join(", ", likes), (char) profile[0], profile[1], profile[2]);

        // initialize user rating for each shop, ranked
        ctx.timer.start("cs.rank");
        List<AlgoCoupon> rankedCoupons = getRankedCoupons(algoUser);
        ctx.timer.stop();
        ctx.log(CS_RANK1);
        for (AlgoCoupon coupon: rankedCoupons) {
            ctx.log(CS_RANK2, coupon.couponId, coupon.shopId, coupon.category, coupon.rating);
        }

        // TODO non-deterministic loop = BAD
        // while coupons < desired, use random factor against rating to decide coupon
        // prefer different categories & shops
        ctx.timer.start("cs.select");
        // XXX for KWM-FT2 also, all coupons should be selected
        int neededCount = rankedCoupons.size();
        /*
        int neededCount = 10;
        // sanity check, in case there are less coupons than needed
        neededCount = Math.min(neededCount, rankedCoupons.size());
        */
        
        Random rng = new Random();
        List<Long> seq = new ArrayList<>();
        StringJoiner recommended = new StringJoiner(",", "(", ")");
        recommended.add("0");   // TODO: HACK: 0 added to avoid exception when set is empty
        int wCount = 0, fCount = 0;
        Set<Long> usedCoupons = new HashSet<>();
        ctx.log(CS_SELECT1);
        while (seq.size() < neededCount) {
            wCount++;
            Set<String> usedCategories = new HashSet<>();
            for (AlgoCoupon coupon : rankedCoupons) {
                fCount++;
                SelectStatus sStatus = null;
                double rnd = 0;
                try {
                    if (usedCategories.contains(coupon.category)) {
                        sStatus = SelectStatus.CAT_USED;
                        continue;
                    }
                    if (usedCoupons.contains(coupon.couponId)) {
                        sStatus = SelectStatus.COUPON_USED;
                        continue;
                    }
                    rnd = rng.nextDouble();
                    if (rnd < coupon.rating) {
                        sStatus = SelectStatus.SELECTED;
                        seq.add(coupon.couponId);
                        recommended.add(String.valueOf(coupon.couponId));
                        usedCategories.add(coupon.category);
                        usedCoupons.add(coupon.couponId);
                        if (seq.size() >= neededCount) {
                            break; // break for, while loop will also terminate
                        }
                    } else {
                        sStatus = SelectStatus.REJECTED;
                    }
                } finally {
                    ctx.log(CS_SELECT2, wCount, fCount, coupon.couponId, sStatus, coupon.rating, rnd);
                }
            }
        }
        ctx.timer.stop();

        ctx.timer.start("cs.convert");
        Map<Long, Coupon> couponMap = new HashMap<>();
        ctx.db.query(String.format(ctx.getResource(this, "GetSelectedCoupons.sql"), recommended), (rs) -> {
            long id = rs.getLong("id");
            couponMap.put(id, new Coupon(id, rs.getString("name"), rs.getString("title"),
                    rs.getString("description"), rs.getString("address"), rs.getString("location"),
                    rs.getString("map_hint"), rs.getString("tel"), rs.getString("terms"),
                    new Date(ctx.clock.now().getTime() + TimeUnit.MINUTES.toMillis(rs.getInt("expiry_duration"))), false, rs.getBoolean("has_banner"),
                    rs.getInt("expected_dwell_time"), rs.getString("category")));
        });
        List<Coupon> coupons = new ArrayList<>();
        for (long id : seq) {
            coupons.add(couponMap.get(id));
        }
        ctx.timer.stop();
/*
        // This step is moved to Coupon Assignment
        ctx.timer.start("cs.reduce");
        ctx.db.update(String.format("UPDATE coupon SET available = available - 1 WHERE id IN %s", recommended));
        ctx.timer.stop();
*/
        return coupons;
    }

    // shopId -> rating
    private List<AlgoCoupon> getRankedCoupons(AlgoUser user) throws SQLException {
        final Map<String, Double> catRatings = getCategoryRatings(user);
        
        List<AlgoCoupon> coupons = ctx.db.query(ctx.getResource(this, "GetAvailableCoupons.sql"), (rs) -> {
            String category = rs.getString("category");
            if (ICM_REWARD_CATEGORY.equals(category)) {
                return new AlgoCoupon(rs.getInt("coupon_id"), category, rs.getInt("shop_id"), 1.0);
            }
            
            Double catRating = catRatings.get(category);
            if (catRating == null) {
                catRating = 0.5;   // default rating
            }
            int moneyLevel = rs.getInt("money_level");
            // [py] income_shop_match_factor = (6 - (abs(int(money_level_shop)-int(income_range_user))))/float(6)
            // [py] rating = rating_category*((int(shop_row["AVAILABLE NUMBER"]))/(int(shop_row["MAX AVAILABLE NUMBER"])))*(income_shop_match_factor)
            double incomeShopMatchFactor = (6 - Math.abs(moneyLevel - user.incomeRange)) / 6.0;
            double availabilityFactor = rs.getDouble("available") / rs.getDouble("max_available");
            double rating = catRating * incomeShopMatchFactor * availabilityFactor;
            return new AlgoCoupon(rs.getInt("coupon_id"), category, rs.getInt("shop_id"), rating);
        }, ctx.user.getVenue(), toTS(ctx.clock.now()), ctx.user.getId());
        Collections.sort(coupons, (c1, c2) -> {
            return Double.compare(c2.rating, c1.rating);   // descending
        });
        return coupons;
    }

    private Map<String, Double> getCategoryRatings(AlgoUser user) throws SQLException {
        Map<String, Double> catRatings = new HashMap<>();

        double mismatch = Double.parseDouble(ctx.settings.get("algo.mismatch.prob", "0.1"));
        for (String interest : INTERESTS) {
            if (user.likes.contains(interest)) {
                catRatings.put(interest, 0.75);
            } else {
                catRatings.put(interest, mismatch);
            }
        }

        // SPECIAL RULES
        // TODO handle Drink only
        if (user.hungry > 0) {
            catRatings.put("dining", 1.0);
        }
        if (user.likes.contains("beauty") && user.gender == 'F') {
            catRatings.put("beauty", 0.9);
        }
        if (user.likes.contains("electronics") && user.gender == 'M') {
            catRatings.put("electronics", 0.9);
        }
        if (user.likes.contains("maternity") && user.ageGroup >= 3) {   // 30 and above
            catRatings.put("maternity", 0.9);
        }

        for (String cat: catRatings.keySet()) {
            ctx.log(CS_RATING, cat, catRatings.get(cat));
        }
        return catRatings;
    }

}
