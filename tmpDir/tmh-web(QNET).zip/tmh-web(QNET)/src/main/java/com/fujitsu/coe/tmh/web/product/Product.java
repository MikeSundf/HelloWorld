package com.fujitsu.coe.tmh.web.product;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fujitsu.coe.ss.util.Date;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.*;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * A product model, contains an egress mode and a list of coupons.
 * 
 * @author ky
 */
@XmlRootElement
public class Product {

    private long id;
    private Egress egress;
    private List<Coupon> coupons;
    
    private Date st;     // startTime
    private transient int dt;   // dwellTime
    private transient int at;   // accessTime
    private transient int wt;   // waitingTime
    private transient int tt;   // travelTime
    
    private transient Object source;

    public Product(long id, Egress egress, Date st) {
        this.id = id;
        this.egress = egress;
        this.st = st;
    }
    
    // clone product into another transport mode
    public Product(Product other, Egress.Mode mode, int congestion) {
        this(0, new Egress(mode, congestion, other.getEgress().getFare(), other.st), other.st);
        for (EgressStep oStep: other.getEgress().getSteps()) {
            getEgress().addStep(oStep.getSeq(), oStep.getMode(), oStep.getService(), oStep.getLocation(), 
                    oStep.getDetails(), oStep.getTime(), oStep.getWaitTime(), oStep.getLat(), oStep.getLon());
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Egress getEgress() {
        return egress;
    }

    public List<Coupon> getCoupons() {
        return coupons;
    }

    public void setCoupons(List<Coupon> coupons) {
        this.coupons = coupons;
    }

    public int getDt() {
        return dt;
    }

    public void setDt(int dt) {
        this.dt = dt;
    }

    public int getAt() {
        return at;
    }

    public void setAt(int at) {
        this.at = at;
    }

    public int getWt() {
        return wt;
    }

    public void setWt(int wt) {
        this.wt = wt;
    }

    public int getTt() {
        return tt;
    }

    public void setTt(int tt) {
        this.tt = tt;
    }

    public Date getStartTime() {
        return st;
    }
    
    public void reschedule() {
        // assumptions assumptions assumptions - first step is walk, 2nd step is egress travel mode
        long fmat = egress.getSteps().get(0).getTime(); // first mile access time (in ms)
        long fmwt = egress.getSteps().get(1).getWaitTime(); // first mile waiting time (in ms)
        long startTime = getStartTime().getTime();
        if (egress.getMode() == Egress.Mode.TAXI) {
            // Based on Group Meeting 2015-12-23, taxi departure should be shown as before AT & WT
            egress.setDep(new Date(startTime + toMS(dt)));
        } else {
            // while Bus/Train should be after AT & WT
            egress.setDep(new Date(startTime + toMS(dt) + fmat + fmwt));
        }
        egress.setArr(new Date(startTime + toMS(dt + at + wt + tt)));
        egress.setStartTime(new Date(startTime + toMS(dt)));
    }

    public void addDwellTime(int dt) {
        setDt(getDt() + dt);
    }

    @JsonIgnore
    public Object getSource() {
        return source;
    }

    public void setSource(Object source) {
        this.source = source;
    }
}
