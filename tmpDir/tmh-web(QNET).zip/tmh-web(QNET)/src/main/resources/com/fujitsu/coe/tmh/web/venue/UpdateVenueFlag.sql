UPDATE venue 
SET
  enable_flag = ?
WHERE
  venue_id = ?
