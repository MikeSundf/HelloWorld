package com.fujitsu.coe.tmh.web.product.icm.po;

import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.util.Map;

/**
 *
 * @author unicenfujitsu
 */
class AlgoUser {
    private double[] vot;
    private double voc;
    private double voi;
    private Map<String, Double> asc;

    public AlgoUser(double[] vot) {
        this.vot = new double[4];
        System.arraycopy(vot, 0, this.vot, 0, this.vot.length);
        this.voc = vot[4];
        this.voi = vot[5];
        asc = MapBuilder.create("bus", vot[6])
                .put("mrt", vot[7])
                .put("staxi", vot[8])
                .build();
    }

    public double[] getVot() {
        return vot;
    }

    public double getVoc() {
        return voc;
    }

    public double getVoi() {
        return voi;
    }

    public Map<String, Double> getAsc() {
        return asc;
    }
}
