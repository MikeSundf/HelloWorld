package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * JSON model for root.taxi.is.tf;
 * 
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDTaxiFare {
    private String type; // ll
    private double value; // v
    private String unit; // u

    public void setLl(String type) {
        this.type = type;
    }

    public void setV(double value) {
        this.value = value;
    }

    public void setU(String unit) {
        this.unit = unit;
    }

    public double getValue() {
        return value;
    }
}
