CREATE TABLE request
(
  id character varying(86) NOT NULL,
  user_id character varying(45) NOT NULL,
  venue_id integer NOT NULL,
  from_location character varying(100),
  to_location character varying(100),
  from_lat numeric(10,5),
  from_lon numeric(10,5),
  to_lat numeric(10,5),
  to_lon numeric(10,5),
  hurry smallint,
  hungry smallint,
  seats smallint,
  created_time timestamp without time zone NOT NULL DEFAULT now(),
  CONSTRAINT request_pkey PRIMARY KEY (id),
  CONSTRAINT "userInfoFK" FOREIGN KEY (user_id)
      REFERENCES user_info (user_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "venueFK" FOREIGN KEY (venue_id)
      REFERENCES venue (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
