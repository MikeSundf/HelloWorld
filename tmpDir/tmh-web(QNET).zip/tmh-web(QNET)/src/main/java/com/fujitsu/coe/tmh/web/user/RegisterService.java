package com.fujitsu.coe.tmh.web.user;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.sim.SysClock;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.LogManage;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.AdminType;
import com.fujitsu.coe.tmh.web.util.IdExistCheck;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import com.fujitsu.coe.tmh.web.util.ValidationCheck;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toTS;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;
import java.util.Random;
import java.util.Arrays;
import java.util.logging.Level;
import javax.annotation.Resource;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.jasypt.util.password.StrongPasswordEncryptor;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.DefaultValue;

/**
 * Service related to User Info
 *
 * @author agustiars
 */
@Path("/")
@ApplicationScoped
public class RegisterService {

    private static final String PASSWORD_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int PASSWORD_LEN = 8;

    String classname = RegisterService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    @ClasspathResource("CheckEmail.sql")
    private String sqlCheckEmail;
    @Inject
    @ClasspathResource("CheckUserId.sql")
    private String sqlCheckUserId;
    @Inject
    @ClasspathResource("CreateUser.sql")
    private String sqlCreateUser;
    @Inject
    @ClasspathResource("DeleteUser.sql")
    private String sqlDeleteUser;
    @Inject
    @ClasspathResource("CreateUserProfile.sql")
    private String sqlCreateUserProfile;
    @Inject
    @ClasspathResource("DeleteUserProfile.sql")
    private String sqlDeleteUserProfile;
    @Inject
    private SystemSettings settings;
    @Inject
    private ActionLogger aLogger;
    @Resource(lookup = "mail/tmh")
    private Session mailSession;
    @Inject
    @ClasspathResource("CreateAdmin.sql")
    private String sqlCreateAdmin;
    @Inject
    private SysClock clock;
    @Inject
    private LogManage logger;
    @Inject
    private AdminType adminUtil;
    @Inject
    private IdExistCheck idExist;

    private final StrongPasswordEncryptor encryptor;
    
    public RegisterService() {
        encryptor = new StrongPasswordEncryptor();
    }

    /**
     * ユーザ登録
     * @param email
     * @param name
     * @param user_id
     * @return
     * @throws SQLException
     * @throws MessagingException 
     * @author Qnet)gotoh
     */
    @POST
    @Path("/user_info")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map register(@FormParam("email") String email,
                         final @FormParam("name") @DefaultValue("") String name,
                         @FormParam("user_id") String user_id) throws SQLException, MessagingException {
        aLogger.log(user_id, "REGISTER", user_id, String.format("[email=%s] [name=%s] [user_id=%s]", email, name, user_id));
        
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[email=" + email + ", name=" + name + ", user_id=" + user_id + "]");

        // 必須パラメータチェック
        if (email == null || email.equals("") || user_id == null || user_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // バリデーションチェック
        if(!(ValidationCheck.checkEmail(email)) ||
           !(ValidationCheck.checkStr45(name)) ||
           !(ValidationCheck.checkUserId(user_id))
          ){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // 登録数上限チェック
        long recoredCount= db.queryForLong("SELECT COUNT(*) FROM user_info");
        if(recoredCount >= Integer.parseInt(settings.get("maxnum.setuserlist", DB_DEFAULT_MAX_NUM))){
            logger.log(Level.WARNING, classname, methodName, LIMIT_SHOP_REGISTER_MSG);
            return ErrorFactory.createError(LIMIT_SHOP_REGISTER_CODE, LIMIT_SHOP_REGISTER_MSG);
        }

        // システムセッティングの"register.disabled"がtrueか
        if (Boolean.valueOf(settings.get("register.disabled", "false"))) {
            logger.log(Level.WARNING, classname, methodName, DISABLED_REGISTRATION_MSG);
            return ErrorFactory.createError(DISABLED_REGISTRATION_CODE, DISABLED_REGISTRATION_MSG);
        }

        // メールアドレス二重登録チェック
        if (db.queryForString(sqlCheckEmail, email) != null) {
            logger.log(Level.WARNING, classname, methodName, TAKEN_EMAIL_ALREADY_MSG);
            return ErrorFactory.createError(TAKEN_EMAIL_ALREADY_CODE, TAKEN_EMAIL_ALREADY_MSG);
        }
        
        // ユーザID二重登録チェック
        if (db.queryForString(sqlCheckUserId, user_id) != null) {
            logger.log(Level.WARNING, classname, methodName, TAKEN_ID_ALREADY_MSG);
            return ErrorFactory.createError(TAKEN_ID_ALREADY_CODE, TAKEN_ID_ALREADY_MSG);
        }

        // 初期パスワード生成
        String password = genPassword();
        if(password == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        
        // データベース登録
        try{
            db.update(sqlCreateUser, user_id, email, name, password, null, null, "", null, null, 0, toTS(clock.now()));
            logger.log(Level.FINE, classname, methodName, "INSERT user_info:[user_id=" + user_id + ", email=" + email + ", name=" + name + ", password=" + password + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }

        try{
            db.update(sqlCreateUserProfile, user_id);
            logger.log(Level.FINE, classname, methodName, "INSERT user_profile:[user_id=" + user_id + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            // DB削除
            try{
                db.update(sqlDeleteUser, user_id);
                logger.log(Level.FINE, classname, methodName, "DELETE user_info:[user_id=" + user_id + "]");
            } catch (SQLException sqle2) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB DELETE error.", sqle2);
            }
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 初期パスワードをメール送信しない場合
        if (settings.get("mail.enabled", "false").equalsIgnoreCase("false")) {
            logger.log(Level.INFO, classname, methodName,"Generated password for {0}: {1}");
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.create("ok", true)
                    .put("password", password)
                    .build();
        }

        // 初期パスワード送信
        int result = emailPassword(name, email, password);
        if(result == -1){
            // DB削除
            try{
                db.update(sqlDeleteUser, user_id);
                logger.log(Level.FINE, classname, methodName, "DELETE user_info:[user_id=" + user_id + "]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB DELETE error.", sqle);
                return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
            }
            try{
                db.update(sqlDeleteUserProfile, user_id);
                logger.log(Level.FINE, classname, methodName, "DELETE user_profile:[user_id=" + user_id + "]");
            } catch (SQLException sqle2) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB DELETE error.", sqle2);
            }
            return ErrorFactory.createError(FAILED_MAIL_CODE, FAILED_MAIL_MSG);
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     * パスワード生成
     * @return
     * @throws SQLException 
     */
    private String genPassword() throws SQLException {

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();

        // 固定パスワード設定
        String fixedPassword = settings.get("register.password");
        if (fixedPassword != null) {
            return fixedPassword;
        }

        // ランダムパスワード設定
        Random rng = (Random)null;
        rng = new Random();
        if(rng == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return null;
        }
        StringBuilder buf = (StringBuilder)null;
        buf = new StringBuilder();
         if(buf == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return null;
        }       
        for (int i = 0; i < PASSWORD_LEN; i++) {
            buf.append(PASSWORD_CHARS.charAt(rng.nextInt(PASSWORD_CHARS.length())));
        }
        return buf.toString();
    }

    // TODO (future) generic mail(email, subject, body) method when more email needs to be sent
    // TODO (future) support multi-language for subject & body
    private int emailPassword(String clientName, String clientEmail, String clientPassword) throws SQLException, MessagingException {

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();

        // メール作成
        MimeMessage message = new MimeMessage(mailSession);
        try {
            message.setFrom(new InternetAddress(settings.get("mail.from")));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(clientEmail));
            message.setSubject(settings.get("mail.subject"));
            message.setSentDate(new Date());
            message.setText(String.format(settings.get("mail.body"), clientName, clientPassword));
            Transport.send(message);
        } catch (MessagingException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "Mail send error.", ex);
            // 送信失敗した場合は30秒 wait
            try{
                Thread.sleep(30000);
            } catch (InterruptedException e){
                logger.thrownLog(Level.SEVERE, classname, methodName, "sleep error.", e);
            }
            // メール送信をリトライ
            try{
                Transport.send(message);
            } catch(MessagingException e){
                logger.thrownLog(Level.SEVERE, classname, methodName, "Mail send error.", e);
                return -1;
            }
        }
        return 0;
    }
    
    /**
     * 管理者ログイン
     * @param admin_id
     * @param name
     * @param email
     * @param reg_admin_id
     * @param venue_id_list
     * @param shop_id_list
     * @return
     * @throws SQLException
     * @throws MessagingException 
     */
    @POST
    @Path("/operator")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map registerOperator(
            @FormParam("admin_id") String admin_id,
            final @FormParam("name") @DefaultValue("") String name,
            @FormParam("email") String email,
            @FormParam("reg_admin_id") String reg_admin_id,
            @FormParam("venue_id_list") @DefaultValue("") String venue_id_list,
            @FormParam("shop_id_list") @DefaultValue("") String shop_id_list) throws SQLException, MessagingException {
        aLogger.log(admin_id, "OPERATOR", admin_id, String.format("[admin_id=%s] [name=%s] [email=%s] [reg_admin_id=%s] [venue_id_list=%s] [shop_id_list=%s]", admin_id, name, email, reg_admin_id, venue_id_list, shop_id_list));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + admin_id + ", name=" + name + ", email=" + email + ", reg_admin_id=" + reg_admin_id + ", venue_id_list=" + venue_id_list + ", shop_id_list=" + shop_id_list + "]");
        
        // 必須パラメータチェック
        if (email == null || email.equals("") || admin_id == null || admin_id.equals("") || reg_admin_id == null || reg_admin_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(admin_id)) ||
           !(ValidationCheck.checkStr45(name)) ||
           !(ValidationCheck.checkEmail(email)) ||
           !(ValidationCheck.checkUserId(reg_admin_id)) ||
           !(ValidationCheck.checkIdList(venue_id_list)) ||
           !(ValidationCheck.checkIdList(shop_id_list))
          ){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
 
        // 開催地取得
        boolean venue_flag = false;
        int venue_id_list_split_int[] = new int[200];
        Arrays.fill(venue_id_list_split_int, 0);
        if((venue_id_list != null) && (!venue_id_list.equals(""))){
            String[] venue_id_list_split_str = venue_id_list.split(",", 0);
            for(int i=0;i<venue_id_list_split_str.length;i++){
                venue_id_list_split_int[i] = Integer.parseInt(venue_id_list_split_str[i]);
                if (idExist.validateaVenueId(venue_id_list_split_int[i]) == false) {
                    logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                    return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
                }
                venue_flag = true;
            }
        }

        // 店舗取得
        boolean shop_flag = false;
        int shop_id_list_split_int[] = new int[200];
        Arrays.fill(shop_id_list_split_int, 0);
        if((shop_id_list != null) && (!shop_id_list.equals(""))){
            String[] shop_id_list_split_str = shop_id_list.split(",", 0);
            for(int i=0;i<shop_id_list_split_str.length;i++){
                shop_id_list_split_int[i] = Integer.parseInt(shop_id_list_split_str[i]);
                if (idExist.validateShopId(shop_id_list_split_int[i]) == false) {
                    logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                    return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
                }
                shop_flag = true;
            }
        }

        // 種別取得
        int admin_type = adminUtil.getUserType(admin_id);
        // 開催地管理者以上か？
        if (admin_type != USER_INFO_TYPE_SYSTEM && admin_type != USER_INFO_TYPE_VENUE){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        // 登録管理者種別が開催地管理者でかつ店舗ID指定なしか？
        if (admin_type == USER_INFO_TYPE_VENUE && shop_flag == false){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }

        // 登録管理者種別設定
        int type;
        if(venue_flag == false && shop_flag == false){
            type = USER_INFO_TYPE_SYSTEM;
        } else if(venue_flag == true && shop_flag == false){
            type = USER_INFO_TYPE_VENUE;
        } else if(venue_flag == false && shop_flag == true){
            type = USER_INFO_TYPE_SHOP;
        } else {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 登録数上限チェック
        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info");
        if(recoredCount >= Integer.parseInt(settings.get("maxnum.setuserlist", DB_DEFAULT_MAX_NUM))){
            logger.log(Level.WARNING, classname, methodName, LIMIT_SHOP_REGISTER_MSG);
            return ErrorFactory.createError(LIMIT_SHOP_REGISTER_CODE, LIMIT_SHOP_REGISTER_MSG);
        }

        // システムセッティングの"register.disabled"がtrueか
        if (Boolean.valueOf(settings.get("register.disabled", "false"))) {
            logger.log(Level.WARNING, classname, methodName, DISABLED_REGISTRATION_MSG);
            return ErrorFactory.createError(DISABLED_REGISTRATION_CODE, DISABLED_REGISTRATION_MSG);
        }

        // メールアドレス二重登録チェック
        if (db.queryForString(sqlCheckEmail, email) != null) {
            logger.log(Level.WARNING, classname, methodName, TAKEN_EMAIL_ALREADY_MSG);
            return ErrorFactory.createError(TAKEN_EMAIL_ALREADY_CODE, TAKEN_EMAIL_ALREADY_MSG);
        }
        
        // ユーザID二重登録チェック
        if (db.queryForString(sqlCheckUserId, reg_admin_id) != null) {
            logger.log(Level.WARNING, classname, methodName, TAKEN_ADMINID_ALREADY_MSG);
            return ErrorFactory.createError(TAKEN_ADMINID_ALREADY_CODE, TAKEN_ADMINID_ALREADY_MSG);
        }

        // 初期パスワード生成
        String password = genPassword();
        if(password == null){
            logger.log(Level.WARNING, classname, methodName, SYSTEM_ERROR_MSG);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        
        // ユーザ情報データベース登録
        try{
            db.update(sqlCreateUser, reg_admin_id, email, name, password, null, null, "", null, null, type, toTS(clock.now()));
            logger.log(Level.FINE, classname, methodName, "INSERT user_info:[user_id=" + reg_admin_id + ", email=" + email + ", name=" + name + ", password=" + password + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // 管理者情報データベース登録
        if(type == USER_INFO_TYPE_VENUE){
            for(int i=0; venue_id_list_split_int[i] != 0; i++){
                try{
                    db.update(sqlCreateAdmin, reg_admin_id, ADMIN_TYPE_VENUE, venue_id_list_split_int[i]);
                    logger.log(Level.FINE, classname, methodName, "INSERT admin_info:[user_id=" + reg_admin_id + ", type=" + ADMIN_TYPE_VENUE + ", manage_id=" + venue_id_list_split_int[i] + "]");
                } catch (SQLException sqle) {
                    logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
                    return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                }
            }
        } else if(type == USER_INFO_TYPE_SHOP){
            for(int i=0; shop_id_list_split_int[i] != 0; i++){
                try{
                    db.update(sqlCreateAdmin, reg_admin_id, ADMIN_TYPE_SHOP, shop_id_list_split_int[i]);
                    logger.log(Level.FINE, classname, methodName, "INSERT admin_info:[user_id=" + reg_admin_id + ", type=" + ADMIN_TYPE_SHOP + ", manage_id=" + shop_id_list_split_int[i] + "]");
                } catch (SQLException sqle) {
                    logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
                    return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                }
            }
        }

        // 初期パスワードをメール送信しない場合
        if (settings.get("mail.enabled", "false").equalsIgnoreCase("false")) {
            logger.log(Level.INFO, classname, methodName,"Generated password for {0}: {1}");
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.create("ok", true)
                    .put("password", password)
                    .build();
        }

        // 初期パスワード送信
        int result = emailPassword(name, email, password);
        if(result == -1){
            // DB削除
            try{
                db.update(sqlDeleteUser, reg_admin_id);
                logger.log(Level.FINE, classname, methodName, "DELETE user_info:[user_id=" + reg_admin_id + "]");
            } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB DELETE error.", sqle);
            }
            return ErrorFactory.createError(FAILED_MAIL_CODE, FAILED_MAIL_MSG);
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }
}
