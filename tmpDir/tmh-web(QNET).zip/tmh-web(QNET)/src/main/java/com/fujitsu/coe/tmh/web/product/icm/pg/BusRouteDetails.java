package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;
import com.fujitsu.coe.tmh.web.util.Location;
import java.sql.SQLException;

/**
 *
 * @author kychua
 */
public class BusRouteDetails extends BusTrainRouteDetails {

    public BusRouteDetails(ICMContext ctx, Route route, Egress.Mode mode, Location userLocation) throws SQLException {
        super(ctx, route, mode);
        
        Step firstWalk = route.getSteps().get(0);
        if (firstWalk.getVehicleType().equals("WALK")) {
            Step firstBus = route.getSteps().get(1);

            // rewrite first mile access
            final Location[] busStopLocation = new Location[1];
            ctx.db.query("SELECT stop_code, lat, lon FROM bus_stop WHERE stop_code=?", (rs) -> {
                busStopLocation[0] = new Location(rs.getDouble(2), rs.getDouble(3));
            }, Integer.parseInt(firstBus.getDetails()));    // bus stop code

            if (busStopLocation[0] == null) {
                throw new IllegalArgumentException(firstBus.getDetails());
            }

            firstWalk.setLocation(userLocation.getLat(), userLocation.getLon());
            firstWalk.setTime(PGUtil.getAccessTime(userLocation, busStopLocation[0]));
        }
        
        init();
    }
}
