package com.fujitsu.coe.tmh.web.product.icm.po;

import com.fujitsu.coe.tmh.web.product.Product;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author unicenfujitsu
 */
public class TaxiOnlyOptimizer {

    static void optimize(List<Product> products) {
        Collections.sort(products, (p1, p2) -> {
            return p2.getDt() - p1.getDt();   // highest to lowest dwell time
        });
    }

}
