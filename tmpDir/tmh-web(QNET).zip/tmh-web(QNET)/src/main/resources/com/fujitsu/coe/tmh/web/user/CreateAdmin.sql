INSERT INTO admin_info(
            user_id, type, manage_id)
    VALUES (?, ?, ?);
