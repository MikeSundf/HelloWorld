package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.icm.ICMRequest;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kychua
 */
public class ProductGenerator {

    private static final int MAX_TIME = 120;

    private ICMContext ctx;
    private ICMRequest request;
    
    public ProductGenerator(ICMContext ctx, ICMRequest request) {
        this.ctx = ctx;
        this.request = request;
    }

    public List<Product> generate() throws SQLException, IOException {
        List<Product> products = new ArrayList<>();
        ShuttleProductGenerator shPG = new ShuttleProductGenerator(ctx, request);
        products.addAll(shPG.generate()); // TODO thread out, join and append together
        FMODProductGenerator fmodPG = new FMODProductGenerator(ctx, request);
        products.addAll(fmodPG.generate(MAX_TIME)); // TODO thread out, join and append together
        SDProductGenerator sdPG = new SDProductGenerator(ctx, request);
        products.addAll(sdPG.generate(MAX_TIME));
        return products;
    }
}
