package com.fujitsu.coe.tmh.web.product;

import com.fujitsu.coe.ss.fac.CheckRole;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.tmh.web.AppException;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.user.LogLocation;
import com.fujitsu.coe.tmh.web.product.icm.ICMEngine;
import com.fujitsu.coe.tmh.web.product.icm.ICMRequest;
import com.fujitsu.coe.tmh.web.product.icm.pg.fmod.FMODGateway;
import com.fujitsu.coe.tmh.web.sim.SysClock;
import com.fujitsu.coe.tmh.web.user.ActionLogger;
import com.fujitsu.coe.tmh.web.user.User;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.Location;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * Services related to the product, e.g. list, select.
 *
 * @author ky
 */
@Path("/product")
@ApplicationScoped
@CheckRole("user")
public class ProductService {

    private static final Logger LOGGER = Logger.getLogger(ProductService.class.getName());
    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private ICMEngine engine;
    @Inject
    private SysClock clock;
    @Inject
    private ActionLogger aLogger;
    @Inject
    private SystemSettings settings;

    /**
     * Gets the assortment for the current user.
     *
     * @param hurry are you in a hurry?
     * @param hungry are you hungry?
     * @param destination destination request
     * @param lat required by FMOD
     * @param lon required by FMOD
     * @param seats required by FMOD
     * @return list of products (assortment)
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    @GET
    @Path("/list")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public List<Product> getAssortment(
            @QueryParam("hurry") @DefaultValue("0") int hurry, 
            @QueryParam("hungry") @DefaultValue("0") int hungry,
            @QueryParam("dest") String destination,
            @QueryParam("lat") float lat,
            @QueryParam("lon") float lon,
            @QueryParam("seats") @DefaultValue("1") int seats) throws SQLException, IOException {
        aLogger.log("OFFER", null, String.format("[hungry=%d] [hurry=%d] [dest=%s (%f, %f)] [seats=%d]", hungry, hurry, destination, lat, lon, seats));
        
        final ICMRequest request = new ICMRequest();
        request.setSeats(seats);
        
        db.query("SELECT name, lat, lon FROM venue WHERE id=?", (rs) -> {
                request.setFrom(rs.getString("name"));
                request.setFromLocation(new Location(rs.getDouble("lat"), rs.getDouble("lon")));
            }, user.getVenue());
        
        if (destination == null) {
            request.setTo(db.queryForString("SELECT postal_code FROM user_info WHERE id=?", user.getId()));
            request.setToLocation(getUserLocation()); // TODO: bug - remove this if, always let user send destination
        } else {
            request.setTo(destination);
            request.setToLocation(new Location(lat, lon));
        }
        
        LOGGER.log(Level.INFO, "Invoking engine for [user={0}, source={1} dest={2}]", new Object[] { user.getId(), request.getFrom(), request.getTo() });
        return engine.run(request);
    }
    
    private Location getUserLocation() throws SQLException {
        // try to see if we have the user's location in the last 5 mins
        List<Location> lastKnown = db.query("SELECT lat, lon FROM user_location WHERE user_id=? AND ((time, time - INTERVAL '5 minutes') OVERLAPS (NOW(), NOW())) ORDER BY time DESC LIMIT 1", (rs) -> {
            return new Location(rs.getDouble("lat"), rs.getDouble("lon"));
        }, user.getId());
        if (!lastKnown.isEmpty()) {
            return lastKnown.get(0);
        }

        // if not we will use the default location for the user's venue
        return db.query("SELECT lat, lon FROM venue WHERE id=?", (rs) -> {
            return new Location(rs.getDouble("lat"), rs.getDouble("lon"));
        }, user.getVenue()).get(0);
    }

    /**
     * Selects a specific product from the assortment.
     *
     * @param id product id
     * @return OK if successful
     * @throws SQLException
     * @throws IOException
     */
    @POST
    @Path("/select")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @Transactional
    public Map<String, Object> select(@FormParam("id") long id) throws SQLException, IOException {
        aLogger.log("OFFER_SELECT", String.valueOf(id), null);
        
        long assortmentId = db.queryForLong("SELECT id FROM assortment WHERE user_id=? ORDER BY created_time DESC LIMIT 1", user.getId());
        // #1 check product belongs to assortment
        if (db.query("SELECT id FROM product WHERE assortment_id=? AND id=?", (rs) -> 1, assortmentId, id).isEmpty()) {
            return ErrorFactory.createError(6001, "Invalid selection.", MapBuilder.build("tag", 1));
        }
        // #2 check no product has already been selected in the assortment
        if (db.query("SELECT id FROM assortment WHERE id=? AND selected_product IS NULL", (rs) -> 1, assortmentId).isEmpty()) {
            return ErrorFactory.createError(6001, "Invalid selection.", MapBuilder.build("tag", 2));
        }
        // #3 check that product selection is allowed at this timing
        if (!Boolean.valueOf(settings.get("icm.enabled", "true"))) {
            return ErrorFactory.createError(6003, "ICM disabled.");
        }
        
        int rows = db.update("UPDATE assortment SET selected_product=?, selected_time=? WHERE id=?", id, new Timestamp(clock.now().getTime()), assortmentId);
        if (rows != 1) {
            return ErrorFactory.createError(500, "Update failed.", MapBuilder.build("tag", rows));
        }
        
        // update fmod
        String mode = db.queryForString("SELECT egress_mode FROM product WHERE id=?", id);
        if ("STAXI".equals(mode)) {
            // TODO: FMODGateway should not always run within ICMContext - but due to time constraint we will inject one
            FMODGateway fmod = new FMODGateway(new ICMContext(db, user, settings, clock, null));
            if (!fmod.confirm(id)) {
                throw new AppException(9999, "Product selection failed.");  // ensure rollback
            }
        }
        
        return MapBuilder.create("ok", true).build();
    }

}
