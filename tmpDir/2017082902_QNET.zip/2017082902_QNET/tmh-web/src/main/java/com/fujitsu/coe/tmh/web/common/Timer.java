package com.fujitsu.coe.tmh.web.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author unicenfujitsu
 */
public class Timer {

    private TimeRecord root;
    private TimeRecord current;

    public Timer() {}

    public synchronized void start(String name) {
        if (current == null) {
            current = new TimeRecord(name);
            root = current;
        } else {
            current = current.add(name);
        }
    }

    public synchronized void stop() {
        current = current.stop();
    }

    public synchronized void end() {
        while (current != root) {
            current = current.stop();
        }
        current.stop();
    }

    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        print(buf, 0, root);
        return buf.append('\n').toString();
    }

    private void print(StringBuilder buf, int indent, TimeRecord record) {
        buf.append('\n');
        for (int i = 0; i < indent; i++) {
            buf.append("  ");
        }
        buf.append(record.name).append(": ").append(record.stop - record.start);
        for (TimeRecord child : record.children) {
            print(buf, indent + 1, child);
        }
    }

    private class TimeRecord {

        private TimeRecord parent;
        private List<TimeRecord> children;
        private String name;
        private long start;
        private long stop;

        TimeRecord(String name) {
            children = Collections.synchronizedList(new ArrayList<>());
            this.name = name;
            this.start = System.currentTimeMillis();
        }

        public TimeRecord add(String name) {
            TimeRecord record = new TimeRecord(name);
            record.parent = this;
            children.add(record);
            return record;
        }

        public TimeRecord stop() {
            this.stop = System.currentTimeMillis();
            return parent;
        }
    }
}
