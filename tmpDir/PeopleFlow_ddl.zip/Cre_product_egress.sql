CREATE TABLE product_egress
(
  product_id integer NOT NULL,
  step smallint NOT NULL,
  mode character varying(10) NOT NULL,
  duration integer,
  wait_duration integer,
  action character varying(100) DEFAULT NULL::character varying,
  service character varying(100) DEFAULT NULL::character varying,
  location character varying(100) DEFAULT NULL::character varying,
  details character varying(100) DEFAULT NULL::character varying,
  lat numeric(10,5) DEFAULT NULL::numeric,
  lon numeric(10,5) DEFAULT NULL::numeric,
  CONSTRAINT product_egress_pkey PRIMARY KEY (product_id, step),
  CONSTRAINT "productFK" FOREIGN KEY (product_id)
      REFERENCES product (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);
