SELECT
  user_id
  , shop_id
  , "time" 
FROM
  user_location 
WHERE
  shop_id = ? 
ORDER BY
  user_id