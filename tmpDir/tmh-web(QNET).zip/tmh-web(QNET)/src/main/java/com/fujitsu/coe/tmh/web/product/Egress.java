package com.fujitsu.coe.tmh.web.product;

import com.fujitsu.coe.ss.util.Date;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Egress model in offers screen.
 * 
 * @author ky
 */
@XmlRootElement
public class Egress {

    public enum Mode {
        BUS, TRAIN, TAXI, STAXI, SHUTTLE, WALK
    }
    
    private Mode mode;
    private int congestion;
    private double fare;
    private Date st;
    private Date dep;
    private Date arr;
    private List<EgressStep> steps;

    public Egress(Mode mode, int congestion, double fare, Date st) {
        this.mode = mode;
        this.congestion = congestion;
        this.fare = fare;
        this.st = st;
        steps = new ArrayList<>();
    }

    public Mode getMode() {
        return mode;
    }

    public int getCongestion() {
        return congestion;
    }

    public double getFare() {
        return fare;
    }

    public Date getDep() {
        return dep;
    }

    public Date getArr() {
        return arr;
    }

    public Date getStartTime() {
        return st;
    }

    public List<EgressStep> getSteps() {
        return steps;
    }
    
    public void addStep(int seq, String mode, String service, String location, String details, long time, long waitTime, double lat, double lon) {
        steps.add(new EgressStep(seq, mode, service, location, details, time, waitTime, lat, lon));
    }

    public void setDep(Date dep) {
        this.dep = dep;
    }

    public void setArr(Date arr) {
        this.arr = arr;
    }
    
    public void setTime(Date dep, Date arr) {
        setDep(dep);
        setArr(arr);
    }

    public void setStartTime(Date st) {
        this.st = st;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }
}
