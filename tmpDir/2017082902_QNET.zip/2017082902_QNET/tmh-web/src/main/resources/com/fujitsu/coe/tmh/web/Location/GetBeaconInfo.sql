SELECT beacon_id, lat, lon, ROUND(CAST((POWER(ABS(lat - ?), 2) + POWER(ABS(lon - ?), 2))AS numeric), 5)
AS distance
FROM beacon_info
WHERE venue_id=?
ORDER BY distance ASC