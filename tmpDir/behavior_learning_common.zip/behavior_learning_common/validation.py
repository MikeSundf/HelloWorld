# -*- coding: utf-8 -*-
"""
Created on Thu Mar 02 14:20:11 2017

@author: takuro

"""
import psycopg2
import psycopg2.extras
import sys
import numpy as np
import pandas as pd
import random
import math
import os.path
import copy
import csv

from config import Config
from configparser import ConfigParser
from user_agent import UserAgent
from user_agent import BehaviorModelParam
from user_agent import DummyUserManager
# from user_agent import RangeCount
from histogram import Histogram
from choice_history import ChoiceDistribution

from product import Assortment
from product import Product
from behavior_learning import create_random_assortment
from behavior_learning import create_assortment
from choice_history import kl_divergence
from choice_history import js_divergence

config = Config()


def output_stdout_file(f, log=""):
    """
    output to fine and stdout
    """
    sys.stdout.write(log + "\n")
    sys.stdout.flush()

    f.write(log + "\n")
    f.flush()


def validate(actual_user, n_epoch, rand_assort):
    """
    validation: compare choice probability distribution of actual parameters and estimated parameters
    actual_user: actual user
    n_epoch: epoch
    rand_assort: test with random assortment(true) or one assortment(false)
    """

    global config

    f_log = config.log_file

    for i in range(2):

        output_dir = config.output_dir + "/err1"
        if (i == 1):
            output_dir = config.output_dir + "/err_all_attr"

        filepath = output_dir + "/param_learnt.csv"

        df = pd.read_csv(filepath)
        user_num = len(df.index)
        l = (len(df) - 1)
        est_user = UserAgent("eu", df.ix[l, "beta_cg"], df.ix[l, "beta_fare"], df.ix[l, "beta_ic"],
                             df.ix[l, "beta_dt"], df.ix[l, "beta_ivtt"], df.ix[l, "beta_ovtt"], df.ix[l, "beta_wt"])

        est_user.output(None, True)

        df = pd.DataFrame(index=[], columns=['exact_match', 'exact_rate', 'segment_match', 'segment_rate'])

        if (rand_assort == False):
            assortment = create_assortment(0)

        exact_count = 0
        segment_count = 0
        for it in range(0, n_epoch):

            output_stdout_file(f_log,
                               "\n---------- [validation] actual user(%s), random_assort=%d, iteration %d / %d ----------\n" % (
                               actual_user.id, rand_assort, it, n_epoch))

            if (rand_assort == True):
                assortment = create_random_assortment(it)

            # simulate that an actual user selects product among an assortment
            selected_product_idx1, selected_product_prob1 = actual_user.selectProduct(assortment)
            product1 = assortment.get(selected_product_idx1)

            prob_array, V_array, max_prob_idx = actual_user.getChoiceProbability(assortment)
            actual_user.choice_history.addChoiceProb(assortment, prob_array)
            actual_user.choice_history.updateChoiceProbDistribution()

            # simulate that an estimated user selects product among an assortment
            selected_product_idx2, selected_product_prob2 = est_user.selectProduct(assortment)
            product2 = assortment.get(selected_product_idx2)

            prob_array, V_array, max_prob_idx = est_user.getChoiceProbability(assortment)
            est_user.choice_history.addChoiceProb(assortment, prob_array)
            est_user.choice_history.updateChoiceProbDistribution()

            exact_match = 0
            if (selected_product_idx1 == selected_product_idx2):
                exact_match = 1
                exact_count += 1
            exact_rate = exact_count / (it + 1)

            dt1, cg1, ic1 = ChoiceDistribution.getSegment(product1)
            dt2, cg2, ic2 = ChoiceDistribution.getSegment(product2)
            segment_match = 0
            if ((dt1 == dt2) and (cg1 == cg2) and (ic1 == ic2)):
                segment_match = 1
                segment_count += 1
            segment_rate = segment_count / (it + 1)

            series = pd.Series([exact_match, exact_rate, segment_match, segment_rate], index=df.columns)
            df = df.append(series, ignore_index=True)

        filepath = output_dir + "/valid_choice.csv"
        df.to_csv(filepath)

        filepath = output_dir + "/valid_product_dist.csv"

        file = open(filepath, 'w')
        csvWriter = csv.writer(file, lineterminator='\n')
        header = ['actual', 'estimated']
        csvWriter.writerow(header)

        filepath = output_dir + "/valid_jsd.csv"
        f_jsd = open(filepath, 'w')

        actual_arr = np.zeros(ChoiceDistribution.TIME_SLOT_NUM * ChoiceDistribution.CG_LEVEL_NUM * ChoiceDistribution.IC_RANGE_NUM)
        estimated_arr = np.zeros(ChoiceDistribution.TIME_SLOT_NUM * ChoiceDistribution.CG_LEVEL_NUM * ChoiceDistribution.IC_RANGE_NUM)

        count = 0
        for l in range(ChoiceDistribution.TIME_SLOT_NUM):
            for m in range(ChoiceDistribution.CG_LEVEL_NUM):
                for n in range(ChoiceDistribution.IC_RANGE_NUM):
                    row = [actual_user.choice_history.product_prob_arr[l][m][n], est_user.choice_history.product_prob_arr[l][m][n]]
                    csvWriter.writerow(row)
                    actual_arr[count] = actual_user.choice_history.product_prob_arr[l][m][n]
                    estimated_arr[count] = est_user.choice_history.product_prob_arr[l][m][n]
                    count += 1
        file.close()

        d = js_divergence(actual_arr, estimated_arr)
        s = "product dist jsd, %f\n" % d
        f_jsd.write(s)

        filepath = output_dir + "/valid_attr_dist.csv"
        file = open(filepath, 'w')
        csvWriter = csv.writer(file, lineterminator='\n')
        header = ['actual', 'estimated']
        csvWriter.writerow(header)

        count = 0
        for l in range(ChoiceDistribution.TIME_SLOT_NUM):
            row = [actual_user.choice_history.attr_prob_arr['DT'][l], est_user.choice_history.attr_prob_arr['DT'][l]]
            csvWriter.writerow(row)
            actual_arr[count] = actual_user.choice_history.attr_prob_arr['DT'][l]
            estimated_arr[count] = est_user.choice_history.attr_prob_arr['DT'][l]
            count += 1
        for l in range(ChoiceDistribution.CG_LEVEL_NUM):
            row = [actual_user.choice_history.attr_prob_arr['CG'][l], est_user.choice_history.attr_prob_arr['CG'][l]]
            csvWriter.writerow(row)
            actual_arr[n] = actual_user.choice_history.attr_prob_arr['CG'][l]
            estimated_arr[n] = est_user.choice_history.attr_prob_arr['CG'][l]
            count += 1
        for l in range(ChoiceDistribution.IC_RANGE_NUM):
            row = [actual_user.choice_history.attr_prob_arr['IC'][l], est_user.choice_history.attr_prob_arr['IC'][l]]
            csvWriter.writerow(row)
            actual_arr[count] = actual_user.choice_history.attr_prob_arr['IC'][l]
            estimated_arr[count] = est_user.choice_history.attr_prob_arr['IC'][l]
            count += 1
        file.close()

        d = js_divergence(actual_arr, estimated_arr)
        s = "attr dist jsd, %f\n" % d
        f_jsd.write(s)

        f_jsd.close()

def run(user_i, n_epoch):

    actual_user = config.au_list[user_i]

    actual_user.output(None, True)

    config.user_dir = config.algo_dir + "/user_%d" % (user_i)

    for i in range(2):
        if (i == 0):
            rand_assort = False
            continue  ################################# test
        else:
            rand_assort = True

        config.output_dir = config.user_dir
        if (rand_assort == True):
            config.output_dir += "/random"
        else:
            config.output_dir += "/fixed"

        if (os.path.exists(config.output_dir) == False):
            raise Excetion

        log_dir = config.output_dir + "/log"
        if (os.path.exists(log_dir) == False):
            os.mkdir(log_dir)

        file_name = log_dir + "/log_validation.txt"
        config.log_file = open(file_name, 'w')
        """
        file_name = config.output_dir + "/assortment.csv"
        config.assortment_file = open(file_name, 'w')
        csvWriter = csv.writer(config.assortment_file, lineterminator='\n')
        header = ['assortment', 'seq', 'product']
        for key in Product.attr_keys:
            header.append(key)
        csvWriter.writerow(header)
        """
        validate(actual_user, n_epoch, rand_assort)

        config.log_file.close()
#        config.assortment_file.close()


def main():
    global config

    config = Config()

    args = sys.argv
    algo_type = 4

    config.algo_dir = "./algo4"
    if (os.path.exists(config.algo_dir) == False):
        print('ERROR')
        return

    df = pd.read_csv('actual_users.csv', index_col='id')
    rand_user = False
    user_num = len(df.index)
    print("The number of users: %d" %user_num)
    for i in range(user_num):
        config.au_list.append(
            UserAgent(df.index[i], df.ix[i, "beta_cg"], df.ix[i, "beta_fare"], df.ix[i, "beta_ic"],
                      df.ix[i, "beta_dt"], df.ix[i, "beta_ivtt"], df.ix[i, "beta_ovtt"], df.ix[i, "beta_wt"]))

    # no of epoch in each test
    if len(args) < 2:
        print("[Usage] args[1] no_of_epoch")
        raise Exception

    n_epoch = int(args[1])
    if (n_epoch < 1):
        print("specify no of epoch")
        return
    print("no of epoch: %d" % n_epoch)

    for i in range(0, user_num):
        run(i, n_epoch)

    print ("finished!")


if __name__ == "__main__":
    main()

