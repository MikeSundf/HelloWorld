UPDATE shop 
SET
  enable_flag = ?
WHERE
  shop_id = ?
