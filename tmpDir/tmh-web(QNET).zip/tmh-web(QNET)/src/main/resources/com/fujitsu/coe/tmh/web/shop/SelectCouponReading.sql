SELECT
  user_id
  , coupon_id
  , reading_start_time
  , reading_end_time
  , reading_time 
FROM
  user_coupon_reading 