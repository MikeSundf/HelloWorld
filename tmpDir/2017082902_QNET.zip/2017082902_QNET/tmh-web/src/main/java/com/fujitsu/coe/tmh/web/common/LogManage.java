package com.fujitsu.coe.tmh.web.common;

import static com.fujitsu.coe.tmh.web.common.LogManage.settinglogLevel;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import javax.inject.Inject;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.ws.rs.Produces;

/**
 *
 * @author qnet8733
 */
@Dependent
public class LogManage {

    @Inject
    private SystemSettings settings;

    //private static final Logger logger = Logger.getLogger("LogMannage");
    private static FileHandler fileHandler = null;
//  private String isLogging = "true";
    private static boolean logEnabled = true;
    private static boolean isLogSettingEnd = false;
    private static String logPath = "/temp/icm/serve/";
    private static Level logLevel = Level.ALL;
    public static int settinglogLevel = 8;
    private static int logSize = 50000;
    private static int LogLotate = 10;
    private static final String propertiesFileName = "/tmh/properties/tmhLog.properties";

    @Inject
    InjectionPoint point;

    // ガベージコレクションに回収されないように強参照で保持する
    private final static Logger parentLogger = Logger.getLogger("myapp");

    static {
        if (isLogSettingEnd == false) {
            try {
                /*
                logEnabled = Boolean.valueOf(settings.get("icm.debug.log.enabled", this.isLogging));
                String path = settings.get("icm.debug.log.path", this.logPath);
                Level lv = this.setLevel(settings.get("icm.debug.log.level", "ALL"));
                */
                Properties properties = new Properties();
                InputStream inputStream = new FileInputStream(propertiesFileName);
                properties.load(inputStream);
                inputStream.close();

                logEnabled = Boolean.valueOf(properties.getProperty("logEnabled"));
                logPath = properties.getProperty("logPath");
                logLevel = setLevel(properties.getProperty("logLevel"));
                logSize = Integer.parseInt(properties.getProperty("logSize"));
                LogLotate = Integer.parseInt(properties.getProperty("logLotate"));
                isLogSettingEnd = true;
            } catch (Exception ex) {
                //デフォルト値でログを作成する
            }
        }
        try {
            if (logEnabled) {
                new File(logPath).mkdirs();

                Date date = new Date();
                String rotate = new SimpleDateFormat("yyyyMMdd-").format(date) + "%g.log";
                String logFilePath = logPath + rotate;
                
                fileHandler = new FileHandler(logFilePath, logSize, LogLotate, true);
                fileHandler.setFormatter(new Formatter() {
                    @Override
                    public String format(LogRecord record) {
                        String format = "%1$tF %1$tT:%1$tL [%2$s]\t%3$s.%4$s()\t%5$s %n";
                        return String.format(format,
                                record.getMillis(),
                                record.getLevel().getName(),
                                record.getSourceClassName(),
                                record.getSourceMethodName(),
                                record.getMessage()
                        );
                    }
                }
                );
            }
            parentLogger.setLevel(logLevel);
            parentLogger.addHandler(fileHandler);
        } catch (Exception ex) {
            // 例外処理
        }
    }

    @Produces
    public Logger getLogger() {
        String loggerName = "myapp." + point.getMember().getDeclaringClass().getName();
        return Logger.getLogger(loggerName);
    }

    public void log(Level lv, String className, String method, String msg) {
        parentLogger.logp(lv, className, method, msg);
//        if (fileHandler == null) {
//            this.setLogger();
//        }
//
//        if (fileHandler != null) {
//            logger.logp(lv, className, method, msg);
//            fileHandler.close();
//        }
//        fileHandler = null;
    }

//
//    /**
//     * <pre>
//     * ログの設定を行う。
//     * DBから設定値を持ってくる。
//     * その際にエラーになった場合は、デフォルト値を設定する
//     * <pre>
//     */
//    public void setLogger() {
//
//        if (fileHandler == null) {
//            if (isLogSettingEnd == false) {
//                try {
//                    logEnabled = Boolean.valueOf(settings.get("icm.debug.log.enabled", this.isLogging));
//                    String path = settings.get("icm.debug.log.path", this.logPath);
//                    Level lv = this.setLevel(settings.get("icm.debug.log.level", "ALL"));
//
//                    this.logPath = path;
//                    this.logLevel = lv;
//                } catch (SQLException ex) {
//                    //デフォルト値でログを作成する
//                }
//                this.isLogSettingEnd = true;
//            }
//            try {
//
//                if (logEnabled) {
//
//                    new File(logPath).mkdirs();
//
//                    Date date = new Date();
//                    String rotate = new SimpleDateFormat("yyyyMMdd-").format(date) + "%g.log";
//                    String logFilePath = logPath + rotate;
//
//                    fileHandler = new FileHandler(logFilePath, 500000, 200, true);
//                    fileHandler.setFormatter(new Formatter() {
//                        @Override
//                        public String format(LogRecord record) {
//                            String format = "%1$tF %1$tT:%1$tL [%2$s]\t%3$s.%4$s()\t%5$s %n";
//                            return String.format(format,
//                                    record.getMillis(),
//                                    record.getLevel().getName(),
//                                    record.getSourceClassName(),
//                                    record.getSourceMethodName(),
//                                    record.getMessage()
//                            );
//                        }
//                    }
//                    );
//                    logger.addHandler(fileHandler);
//                    logger.setLevel(logLevel);
//
//                    ConsoleHandler consoleHandler = new ConsoleHandler();
//                    consoleHandler.setLevel(Level.CONFIG);
//                    logger.addHandler(consoleHandler);
//                    logger.setUseParentHandlers(false);
//                }
//
//            } catch (IOException | SecurityException ex) {
//            }
//        }
//    }
//
//    /**
//     * デバッグログ出力
//     *
//     * @param lv　ログレベル
//     * @param className　クラス名
//     * @param method　メソッド名
//     * @param msg 出力ログ
//     */
//    public void log(Level lv, String className, String method, String msg) {
//
//        if (fileHandler == null) {
//            this.setLogger();
//        }
//
//        if (fileHandler != null) {
//            logger.logp(lv, className, method, msg);
//            fileHandler.close();
//        }
//        fileHandler = null;
//    }
//
    /**
     * スタックトレース出力ログ
     *
     * @param lv　ログレベル
     * @param className　クラス名
     * @param method　メソッド名
     * @param msg　出力メッセージ
     * @param thrown スタックトレース
     */
    public void thrownLog(Level lv, String className, String method, String msg, Throwable thrown) {

        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        thrown.printStackTrace(printWriter);
        parentLogger.logp(lv, className, method, msg + " " + stringWriter.toString());

    }
    /**
     * ログレベルの変換 (String -> Level)
     * <pre>
     * ログレベル	意味
     * Level.FINEST	詳細レベル（高）／最も詳細
     * Level.FINER	詳細レベル（中）／詳細
     * Level.FINE      詳細レベル（低）／普通
     * Level.CONFIG	設定／構成
     * Level.INFO	情報
     * Level.WARNING	警告
     * Level.SEVERE	致命的／重大
     *
     * @param lv ログレベル
     * <pre>
     * @return lv ログレベル
     */
    private static Level setLevel(String lv) {

        Level logLv = Level.ALL;
        switch (lv) {
            case "ALL":
                logLv = Level.ALL;
                settinglogLevel = 8;
                break;
            case "FINEST":
                logLv = Level.FINEST;
                settinglogLevel = 7;
                break;
            case "FINER":
                logLv = Level.FINER;
                settinglogLevel = 6;
                break;
            case "FINE":
                logLv = Level.FINE;
                settinglogLevel = 5;
                break;
            case "CONFIG":
                logLv = Level.CONFIG;
                settinglogLevel = 4;
                break;
            case "INFO":
                logLv = Level.INFO;
                settinglogLevel = 3;
                break;
            case "WARNING":
                logLv = Level.WARNING;
                settinglogLevel = 2;
                break;
            case "SEVERE":
                logLv = Level.SEVERE;
                settinglogLevel = 1;
                break;
            case "OFF":
                logLv = Level.OFF;
                settinglogLevel = 0;
                break;
        }

        return logLv;
    }
}
