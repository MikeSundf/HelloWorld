package com.fujitsu.coe.tmh.web.Location;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.res.ClasspathResource;
import com.fujitsu.coe.tmh.web.common.AdminType;
import com.fujitsu.coe.tmh.web.common.ErrorFactory;
import com.fujitsu.coe.tmh.web.common.LogManage;
import com.fujitsu.coe.tmh.web.common.MapBuilder;
import static com.fujitsu.coe.tmh.web.common.ParamConstants.*;
import com.fujitsu.coe.tmh.web.common.SystemSettings;
import com.fujitsu.coe.tmh.web.common.ValidationCheck;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.QueryParam;
import org.jasypt.util.password.StrongPasswordEncryptor;
import java.util.Calendar;
import java.util.Set;

/**
 * Service related to User Info
 *
 * @author agustiars
 */
@Path("/Location")
@ApplicationScoped
public class userLocationService {

    String classname = userLocationService.class.getName();
    static final String LineSeparator = System.getProperty("line.separator");

    @Inject
    private JdbcTemplate db;
    @Inject
    @ClasspathResource("CreateUploadLocation.sql")
    private String sqlCreateUploadLocation;
    @Inject
    @ClasspathResource("CreateUploadBeaconUserRecord.sql")
    private String sqlCreateUploadBeaconUserRecord;
    @Inject
    @ClasspathResource("GetUserLocation.sql")
    private String sqlGetUserLocation;
    @Inject
    @ClasspathResource("GetUserBeaconInfo.sql")
    private String sqlGetUserBeaconInfo;
    @Inject
    @ClasspathResource("GetBeaconInfo3.sql")
    private String sqlGetBeaconInfo;
    @Inject
    private AdminType adminUtil;
    @Inject
    private SystemSettings settings;
    @Inject
    private LogManage logger;
    private final StrongPasswordEncryptor encryptor;
    
    public userLocationService() {
        encryptor = new StrongPasswordEncryptor();
    }

    /**
     * ユーザの位置情報を登録
     * @param user_id
     * @param time
     * @param lat
     * @param lon
     * @param accuracy
     * @author QNET
     * @return 
     */
    @POST
    @Path("/uploadLocation")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map uploadLocation(
            @FormParam("user_id") @DefaultValue("") String user_id, 
            @FormParam("time") @DefaultValue("") String time,
            @FormParam("lat") @DefaultValue("-1") float lat,
            @FormParam("lon") @DefaultValue("-1") float lon,
            @FormParam("accuracy") @DefaultValue("-1") float accuracy
    ) throws SQLException{
        
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", time=" + time + ", lat=" + lat +  ", lon=" + lon +  ", accuracy=" + accuracy + "]");

        //必須項目チェック
        if (user_id.equals("") || time.equals("") || lat == -1 || lon == -1 || accuracy == -1) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);    
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // user_idのバリデーションチェック
        if(!ValidationCheck.checkUserId(user_id)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG + "[" + user_id + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        // timeのバリデーションチェック
        if (!ValidationCheck.checkDate(time)) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG + "[" + time + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        // latのバリデーションチェック
        if (lat != -1) {
            int res = ValidationCheck.checkLatLon(lat, LATITUDE);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(lat);
            } else if (res != 0) {
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG + "[" + lat + "]");
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
        }
        // lonのバリデーションチェック
        if (lon != -1) {
            int res = ValidationCheck.checkLatLon(lon, LONGITUDE);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lon = ValidationCheck.roundUpLatLon(lon);
            } else if (res != 0) {
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG + "[" + lon + "]");
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
        }
        // accuracyのバリデーションチェック
        if (accuracy != -1) {
            int res = ValidationCheck.checkLatLon(accuracy, 0);
            if (res == NUM_DECIMAL_OVER) {
                // 小数部の最大桁数超えの場合は四捨五入する
                lat = ValidationCheck.roundUpLatLon(accuracy);
            } else if (res != 0) {
                logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG + "[" + accuracy + "]");
                return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
            }
        }
        // 時刻をTimestamp型に変換
        java.sql.Timestamp timestamp = null;
        try {
            java.util.Date datetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time);
            timestamp = new java.sql.Timestamp(datetime.getTime());
        } catch (ParseException pEx) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        // 権限チェック
        int userType = adminUtil.getUserType(user_id);
        if (userType != USER_INFO_TYPE_USER) {
            logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        
        int status = 0;
        
        // システムセッティングから情報取得
        boolean spatiowl_useFlg = Boolean.valueOf(settings.get("user.location.spatiowl.usageflag", "false"));
        String spatiowl_ver = settings.get("user.location.spatiowl.version", "");
        boolean db_useFlg = Boolean.valueOf(settings.get("user.location.db.usageflag", "false"));
        // SPATIOWL,DBとも未使用の場合はシステムエラーとする。
        if( (spatiowl_useFlg == false && db_useFlg== false) || ( spatiowl_useFlg == true && spatiowl_ver.length() == 0 && db_useFlg== false)){
            logger.log(Level.WARNING, classname, methodName, "Both SPATIOWL and DB unsed. Please check the setting of System_setting.");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        
        try{
            if(spatiowl_useFlg == true){
                // SPATIOWL使用
                switch (spatiowl_ver) {
                    case "v1":
                        // SPATIOWL v1への設定要求
                        status = 4;
                        String spatiowl_v1_url = settings.get("spatiowl.v1.url", "");
                        if(spatiowl_v1_url.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v1 url set in system setting is invalid.");
                            break;
                        }
                        String spatiowl_DLMName = settings.get("spatiowl.v1.DLMName", "");
                        if(spatiowl_DLMName.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v1 DLMName set in system setting is invalid.");
                            break;
                        }
                        String spatiowl_layerName = settings.get("spatiowl.v1.layerName", "");
                        if(spatiowl_layerName.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v1 layerName set in system setting is invalid.");
                            break;
                        }
                        // method=putMO&result=json&DLMName=dlmId01&layerName=QnetTestLayer&id=9999999999&lon=139.76716681747&lat=35.680802818389
                        Map<String, Object> pramMapV1 = new LinkedHashMap<>();
                        pramMapV1.put("method", "putMO");
                        pramMapV1.put("result", "json");
                        pramMapV1.put("DLMName", spatiowl_DLMName);
                        pramMapV1.put("layerName", spatiowl_layerName);
                        pramMapV1.put("id", user_id);
                        String encodedTime = URLEncoder.encode(time, "UTF-8");
                        pramMapV1.put("timeStamp", encodedTime);
                        pramMapV1.put("lon", lon);
                        pramMapV1.put("lat", lat);
                    //  pramMapV1.put("data", accuracy);

                        // HTTP通信
                        Map responseV1 = httpNotice("GET", spatiowl_v1_url, pramMapV1);

                        // HTTPステータス判定
                        int httpStatusV1 = (int)responseV1.get("httpStatus");
                        if(httpStatusV1 != 200){
                            if(httpStatusV1 == 9999){
                                Exception detailV1 = (Exception)responseV1.get("detail");
                                logger.thrownLog(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " [HTTP Exception.]" + LineSeparator, detailV1);
                            }
                            else{
                                String detailV1 = (String)responseV1.get("detail");
                                logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " HTTP status[" + httpStatusV1 + "] detail[" + detailV1 + "]");
                            }
                            status = 2;
                        }
                        else{
                            // SPATIOWLステータス判定
                            String detailV1 = (String)responseV1.get("detail");
                            Map resultV1 = new ObjectMapper().readValue(detailV1, LinkedHashMap.class);
                            Map resultInfoV1 = (Map)resultV1.get("resultInfo");
                            int returnCodeV1 = (int)resultInfoV1.get("returnCode");
                            if(returnCodeV1 != 0){
                                logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG1 + " SPATIOWL returnCode[" + returnCodeV1 + "]");
                                status = 1;
                            }
                            else{
                                status = 0;
                            }
                        }
                        break;

                    case "v2":
                        // SPATIOWL v2への設定要求
                        status = 4;
                        String spatiowl_hostName = settings.get("spatiowl.v2.hostName", "");
                        if(spatiowl_hostName.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 hostName set in system setting is invalid.");
                            break;
                        }
                        String spatiowl_versionInf = settings.get("spatiowl.v2.versionInfo", "");
                        if(spatiowl_versionInf.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 versionInf set in system setting is invalid.");
                            break;
                        }
                        String spatiowl_accountID = settings.get("spatiowl.v2.accountID", "");
                        if(spatiowl_accountID.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 accountID set in system setting is invalid.");
                            break;
                        }
                        String spatiowl_subAccountID = settings.get("spatiowl.v2.subAccountID", "");
                        if(spatiowl_subAccountID.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 subAccountID set in system setting is invalid.");
                        }
                        String spatiowl_spaceID = settings.get("spatiowl.v2.spaceID", "");
                        if(spatiowl_spaceID.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 spaceID set in system setting is invalid.");
                            break;
                        }
                        String spatiowl_layerID = settings.get("spatiowl.v2.layerID", "");
                        if(spatiowl_layerID.length() == 0){
                            logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 layerID set in system setting is invalid.");
                            break;
                        }

                        String spatiowl_v2_url;
                        spatiowl_v2_url =  "http://" + spatiowl_hostName;
                        spatiowl_v2_url += "/" + spatiowl_versionInf;
                        spatiowl_v2_url += "/" + spatiowl_accountID;
                        if(spatiowl_subAccountID.length() != 0){
                            // spatiowl_subAccountIDは設定されている場合のみ
                            spatiowl_v2_url += "." + spatiowl_subAccountID;
                        }
                        spatiowl_v2_url += "/" + spatiowl_spaceID;
                        spatiowl_v2_url += "/" + spatiowl_layerID;
                        Map<String, Object> pramMapV2 = new HashMap<>();
                        pramMapV2.put("method", "getMO");
                        pramMapV2.put("id", user_id);
                        pramMapV2.put("timeStamp", time);
                        pramMapV2.put("lon", lon);
                        pramMapV2.put("lat", lat);
                        String relation = "\"relation\": [{ \"relationType\":\"accuracy\",\"dstPath\":\"\",\"attribute\":{ \"accuracy\":" + accuracy + "}]}" ;
                        pramMapV2.put("relation", relation);

                        // HTTP通信
                        Map responseV2 = httpNotice("POST", spatiowl_v2_url, pramMapV2);

                        // HTTPステータス判定
                        int httpStatusV2 = (int)responseV2.get("httpStatus");
                        if(httpStatusV2 != 200){
                            if(httpStatusV2 == 9999){
                                Exception detailV2 = (Exception)responseV2.get("detail");
                                logger.thrownLog(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " [HTTP Exception.]" + LineSeparator,  detailV2);
                            }
                            else{
                                String detailV2 = (String)responseV2.get("detail");
                                logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " HTTP status[" + httpStatusV2 + "] detail[" + detailV2 + "]");
                            }
                            status = 2;
                        }
                        else{
                            // SPATIOWLステータス判定
                            String detailV2 = (String)responseV2.get("detail");
                            Map resultV2 = new ObjectMapper().readValue(detailV2, LinkedHashMap.class);
                            Map resultInfoV2 = (Map)resultV2.get("metadata");
                            String returnCodeV2 = (String)resultInfoV2.get("code");
                            if(!returnCodeV2.equals("0")){
                                logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG1);
                                status = 1;
                            }
                            else{
                                status = 0;
                            }
                        }
                        break;
                    default:
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL version set in system setting is invalid.");
                        break;
                }
            }

            if(db_useFlg == true){
                    db.update(sqlCreateUploadLocation, user_id, timestamp, lat, lon, accuracy);
                    logger.log(Level.FINE, classname, methodName, "INSERT user_location:[user_id=" + user_id + ", time=" + timestamp + ", lat=" + lat + ", lon=" + lon + ", accuracy=" + accuracy + "]");
                    // SPATIOWLでNGとなっていても、DBへの登録できれば正常とする。
                    status = 0;
            }
        } catch (SQLException sqle) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
                status = 3;
        } catch (Exception e) {
                logger.thrownLog(Level.SEVERE, classname, methodName, "Exception.", e);
                status = 4;
        }
        
        if(status == 0){
            logger.log(Level.FINE, classname, methodName, "END");
            return MapBuilder.build("ok", true);
        }
        else if( status == 1){
            return ErrorFactory.createError(SPATIOWL_ERROR_CODE1, SPATIOWL_ERROR_MSG1);
        }
        else if( status == 2){
            return ErrorFactory.createError(SPATIOWL_ERROR_CODE2, SPATIOWL_ERROR_MSG2);
        }
        else if( status == 3){
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        else{
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
    }

    /**
     * ユーザのビーコン受信情報を登録
     * @param user_id
     * @param time
     * @param beacon_id
     * @param major_minor
     * @author QNET
     * @return 
     */
    @POST
    @Path("/uploadBeaconUserRecord")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map uploadBeaconUserRecord(
            @FormParam("user_id") @DefaultValue("") String user_id, 
            @FormParam("time") @DefaultValue("") String time,
            @FormParam("beacon_id") @DefaultValue("") String beacon_id,
            @FormParam("major_minor") @DefaultValue("") String major_minor
    ) throws SQLException {
       
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", time=" + time + ", beacon_id=" + beacon_id +  ", major_minor=" + major_minor + "]");

        // 必須項目チェック
        if (user_id.equals("") || time.equals("") || beacon_id.equals("")) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // バリデーションチェック
        List<Object> validateErr = new ArrayList<>();
        boolean validate = ValidationCheck.checkUserId(user_id);
        if (validate == false) {
            validateErr.add("user_id");
        }

        validate = ValidationCheck.checkDate(time);
        if (validate == false) {
            validateErr.add("time");
        }

        validate = ValidationCheck.checkBeaconId(beacon_id);
        if (validate == false) {
            validateErr.add("beacon_id");
        }

        validate = ValidationCheck.checkStr100(major_minor);
        if (validate == false) {
            validateErr.add("major_minor");
        }

        if (validateErr.size() > 0) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG + "[" + validateErr.toString() + "]");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // 権限チェック
        int auth = adminUtil.getUserType(user_id);
        if (auth != USER_INFO_TYPE_USER) {
            logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }

        // 時刻をTimestamp型に変換
        java.sql.Timestamp timestamp = null;
        try {
            java.util.Date datetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time);
            timestamp = new java.sql.Timestamp(datetime.getTime());
        } catch (ParseException pEx) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // major_minor未設定の場合はnullに変換
        String for_db_major_minor = (major_minor.equals("")) ? null : major_minor;

        // データベース設定
        try{
            db.update(sqlCreateUploadBeaconUserRecord, beacon_id, user_id, timestamp, for_db_major_minor);
            logger.log(Level.FINE, classname, methodName, "INSERT user_beacon_info:[beacon_id=" + beacon_id + ", user_id=" + user_id + ", time=" + time + ", major_minor=" + major_minor + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
            logger.log(Level.FINE, classname, methodName, "END");
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     * ユーザの現在地を取得
     * @param user_id
     * @author QNET
     * @return 
     */
    @GET
    @Path("/getCurrentLocation")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map getCurrentLocation(
            @QueryParam("user_id") @DefaultValue("")  String user_id,
            @QueryParam("tgt_user_id") @DefaultValue("")  String tgt_user_id
    ) throws SQLException{
        
        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id+ "]");

        //必須項目チェック
        if (user_id.equals("") || tgt_user_id.equals("")) {
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // user_idのバリデーションチェック
        if(!ValidationCheck.checkUserId(user_id)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        // target user_idのバリデーションチェック
        if(!ValidationCheck.checkUserId(tgt_user_id)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        // 権限チェック(user_id)
        int userType = adminUtil.getUserType(user_id);
        if (userType == USER_INFO_TYPE_USER) {
            logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        // 権限チェック(tgt_user_id)
        int tgtUserType = adminUtil.getUserType(tgt_user_id);
        if (tgtUserType != USER_INFO_TYPE_USER) {
            logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }
        
        int status = 0;

        // レスポンス生成
        Map<String,Object> response = new LinkedHashMap<>();
        
        // システムセッティングから情報取得
        boolean spatiowl_useFlg = Boolean.valueOf(settings.get("user.location.spatiowl.usageflag", "false"));
        String spatiowl_ver = settings.get("user.location.spatiowl.version", "");
        boolean db_useFlg = Boolean.valueOf(settings.get("user.location.db.usageflag", "false"));
        // SPATIOWL,DBとも未使用の場合はシステムエラーとする。
        if( (spatiowl_useFlg == false && db_useFlg== false) || ( spatiowl_useFlg == true && spatiowl_ver.length() == 0 && db_useFlg== false)){
            logger.log(Level.WARNING, classname, methodName, "Both SPATIOWL and DB unsed. Please check the setting of System_setting.");
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        
        try{
            if(spatiowl_useFlg == true){
                // SPATIOWL使用
                switch (spatiowl_ver) {
                case "v1":
                    // SPATIOWL v1からの取得
                    String spatiowl_v1_url = settings.get("spatiowl.v1.url", "");
                    if(spatiowl_v1_url.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v1 url set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    String spatiowl_DLMName = settings.get("spatiowl.v1.DLMName", "");
                    if(spatiowl_DLMName.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v1 DLMName set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    String spatiowl_layerName = settings.get("spatiowl.v1.layerName", "");
                    if(spatiowl_layerName.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v1 layerName set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    // method=putMO&result=json&DLMName=dlmId01&layerName=QnetTestLayer&id=9999999999&lon=139.76716681747&lat=35.680802818389
                    Map<String, Object> pramMapV1 = new HashMap<>();
                    pramMapV1.put("method", "getMO");
                    pramMapV1.put("result", "json");
                    pramMapV1.put("DLMName", spatiowl_DLMName);
                    pramMapV1.put("layerName", spatiowl_layerName);
                    pramMapV1.put("id", tgt_user_id);
                    
                    // HTTP通信
                    Map responseV1 = httpNotice("GET", spatiowl_v1_url, pramMapV1);
                    
                    // HTTPステータス判定
                    int httpStatusV1 = (int)responseV1.get("httpStatus");
                    if(httpStatusV1 != 200){
                        if(httpStatusV1 == 9999){
                            Exception detailV1 = (Exception)responseV1.get("detail");
                            logger.thrownLog(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " [HTTP Exception.]" + LineSeparator, detailV1);
                        }
                        else{
                            String detailV1 = (String)responseV1.get("detail");
                            logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " HTTP status[" + httpStatusV1 + "] detail[" + detailV1 + "]");
                        }
                        if(db_useFlg == false){
                            return ErrorFactory.createError(SPATIOWL_ERROR_CODE1, SPATIOWL_ERROR_MSG1);
                        }
                    }
                    else{
                        // SPATIOWLステータス判定
                        String detailV1 = (String)responseV1.get("detail");
                        Map resultV1 = new ObjectMapper().readValue(detailV1, LinkedHashMap.class);
                        Map resultInfoV1 = (Map)resultV1.get("resultInfo");
                        int returnCodeV1 = (int)resultInfoV1.get("returnCode");
                        if(returnCodeV1 != 0){
                            logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " SPATIOWL returnCode[" + returnCodeV1 + "]");
                            if(db_useFlg == false){
                                return ErrorFactory.createError(SPATIOWL_ERROR_CODE2, SPATIOWL_ERROR_MSG2);
                            }
                        }
                        else{
                            Map resultData = (Map)resultV1.get("resultData");
                            Set<String> keys = resultData.keySet();
                            for (int i = 0; i < keys.size(); i++) {
                                String key = keys.toArray(new String[0])[i];
                                Map resultInfo = (Map)resultData.get(key);
                                response.put("lat", resultInfo.get("lat"));
                                response.put("lon", resultInfo.get("lon"));
                                break;
                            }
                        }
                    }
                    break;
                    
                case "v2":
                    // SPATIOWL v2からの取得
                    String spatiowl_hostName = settings.get("spatiowl.v2.hostName", "");
                    if(spatiowl_hostName.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 hostName set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    String spatiowl_versionInf = settings.get("spatiowl.v2.versionInfo", "");
                    if(spatiowl_versionInf.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 versionInf set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    String spatiowl_accountID = settings.get("spatiowl.v2.accountID", "");
                    if(spatiowl_accountID.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 accountID set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    String spatiowl_subAccountID = settings.get("spatiowl.v2.subAccountID", "");
                    if(spatiowl_subAccountID.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 subAccountID set in system setting is invalid.");
                    }
                    String spatiowl_spaceID = settings.get("spatiowl.v2.spaceID", "");
                    if(spatiowl_spaceID.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 spaceID set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    String spatiowl_layerID = settings.get("spatiowl.v2.layerID", "");
                    if(spatiowl_layerID.length() == 0){
                        logger.log(Level.WARNING, classname, methodName, "The SPATIOWL v2 layerID set in system setting is invalid.");
                        if(db_useFlg == false) return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
                        break;
                    }
                    
                    String spatiowl_v2_url;
                    spatiowl_v2_url = "http://" + spatiowl_hostName;
                    spatiowl_v2_url += "/" + spatiowl_versionInf;
                    spatiowl_v2_url += "/" + spatiowl_accountID;
                    if(spatiowl_subAccountID.length() != 0){
                        spatiowl_v2_url += "." + spatiowl_subAccountID;
                    }
                    spatiowl_v2_url += "/" + spatiowl_spaceID;
                    spatiowl_v2_url += "/" + spatiowl_layerID;
                    Map<String, Object> pramMapV2 = new HashMap<>();
                    pramMapV2.put("method", "getMO");
                    pramMapV2.put("id", tgt_user_id);
                    
                    // HTTP通信
                    Map responseV2 = (Map)httpNotice("POST", spatiowl_v2_url, pramMapV2);
                    
                    // HTTPステータス判定
                    int httpStatusV2 = (int)responseV2.get("httpStatus");
                    if(httpStatusV2 != 200){
                        if(httpStatusV2 == 9999){
                            Exception detailV2 = (Exception)responseV2.get("detail");
                            logger.thrownLog(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " [HTTP Exception.]" + LineSeparator, detailV2);
                        }
                        else{
                            String detailV2 = (String)responseV2.get("detail");
                            logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG2 + " HTTP status[" + httpStatusV2 + "] detail[" + detailV2 + "]");
                        }
                        if(db_useFlg == false){
                            return ErrorFactory.createError(SPATIOWL_ERROR_CODE1, SPATIOWL_ERROR_MSG2);
                        }
                    }
                    else{
                        // SPATIOWLステータス判定
                        String detailV2 = (String)responseV2.get("detail");
                        Map resultV2 = new ObjectMapper().readValue(detailV2, LinkedHashMap.class);
                        Map resultInfoV2 = (Map)resultV2.get("metadata");
                        String returnCodeV2 = (String)resultInfoV2.get("code");
                        if(!returnCodeV2.equals("0")){
                            logger.log(Level.WARNING, classname, methodName, SPATIOWL_ERROR_MSG1);
                            return ErrorFactory.createError(SPATIOWL_ERROR_CODE2, SPATIOWL_ERROR_MSG1);
                        }
                        else{
                            Map resultData = (Map)resultV2.get("resultData");
                            response.put("lat", resultData.get("lat"));
                            response.put("lon", resultData.get("lon"));
                        }
                    }

                    break;
                default:
                    logger.log(Level.WARNING, classname, methodName, "The SPATIOWL version set in system setting is invalid.");
                    break;
                }
            }

            if(db_useFlg == true && response.isEmpty()){
                //UserLocationの最新情報を取得する。
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sqlGetUserLocation, tgt_user_id));
                Map<String, Object> userLocation = new HashMap<>();
                db.query(sqlGetUserLocation, (rs) -> {
                    userLocation.put("time", rs.getString("time"));
                    userLocation.put("lat", (Float)rs.getFloat("lat"));
                    userLocation.put("lon", (Float)rs.getFloat("lon"));
                    userLocation.put("location", rs.getString("location"));
                }, tgt_user_id);
                
                //UserBeaconInfoの最新情報を取得する。
                logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sqlGetUserBeaconInfo, tgt_user_id));
                Map<String, Object> userBeacon = new HashMap<>();
                db.query(sqlGetUserBeaconInfo, (rs) -> {
                    userBeacon.put("time", rs.getString("time"));
                    userBeacon.put("beacon_id", rs.getString("beacon_id"));
                }, tgt_user_id);
                
                // UserLocationとUserBeaconInfoの時間を比較して
                // UserLocationが最新であれば、UserLocationの情報を返す。
                // そうであない場合は、Beacon_idでBeaconInfoを検索して
                // その位置情報を返す。
                String userLocationDatetime = (String)userLocation.get("time");
                SimpleDateFormat userLocationSdf = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
                Date userLocationDate = userLocationSdf.parse(userLocationDatetime);
                Calendar userLocationCal = Calendar.getInstance();
                userLocationCal.setTime(userLocationDate);

                String userBeaconDatetime = (String)userBeacon.get("time");
                SimpleDateFormat userBeaconSdf = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
                Date userBeaconDate = userBeaconSdf.parse(userBeaconDatetime);
                Calendar userBeaconCal = Calendar.getInstance();
                userBeaconCal.setTime(userBeaconDate);
                
                int diff = userLocationCal.compareTo(userBeaconCal);
                if(diff == 0 || diff > 0){
                    // UserLocationが最新
                    response.put("lat", userLocation.get("lat"));
                    response.put("lon", userLocation.get("lon"));
                    response.put("location", userLocation.get("location"));
                    logger.log(Level.FINE, classname, methodName, "END");
                //    return response;
                }
                else{
                    // UserBeaconInfoが最新
                    logger.log(Level.FINE, classname, methodName, String.format("SQL:[%s] Param:[%s]", sqlGetBeaconInfo, tgt_user_id));
                    db.query(sqlGetBeaconInfo, (rs) -> {
                        response.put("lat", rs.getFloat("lat"));
                        response.put("lon", rs.getFloat("lon"));
                        response.put("venue_id", rs.getString("venue_id"));
                    }, userBeacon.get("beacon_id"));
                    logger.log(Level.FINE, classname, methodName, "END");
                //    return response;
                }
            }
        } catch (SQLException sqle ) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB Select error.", sqle);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SQL_ERROR_MSG);
        }
        catch (ParseException e) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "Date Parse error.", e);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        catch (Exception e) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "Exception.", e);
            return ErrorFactory.createError(SYSTEM_ERROR_CODE, SYSTEM_ERROR_MSG);
        }
        return response;
    }
    
    private static Map httpNotice(String methodName, String spatiowlUrl, Map<String, Object> pramMap) {
        PrintStream ps;
        String urlParam = "";
        URL url;
        HttpURLConnection connection = null;
        String ditailInfo = ""; 
        Map<String, Object> response = new HashMap<>();

        try {
            int mapcnt = pramMap.size();
            int cnt = 0;
            if (mapcnt > 0) {
                //URLパラメータ作成
                for (String key : pramMap.keySet()) {
                    urlParam += key + "=" + pramMap.get(key);
                    cnt++;
                    if (cnt != mapcnt) {
                        urlParam += "&";
                    }
                }
            }

            if (methodName.equals("POST")) {
                //URL作成 POST
                url = new URL(spatiowlUrl);
            } else {
                //URL作成 GET
                String urlbase = spatiowlUrl;
                if (urlParam.length() > 0) {
                    url = new URL(spatiowlUrl + "?" + urlParam);
                } else {
                    url = new URL(spatiowlUrl);
                }
            }

            //オブジェクト生成
            connection = (HttpURLConnection) url.openConnection();
            //接続タイムアウト
            connection.setConnectTimeout(100000);
            //レスポンスデータ読み取りタイムアウト
            connection.setReadTimeout(100000);
            //ヘッダーにContent-Typeを設定
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            //HTTPのメソッドをPOSTに設定
            connection.setRequestMethod(methodName);
            //レスポンスのボディ受信を許可
            connection.setDoInput(true);

            if (methodName.equals("POST")) {
                //リクエストのボディ送信を許可
                connection.setDoOutput(true);
                ps = new PrintStream(connection.getOutputStream());
                ps.print(urlParam);
                ps.close();
            }

            //コネクションを開く
            connection.connect();

            int ret = connection.getResponseCode();
            response.put("httpStatus", ret);
            String line;
            //System.out.println("ステータス:" + ret);
            if (ret == HttpURLConnection.HTTP_OK) {
                try (InputStreamReader isr = new InputStreamReader(connection.getInputStream(),
                        StandardCharsets.UTF_8);
                        BufferedReader reader = new BufferedReader(isr)) {

                    while ((line = reader.readLine()) != null) {
                        ditailInfo += line;
                    }
                }
            }
            //HTTPステータス　300番台
            if (ret / 100 == 3) {

                try (InputStreamReader isr = new InputStreamReader(connection.getInputStream(),
                        StandardCharsets.UTF_8);
                        BufferedReader reader = new BufferedReader(isr)) {
                    while ((line = reader.readLine()) != null) {
                        ditailInfo += line;
                    }
                }
            }
            //HTTPステータス　400、500番台
            if ((ret / 100 == 4) || ret / 100 == 5) {

                try (InputStreamReader isr = new InputStreamReader(connection.getErrorStream(),
                        StandardCharsets.UTF_8);
                        BufferedReader reader = new BufferedReader(isr)) {
                    while ((line = reader.readLine()) != null) {
                        ditailInfo += line;
                    }
                }
            }
            response.put("detail", ditailInfo);
            
        } catch (IOException e) {
            response.put("httpStatus", 9999);
            response.put("detail", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return response;
    }
}
