package com.fujitsu.coe.tmh.web;

import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author unicenfujitsu
 */
@Path("/")
@ApplicationScoped
public class CheckService {
    
    @Inject
    private SystemSettings settings;
    
    @GET
    @Path("/check")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> check(@QueryParam("v") String version) throws SQLException {
        Set<String> compatible = new HashSet<>(Arrays.asList(settings.get("init.version", "1.0").split(" ")));
        if (!compatible.contains(version)) {
            return MapBuilder.build("compat", false);
        }
        String message = settings.get("init.message", null);
        String image = settings.get("init.img", null);
        String url = settings.get("init.url", null);
        
        return MapBuilder.create("compat", true)
                .put("msg", message)
                .put("img", image)
                .put("url", url)
                .build();
    }
}
