package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.tmh.web.product.Coupon;
import com.fujitsu.coe.tmh.web.product.Product;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.StringJoiner;

/**
 *
 * @author chuakayick
 */
public class CouponAssigner {

    private ICMContext ctx;
    private List<Coupon> coupons;
    private List<Product> products;

    public CouponAssigner(ICMContext ctx, List<Coupon> coupons, List<Product> products) {
        this.ctx = ctx;
        this.coupons = coupons;
        this.products = products;
    }

    public void assign() throws SQLException {
        ctx.timer.start("ca.sort");
        Collections.sort(coupons, (c1, c2) -> {
            return c1.getEDT() - c2.getEDT();
        });
        ctx.timer.stop();
        ctx.log(CA_EDT1);
        for (Coupon coupon : coupons) {
            ctx.log(CA_EDT2, coupon.getId(), coupon.getCategory(), coupon.getShop(), coupon.getTitle(), coupon.getEDT());
        }

        // Extract download/dwell reward
        ctx.timer.start("ca.reward");
        Coupon dlReward = null;
        Coupon dwReward = null;
        
        for (Iterator<Coupon> it = coupons.iterator(); it.hasNext();) {
            Coupon coupon = it.next();
            if (coupon.getEDT() > 0) {  // we expect dl/dw coupons to be first in line
                break;
            } else if (coupon.getEDT() == -1) {
                dlReward = coupon;
            } else if (coupon.getEDT() == -2) {
                dwReward = coupon;
            }
            it.remove();
        }
        if (dlReward == null || dwReward == null) { // coupon already used
            dlReward = dwReward = null;
        }
        ctx.timer.stop();
        
        ctx.timer.start("ca.assign");
        HashSet<Coupon> usedCoupons = new HashSet<>();
        ctx.log(CA_PRODUCT1);
        for (Product product : products) {
            List<Coupon> assigned = new ArrayList<>();
            if (dlReward != null) {
                if (product.getDt() == 0) {
                    assigned.add(dlReward);
                } else {
                    assigned.add(dwReward);
                }
                usedCoupons.add(dlReward);  // use download reward to count total rewards given
            }
            for (Coupon coupon : coupons) {
                if (coupon.getEDT() > product.getDt()) {
                    break;
                }
                // TODO consider total coupon limit after adding reward coupons (for KWM-FT2 no issue as we show all coupons)
                assigned.add(coupon);
                usedCoupons.add(coupon);
            }
            product.setCoupons(_clone(assigned));
            ctx.log(CA_PRODUCT2, product.getEgress().getMode(), product.getDt(), assigned.size());
        }
        ctx.timer.stop();
        
        ctx.timer.start("ca.reduce");
        StringJoiner inCondition = new StringJoiner(",", "(", ")");
        inCondition.add("0");
        for (Coupon coupon : usedCoupons) {
            inCondition.add(String.valueOf(coupon.getId()));
        }
        ctx.db.update(String.format("UPDATE coupon SET available = available - 1 WHERE id IN %s", inCondition));
        ctx.timer.stop();
    }

    private List<Coupon> _clone(List<Coupon> toClone) {
        List<Coupon> cloned = new ArrayList<>();
        for (Coupon coupon : toClone) {
            cloned.add((Coupon) coupon.clone());
        }
        return cloned;
    }
}
