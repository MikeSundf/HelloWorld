Select
  c.coupon_id
  , c.title
  , c.description
  , c.terms
  , c.expiry_date
  , c.expiry_duration
  , c.expected_dwell_time
  , c.coupon_value
  , shop.shop_id
  , shop.name
  , shop.address
  , shop.tel
  , shop.location
  , shop.map_hint
  , pc.redemption_time
  , logo.logo
from
  coupon c 
   left join shop 
    on c.shop_id = shop.shop_id 
   left join product_coupon pc 
    on c.coupon_id = pc.coupon_id 
   left join shop_logo logo 
    on c.shop_id = logo.shop_id 
where 
 