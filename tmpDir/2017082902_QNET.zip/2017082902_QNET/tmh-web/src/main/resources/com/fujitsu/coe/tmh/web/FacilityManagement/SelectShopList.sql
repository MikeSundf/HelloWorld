SELECT
  shop_id
FROM
  shop 
WHERE
  venue_id = ? AND enable_flag = true
ORDER BY
  shop_id