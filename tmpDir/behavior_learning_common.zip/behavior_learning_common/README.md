How to run the code
===================

## Prerequisites
* Anaconda (Python 2)
* ICM database in PostgreSQL

## Steps
1. Edit the `database.ini` configuration file to correct the ICM database credentials.
2. From the command line, type

  ```
  python po_learning.py <id>
  ```
  
  where `<id>` is the user ID to learn.

The Learning algorithm will study the user's behavior from the database and update the user coefficients back to the database.


How to run the validation
=========================
## Prerequisites
* Anaconda (Python 2)
* ICM Validation database in PostgreSQL

## Validation 1: Steps
1. Edit the 'database.ini' configuration file to correct the ICM Validation database credentials.
2. From the command line, type


  ```
  python validation_input2.py
  ```
The validation codes will plot the histogram of three errors of all the synthetic users in ICM Validation database and store the errors in three csv files:
  1. Normalized error of the last iteration
  2. Absolute error of the last iteration
  3. Absolute error/true value of the last iteration

## Validation 2: Steps
1. Edit the 'database.ini' configuration file to correct the ICM Validation database credentials.
2. From the command line, type


  ```
  python validation_input3.py
  ```
This validation code will count the number of different transport mode in every time slot in 
  1. All shown products
  2. All selected products
  
