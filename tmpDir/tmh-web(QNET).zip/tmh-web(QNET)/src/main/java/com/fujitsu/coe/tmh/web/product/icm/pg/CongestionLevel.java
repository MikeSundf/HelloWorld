package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toHHMM;
import java.sql.SQLException;

/**
 *
 * @author kychua
 */
public class CongestionLevel {
    
    private ICMContext ctx;
    private String congestion;
    
    public CongestionLevel(ICMContext ctx) throws SQLException {
        this.ctx = ctx;
        congestion = ctx.settings.get(String.format("algo.congestion.%d", ctx.user.getVenue()));
    }
    
    public int get(Egress.Mode mode, long stepTime) throws SQLException {
        int hhmm = toHHMM(new Date(stepTime));
        int index = (mode.ordinal() * 96) + (hhmm / 100 * 4) + (hhmm % 100 / 15);
        if (index >= congestion.length()) return -1;
        return congestion.charAt(index) - '0';
    }

    @Override
    public String toString() {
        return congestion;
    }
}
