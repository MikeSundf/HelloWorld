package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.tmh.web.product.Coupon;
import com.fujitsu.coe.tmh.web.product.Egress.Mode;
import com.fujitsu.coe.tmh.web.product.Product;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.*;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author unicenfujitsu
 */
public class ProductRefiner {

    private ICMContext ctx;
    private List<Product> products;
    private Random rng;

    public ProductRefiner(ICMContext ctx, List<Product> products) {
        this.ctx = ctx;
        this.products = products;
        this.rng = new Random();
    }

    public void refine() {
        ctx.log(PR);
        for (Product product : products) {
            if (product.getEgress().getMode() == Mode.STAXI) {
                // don't shift any shared-taxi time, but we need to set the dep/arr time.
                product.reschedule();
                continue;
            }
            if (product.getEgress().getMode() == Mode.SHUTTLE) {
                continue;   // the shuttle will leave on the dot, don't mess with it.
            }
            
            int slot = rng.nextInt(3);
            int original = product.getDt();
            product.addDwellTime(slot * 5);
            if (product.getEgress().getMode() == Mode.TAXI) {
                // round taxi departure time to round numbers
                int mins = (int)(TimeUnit.MILLISECONDS.toMinutes(product.getStartTime().getTime()) % 60);
                product.addDwellTime((5 - (mins % 5)) % 5);
            }
            product.reschedule();
            for (Coupon coupon: product.getCoupons()) {
                coupon.setExpiry(product.getEgress().getDep()); // KWM-FT2 update expiry date for coupon to match egress for download/dwell reward redemption
            }
            ctx.log(PR_DT, product.getEgress().getMode(), original, product.getDt());
        }
    }

}
