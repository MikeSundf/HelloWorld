package com.fujitsu.coe.tmh.web.product.icm.po;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.ss.util.NamedThreadFactory;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.Egress.Mode;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.*;
import com.fujitsu.coe.tmh.web.util.Drain;
import com.fujitsu.coe.tmh.web.util.PathPrefix;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;


/**
 *
 * @author unicenfujitsu
 */
public class ProductOptimizer {

    private static final Logger LOGGER = Logger.getLogger(ProductOptimizer.class.getName());
    private ICMContext ctx;
    private List<Product> products;
    private ExecutorService pool;
    private int hurry;

    public ProductOptimizer(ICMContext ctx, List<Product> products, int hurry) {
        this.ctx = ctx;
        this.products = products;
        this.hurry = hurry;
    }

    public void optimize() throws IOException, JsonProcessingException, SQLException {
        if (taxiOptimize()) {
            return;
        }
        
        pool = Executors.newFixedThreadPool(10, new NamedThreadFactory("icm-optimizer")); // TODO reuse at higher level
        AlgoInput input = setupInput();

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(input);
        ctx.log(PO_INPUT, json);

        Path workingPath = FileSystems.getDefault().getPath(ctx.settings.get("algo.opt.path", "/Temp/algo/log"));
        PathPrefix inF = new PathPrefix(workingPath, ctx.reqId + "-algo", ".txt");
        Files.write(inF.getPath(".in"), Arrays.asList(json), StandardOpenOption.CREATE_NEW);

        String poMode = ctx.settings.get("algo.opt.mode.socket", "false");
        Path outF = "true".equals(poMode) ? executeSocket(inF) : execute(inF);

        AlgoOutput[] output;
        try (InputStream in = Files.newInputStream(outF)) {
            output = mapper.readValue(in, AlgoOutput[].class);
        }
        List<Product> optProducts = new ArrayList<>();
        for (AlgoOutput optimized : output) {
            Product optimal = products.get(optimized.getIndex());
            ctx.log(PO_OUTPUT, optimal.getEgress().getMode(), optimal.getDt(), optimized.isIncentive());
            // KWM-FT2: don't respect i in optimization response as this will wipe out the download reward
            /*
            if (!optimized.isIncentive()) {
                optimal.getCoupons().clear();
            }
            */
            optProducts.add(optimal);
        }
        // cannot use retainAll as this does not change the sequence
        // products.retainAll(optProducts);
        products.clear();
        products.addAll(optProducts);
        
        // TODO tentative way to order products for field test.
        Collections.sort(products, (p1, p2) -> {
            return p2.getDt() - p1.getDt();   // highest to lowest dwell time
        });

        pool.shutdown();
    }

    // convert users and products into algo json
    private AlgoInput setupInput() throws SQLException {
        double ascBus = Double.parseDouble(ctx.settings.get("algo.asc.bus", "-0.55"));
        double ascMrt = Double.parseDouble(ctx.settings.get("algo.asc.mrt", "-0.75"));
        double ascStaxi = Double.parseDouble(ctx.settings.get("algo.asc.staxi", "0"));

        double[] beta = ctx.db.query("SELECT * FROM user_profile WHERE user_id=?",
                (rs) -> new double[]{
                    rs.getDouble("beta_ivtt"),
                    rs.getDouble("beta_dt"), 
                    rs.getDouble("beta_wt"), 
                    rs.getDouble("beta_ovtt"), 
                    
                    rs.getDouble("beta_cg"), 
                    rs.getDouble("beta_i"),
                    
                    ascBus, ascMrt, ascStaxi},
                ctx.user.getId()).get(0);
        ctx.log(PO_VOT, beta[0], beta[1], beta[2], beta[3], beta[4], beta[5], beta[6], beta[7], beta[8]);
        beta[1] = hurry(beta[1]); // adjust betaDT

        List<AlgoProduct> algoProducts = new ArrayList<>();
        for (Product product : products) {
            Egress egress = product.getEgress();
            algoProducts.add(new AlgoProduct(egress.getMode().toString(), egress.getFare(), product.getDt(),
                    product.getTt(), product.getWt(), product.getAt(), egress.getCongestion() - 1,
                    // SCC-FT2: no coupons, so cv always 0
                    0, /* CouponValuator.getValue(product.getDt()), */
                    (product.getDt() == 0) ? 0 : 1));
        }

        return new AlgoInput(new AlgoUser(beta), algoProducts);
    }
    
    private Path executeSocket(PathPrefix inF) throws IOException, JsonProcessingException, SQLException {
        Path outF = inF.getPath(".out");
        ctx.timer.start("po.python");
        Socket socket = new Socket("localhost", 8787);
        PrintWriter out = new PrintWriter(socket.getOutputStream());
        out.println(String.format("%s %s", inF.getPath(".in").toString(), outF.toString()));
        out.flush();
        
        InputStream in = socket.getInputStream();
        while (in.read() != -1);
        ctx.timer.stop();
        
        return outF;
    }

    private Path execute(PathPrefix inF) throws IOException, JsonProcessingException, SQLException {
        String executable = ctx.settings.get("algo.opt.python", "python");
        String algo = ctx.settings.get("algo.opt.algo", "/Temp/algo/mainR6.py");
        Path outF = inF.getPath(".out");
        ctx.timer.start("po.python");
        Process py = Runtime.getRuntime().exec(String.format("%s %s %s %s", executable, algo, inF.getPath(".in").toString(), outF.toString()));
        pool.submit(new Drain(inF.getPath(".log"), py.getInputStream()));
        pool.submit(new Drain(inF.getPath(".err"), py.getErrorStream()));
        try {
            py.waitFor();
        } catch (InterruptedException ex) {
        }
        ctx.timer.stop();
        
        return outF;
    }

    // adjust betaDT by hurry factor
    private double hurry(double betaDT) throws SQLException {
        String hurryFactor = ctx.settings.get("algo.hurry.beta_dt");
        betaDT *= Double.parseDouble(hurryFactor.split(" ")[hurry]);
        ctx.log(PO_HURRY, hurryFactor.replaceAll(" ", "\t"), betaDT);
        return betaDT;
    }

    private boolean taxiOptimize() {
        for (Product product : products) {
            if (product.getEgress().getMode() != Mode.TAXI) {
                return false;
            }
        }
        
        TaxiOnlyOptimizer.optimize(products);
        return true;
    }
}
