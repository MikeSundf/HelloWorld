package com.fujitsu.coe.tmh.web.common;

import static com.fujitsu.coe.tmh.web.common.ParamConstants.*;
import static java.lang.Double.parseDouble;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * JAX-RS application root.
 *
 * @author fujitsu
 */
public class ValidationCheck {

    public static final String classname = ValidationCheck.class.getName();

    public static final int STR_LEN_0 = 0;
    public static final int STR_LEN_1 = 1;
    public static final int STR_LEN_5 = 5;
    public static final int STR_LEN_8 = 8;
    public static final int STR_LEN_36 = 36;
    public static final int STR_LEN_45 = 45;
    public static final int STR_LEN_100 = 100;
    public static final int STR_LEN_120 = 120;
    public static final int STR_LEN_200 = 200;
    public static final int STR_LEN_300 = 300;
    public static final int STR_LEN_500 = 500;
    public static final int STR_LEN_2000 = 2000;

    public static final long VAL_minus1 = -1;
    public static final long VAL_0 = 0;
    public static final long VAL_1 = 1;
    public static final long VAL_5 = 5;
    public static final long VAL_65535 = 65535;
    public static final long VAL_4294967295 = 4294967295L;

    public static final int LOG_OUTPUT_OFF = 0;
    public static final int LOG_OUTPUT_ON = 1;

    public static boolean checkUserId(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // 文字数チェック
        if ((STR_LEN_8 > str.length()) || (str.length() > STR_LEN_45)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 使用可能文字チェック
        if (!(isUserId(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean isUserId(String str) {
        String ptnStr = "^[a-zA-Z0-9-/_.]*$";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        return mc.matches();
    }

    public static boolean checkEmail(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_100)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 使用可能文字チェック
        if (!(isEmail(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }

        // "."は先頭と末尾以外になっているか
        // "."を2個連続で使用していないか
        if (!(checkPeriod(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use continuation periods.");
            return false;
        }

        return true;
    }

    public static boolean isEmail(String str) {
        String ptnStr = "^[\\w!#%&'/=~`\\*\\+\\?\\{\\}\\^\\$\\-\\|]+(\\.[\\w!#%&'/=~`\\*\\+\\?\\{\\}\\^\\$\\-\\|]+)*@[\\w!#%&'/=~`\\*\\+\\?\\{\\}\\^\\$\\-\\|]+(\\.[\\w!#%&'/=~`\\*\\+\\?\\{\\}\\^\\$\\-\\|]+)*$";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        return mc.matches();
    }

    public static boolean checkPeriod(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // "."は先頭と末尾以外になっているか
        char start_char = str.charAt(0);
        char end_char = str.charAt(str.length() - 1);
        if ((start_char == '.') || (end_char == '.')) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use place period.");
            return false;
        }

        // "."を2個連続で使用していないか
        String ptnStr = "[a-zA-Z]+(\\.[a-zA-Z]+)*$";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        boolean result = mc.matches();
        if (result == true) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use continuation periods.");
            return false;
        }
        return true;
    }

    public static boolean checkEmail(String str, int type) { // tyep 0:ログなし 1:ログあり

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_100)) {
            if (type == 1) {
//                logger.log(Level.WARNING, classname, methodName, "Length over.");
            }
            return false;
        }

        // 使用可能文字チェック
        if (!(isEmail(str))) {
            if (type == 1) {
//                logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            }
            return false;
        }

        // "."は先頭と末尾以外になっているか
        // "."を2個連続で使用していないか
        if (!(checkPeriod(str, type))) {
            if (type == 1) {
//                logger.log(Level.WARNING, classname, methodName, "Bad use continuation periods.");
            }
            return false;
        }

        return true;
    }

    public static boolean checkPeriod(String str, int type) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // "."は先頭と末尾以外になっているか
        char start_char = str.charAt(0);
        char end_char = str.charAt(str.length() - 1);
        if ((start_char == '.') || (end_char == '.')) {
            if (type == 1) {
//                logger.log(Level.WARNING, classname, methodName, "Bad use place period.");
            }
            return false;
        }

        // "."を2個連続で使用していないか
        String ptnStr = "[a-zA-Z]+(\\.[a-zA-Z]+)*$";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        boolean result = mc.matches();
        if (result == true) {
            if (type == 1) {
//                logger.log(Level.WARNING, classname, methodName, "Bad use continuation periods.");
            }
            return false;
        }
        return true;
    }

    public static boolean checkStr45(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_45)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }
        return true;
    }

    public static boolean checkStr100(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_100)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }
        return true;
    }

    public static boolean checkPostal(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_45)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 数字チェック
        if (!isNumber(str)) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean isNumber(String val) {

        try {
            Integer.parseInt(val);
            return true;
        } catch (NumberFormatException nfex) {
            return false;
        }
    }

    public static boolean checkGender(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_1)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 文字チェック
        if (str.charAt(0) != 'M' && str.charAt(0) != 'F') {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean checkAgeGroup(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        Long i = Long.valueOf(str);
        if (i < VAL_0 || i > VAL_65535) {
//            logger.log(Level.WARNING, classname, methodName, "Over range.");
            return false;
        }

        return true;
    }

    public static boolean checkIncomeGroup(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        Long i = Long.valueOf(str);
        if (i < VAL_0 || i > VAL_65535) {
//            logger.log(Level.WARNING, classname, methodName, "Over range.");
            return false;
        }

        return true;
    }

    public static boolean checkIsPublic(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_5)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 文字チェック
        if (!(str.equals("true")) && !(str.equals("false")) && !(str.equals("TRUE")) && !(str.equals("FALSE"))) {    // Boolean.valueOf(str).booleanValue();
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean checkCategoryValue(List<String> category, List<String> value) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((category == null) || (category.equals("")
                || (value == null) || (value.equals("")))) {
            return true;
        }

        // カテゴリと値が同数かチェック
        if (category.size() != value.size()) {
//            logger.log(Level.WARNING, classname, methodName, "Disagreement category and value.");
            return false;
        }

        for (int i = 0; i < category.size(); i++) {
            // 使用可能文字チェック
            if (!(isCategory(category.get(i)))) {
//                logger.log(Level.WARNING, classname, methodName, "Bad use character.");
                return false;
            }
            // 文字数チェック
            if ((STR_LEN_0 > category.get(i).length()) || (category.get(i).length() > STR_LEN_45)) {
//                logger.log(Level.WARNING, classname, methodName, "Length over category.");
                return false;
            }
        }

        for (int i = 0; i < value.size(); i++) {
            // 文字数チェック
            if ((STR_LEN_0 > value.get(i).length()) || (value.get(i).length() > STR_LEN_200)) {
//                logger.log(Level.WARNING, classname, methodName, "Length over value.");
                return false;
            }
        }
        return true;
    }

    public static boolean isCategory(String str) {
        String ptnStr = "^[a-zA-Z0-9-_]*$";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        return mc.matches();
    }

    public static boolean checkJob(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_100)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }
        return true;
    }

    public static boolean checkWorkplaceAddress(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_100)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }
        return true;
    }

    public static boolean checkIntegerId(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 数字チェック
        if (!isNumber(str)) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        Long i = Long.valueOf(str);
        if (i < VAL_minus1 || i > VAL_4294967295) {
//            logger.log(Level.WARNING, classname, methodName, "Over range.");
            return false;
        }
        return true;
    }

    public static boolean checkPassword(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // 文字数チェック
        if ((STR_LEN_8 > str.length()) || (str.length() > STR_LEN_45)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 使用可能文字チェック
        if (!(isUserId(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean checkIdList(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_500)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 使用可能文字チェック
        if (!(isIdList(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean isIdList(String str) {
        String ptnStr = "[0-9,]+";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        return mc.matches();
    }

    public static boolean checkStr120(String str) {

        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_120)) {
            return false;
        }
        return true;
    }

    public static boolean checkDate(String str) {

        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
//            format.setLenient(false);
            java.util.Date date = format.parse(str);
            return true;
        } catch (ParseException ex) {
            return false;
        }

    }

    public static boolean checkStr2000(String str) {

        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_2000)) {
            return false;
        }
        return true;
    }

    public static boolean checkStr300(String str) {

        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > STR_LEN_300)) {
            return false;
        }
        return true;
    }

    public static boolean checkStrLen(String str, int len) {

        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_0 > str.length()) || (str.length() > len)) {
            return false;
        }
        return true;
    }

    public static boolean checkDouble(String str) {

        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 数字チェック
        if (!isDouble(str)) {
            return false;
        }

        // マイナスチェック
        BigDecimal bigdecimal = BigDecimal.valueOf(Double.valueOf(str));
        if (bigdecimal.compareTo(BigDecimal.valueOf(0)) < 0) {
            return false;
        }
        return true;
    }

    public static boolean isDouble(String val) {

        try {
            Double.parseDouble(val);
            return true;
        } catch (NumberFormatException nfex) {
            return false;
        }
    }

    public static boolean checkLong(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 数字チェック
        if (!(isLong(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        Long i = Long.valueOf(str);
        if (i < VAL_minus1 || i > VAL_4294967295) {
//            logger.log(Level.WARNING, classname, methodName, "Over range.");
            return false;
        }
        return true;
    }

    public static boolean isLong(String val) {

        try {
            Long.parseLong(val);
            return true;
        } catch (NumberFormatException nfex) {
            return false;
        }
    }

    public static int checkLatLon(Float location, int len) {

        Double num = parseDouble(location.toString());
        BigDecimal bigdecimal = BigDecimal.valueOf(num);

        if (len < 1) {
            if (bigdecimal.compareTo(BigDecimal.valueOf(0)) < 0) {
                // 値がマイナスだった場合の処理
                return NUM_MINUS;
            }
        }

        if (location > len || location < (len * -1)) {
            return LAT_LON_OUT_OF_RANGE;
        }

        if (bigdecimal.precision() - bigdecimal.scale() > LAT_LON_INTEGER_MAX_LENGTH) {
            // 整数部の桁数が上限を超えてる場合の処理
            return NUM_INTEGER_OVER;
        } else if (bigdecimal.scale() > LAT_LON_DECIMAL_MAX_LENGTH) {
            // 小数点以下の桁数が上限を超えてる場合の処理
            return NUM_DECIMAL_OVER;
        } else {
            return 0;
        }
    }

    public static float roundUpLatLon(Float location) {
        // 小数点以下の桁数が上限を超えてる場合は丸める
        Double num = parseDouble(location.toString());
        BigDecimal value = new BigDecimal(num);
        BigDecimal roundUp = value.setScale(LAT_LON_DECIMAL_MAX_LENGTH, BigDecimal.ROUND_UP);
        return roundUp.floatValue();
    }

    public static boolean checkEvaluation(int num) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        if (num < VAL_1 || num > VAL_5) {
//            logger.log(Level.WARNING, classname, methodName, "Over range.");
            return false;
        }

        return true;
    }

    /**
     * 小数の桁チェック
     *
     * @param num　対象
     * @param limit　limit[0]:整数部最大桁数　limit[1]:小数部最大桁数
     * @return
     */
    public static int checkDecimal(Double num, int... limit) {
//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();

        if (limit.length < 2) {
            limit = new int[2];
            limit[0] = NUM_INTEGER_MAX_LENGTH;
            limit[1] = NUM_DECIMAL_MAX_LENGTH;
        }

        BigDecimal bigdecimal = BigDecimal.valueOf(num);

        if (bigdecimal.compareTo(BigDecimal.valueOf(0)) < 0) {
            // 値がマイナスだった場合の処理
//            logger.log(Level.WARNING, classname, methodName, "param is minus.");
            return NUM_MINUS;
        } else if (bigdecimal.precision() - bigdecimal.scale() > limit[0]) {
            // 整数部の桁数が上限を超えてる場合の処理
//            logger.log(Level.WARNING, classname, methodName, "param is over integer length.");
            return NUM_INTEGER_OVER;
        } else if (bigdecimal.scale() > limit[1]) {
            // 小数点以下の桁数が上限を超えてる場合の処理
//            logger.log(Level.WARNING, classname, methodName, "param is over decimal length.");
            return NUM_DECIMAL_OVER;
        } else {
            return 0;
        }
    }

    /**
     * 小数の桁数を丸める（四捨五入）
     *
     * @param num　対象数
     * @param limit　有効桁数
     * @return
     */
    public static Double roundUpNum(Double num, int limit) {
        // 小数点以下の桁数が上限を超えてる場合は丸める
        BigDecimal value = new BigDecimal(num);
        BigDecimal roundUp = value.setScale(limit, BigDecimal.ROUND_UP);
        return roundUp.doubleValue();
    }

    public static boolean checkBeaconId(String str) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((str == null) || (str.equals(""))) {
            return true;
        }

        // 文字数チェック
        if ((STR_LEN_1 > str.length()) || (str.length() > STR_LEN_36)) {
//            logger.log(Level.WARNING, classname, methodName, "Length over.");
            return false;
        }

        // 使用可能文字チェック
        if (!(isBeaconId(str))) {
//            logger.log(Level.WARNING, classname, methodName, "Bad use character.");
            return false;
        }
        return true;
    }

    public static boolean isBeaconId(String str) {
        String ptnStr = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";
        Pattern ptn = Pattern.compile(ptnStr);
        Matcher mc = ptn.matcher(str);
        return mc.matches();
    }

    public static boolean checkFacility(List<String> type, List<Integer> id) {

//        String methodName = new Object() {
//        }.getClass().getEnclosingMethod().getName();
//        LogManage logger = new LogManage();
        // nullのときはチェックしない
        if ((type == null) || (id == null)) {
            return true;
        }

        // カテゴリと値が同数かチェック
        if (type.size() != id.size()) {
//            logger.log(Level.WARNING, classname, methodName, "Disagreement type and id.");
            return false;
        }

        for (int i = 0; i < type.size(); i++) {
            // 文字数チェック
            if ((STR_LEN_0 > type.get(i).length()) || (type.get(i).length() > STR_LEN_45)) {
//                logger.log(Level.WARNING, classname, methodName, "Length over type.");
                return false;
            }
        }

        for (int i = 0; i < id.size(); i++) {
            // 範囲チェック
            if (id.get(i) < VAL_0 || id.get(i) > VAL_65535) {
//                logger.log(Level.WARNING, classname, methodName, "Over range.");
                return false;
            }
        }
        return true;
    }

}
