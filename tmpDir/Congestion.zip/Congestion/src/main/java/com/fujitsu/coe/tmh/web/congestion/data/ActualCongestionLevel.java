/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fujitsu.coe.tmh.web.congestion.data;

/**
 *
 * @author fujitsu
 */
public class ActualCongestionLevel {
    private String time_from;
    private String time_to;
    private int level;

    public String getTime_from() {
        return time_from;
    }

    public void setTime_from(String time_from) {
        this.time_from = time_from;
    }

    public String getTime_to() {
        return time_to;
    }

    public void setTime_to(String time_to) {
        this.time_to = time_to;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    
    public ActualCongestionLevel(String from, String to, int level){
        this.time_from=from;
        this.time_to=to;
        this.level=level;
    }
}
