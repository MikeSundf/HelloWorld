package com.fujitsu.coe.tmh.web.congestion;




import com.fujitsu.coe.tmh.web.congestion.data.ActualCongestionLevel;
import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.user.ActionLogger;
import com.fujitsu.coe.tmh.web.util.AdminType;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.IdExistCheck;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import com.fujitsu.coe.tmh.web.util.LogManage;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toTS;
//import com.fujitsu.coe.tmh.web.util.LogManage_r2;
import com.fujitsu.coe.tmh.web.util.ValidationCheck;
import javax.ws.rs.FormParam;


/**
 * Services related to the congestion service .
 *
 * @author sun
 */
@Path("/")
@ApplicationScoped
public class CongestionService {

    String classname = CongestionService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    private AdminType adminUtil;
    @Inject
    private LogManage logger;
    @Inject
    private IdExistCheck idExist;
    @Inject
    private ActionLogger aLogger;
    /**
     *
     * @param adminuser
     * @param facility_type
     * @param str_facility_id
     * @param time_from
     * @param time_to
     * @param str_congestion_level
     * @return
     * @throws java.sql.SQLException
     */
    @POST
    @Path("/setCongestion")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Map<String, Object> setCongestion(
            @FormParam("admin_id") String adminuser,
            @FormParam("facility_type") String facility_type,
            @FormParam("facility_id") String str_facility_id,
            @FormParam("time_from") String time_from,
            @FormParam("time_to") String time_to,
            @FormParam("congestion_level") String str_congestion_level
    ) throws SQLException  {
        aLogger.log(adminuser, "SET_CONGESTION", null, 
                String.format("[admin_id=%s] [facility_type=%s] [facility_id=%s] "
                        + "[time_from=%s] [time_to=%s] [congestion_level=%s] ", 
                        adminuser,facility_type,str_facility_id,time_from,time_to,
                        str_congestion_level));
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[admin_id=" + adminuser + ", "
                + "facility_type=" + facility_type + ", "
                + "facility_id=" + str_facility_id + ", "        
                + "time_from=" + time_from + ", "
                + "time_to=" + time_to + ", "        
                + "congestion_level=" + str_congestion_level + "]");

        // 必須パラメータチェック
        if (adminuser == null || adminuser.equals("") || facility_type == null || facility_type.equals("")
                || str_facility_id == null || time_from == null ||time_from.equals("") 
                || time_to == null || time_to.equals("") || str_congestion_level == null) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(adminuser))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        int facility_id,congestion_level = 0;
        
        try{
            facility_id = Integer.parseInt(str_facility_id);
            congestion_level = Integer.parseInt(str_congestion_level);
        }catch(NumberFormatException e){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);            
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date timeFrom,timeTo; //to use some method in java.util.date, set it as Date first.
        try {
            timeFrom = sdf.parse(time_from);
            timeTo = sdf.parse(time_to);
        } catch (ParseException ex) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        if (timeFrom.after(timeTo)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(adminuser) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }
            /**
             * 権限チェック　
             */
            int auth = adminUtil.getUserType(adminuser);
            if (auth <= USER_INFO_TYPE_USER) { //any operator?
                logger.log(Level.SEVERE, classname, methodName, NO_AUTHORITY_CODE + " " + NO_AUTHORITY_MSG);
                logger.log(Level.FINE, classname, methodName, "END");
                return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
            }
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        try {
            db.update("UPDATE time_slot SET actual_congestion_level=? where "
                    + "facility_type=? and facility_id=? and "
                    + "start_time>=? and start_time<? ", congestion_level,
                    facility_type, facility_id,
                    toTS(new Date(timeFrom.getTime())),toTS(new Date(timeTo.getTime())));
        } catch (SQLException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", ex);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     *
     * @param user_id
     * @param facility_type
     * @param str_facility_id
     * @param time_from
     * @param time_to
     * @return
     * @throws java.sql.SQLException
     */
    @GET
    @Path("/getCongestion")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> getCongestion(
            @QueryParam("user_id") String user_id,
            @QueryParam("facility_type") String facility_type,
            @QueryParam("facility_id") String str_facility_id,
            @QueryParam("time_from") String time_from,
            @QueryParam("time_to") String time_to
    ) throws SQLException  {
        aLogger.log(user_id, "GET_CONGESTION", null, 
                String.format("[user_id=%s] [facility_type=%s] [facility_id=%s] "
                        + "[time_from=%s] [time_to=%s]",
                        user_id,facility_type,str_facility_id,time_from,time_to));
        String methodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ", "
                + "facility_type=" + facility_type + ", "
                + "facility_id=" + str_facility_id + ", " 
                + "time_from=" + time_from + ", "
                + "time_to=" + time_to + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("") || facility_type == null || facility_type.equals("")
                || str_facility_id == null ) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // バリデーションチェック
        if (!(ValidationCheck.checkUserId(user_id))) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        int facility_id = 0;
        
        try{
            facility_id = Integer.parseInt(str_facility_id);
        }catch(NumberFormatException e){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);            
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        java.util.Date timeFrom=null ,timeTo=null; //to use some method in java.util.date, set it as Date first.
        try {
            if (time_from!=null && !time_from.equals("")){
                timeFrom = sdf.parse(time_from);
            }
            if (time_to!=null && !time_to.equals("")){
                timeTo = sdf.parse(time_to);
            }
        } catch (ParseException ex) {
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }
        
        if (timeFrom!=null && timeTo!=null && timeFrom.after(timeTo)){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }        
        
        // パラメタチェック
        try {
            // ユーザIDチェック
            if (idExist.validateUserId(user_id) == false) {
                logger.log(Level.WARNING, classname, methodName, UNREGISTERED_ID_MSG);
                return ErrorFactory.createError(UNREGISTERED_ID_CODE, UNREGISTERED_ID_MSG);
            }

        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        
        Map<String, Object> res = new HashMap<> ();
        List<ActualCongestionLevel> resLink = new ArrayList<>();

        try {
            if (timeFrom==null && timeTo==null){
                db.query("SELECT start_time,end_time,coalesce(actual_congestion_level) FROM time_slot where "
                        + "facility_type=? and facility_id=? order by start_time", (rs)->{
                            Date t1 = new Date(rs.getTimestamp(1));
                            Date t2 = new Date(rs.getTimestamp(2));
                            resLink.add(new ActualCongestionLevel(
                            sdf.format(new java.util.Date(t1.getTime())),
                            sdf.format(new java.util.Date(t2.getTime())),
                            rs.getInt(3)
                            ));
                        }, facility_type,facility_id);
            }else if(timeTo==null){ // only timeFrom has value
                db.query("SELECT start_time,end_time,coalesce(actual_congestion_level) FROM time_slot where "
                        + "facility_type=? and facility_id=? and start_time>=? order by start_time", (rs)->{
                            Date t1 = new Date(rs.getTimestamp(1));
                            Date t2 = new Date(rs.getTimestamp(2));
                            resLink.add(new ActualCongestionLevel(
                            sdf.format(new java.util.Date(t1.getTime())),
                            sdf.format(new java.util.Date(t2.getTime())),
                            rs.getInt(3)
                            ));
                        }, facility_type,facility_id,toTS(new Date(timeFrom)));                
            }else if(timeFrom==null){ //only timeTo has value
                db.query("SELECT start_time,end_time,coalesce(actual_congestion_level) FROM time_slot where "
                        + "facility_type=? and facility_id=? and start_time <=? order by start_time", (rs)->{
                            Date t1 = new Date(rs.getTimestamp(1));
                            Date t2 = new Date(rs.getTimestamp(2));
                            resLink.add(new ActualCongestionLevel(
                            sdf.format(new java.util.Date(t1.getTime())),
                            sdf.format(new java.util.Date(t2.getTime())),
                            rs.getInt(3)
                            ));
                        }, facility_type,facility_id,toTS(new Date(timeTo)));                
            }else{// all have value
                db.query("SELECT start_time,end_time,coalesce(actual_congestion_level) FROM time_slot where "
                        + "facility_type=? and facility_id=? and start_time between ? and ? order by start_time", (rs)->{
                            Date t1 = new Date(rs.getTimestamp(1));
                            Date t2 = new Date(rs.getTimestamp(2));
                            resLink.add(new ActualCongestionLevel(
                            sdf.format(new java.util.Date(t1.getTime())),
                            sdf.format(new java.util.Date(t2.getTime())),
                            rs.getInt(3)
                            ));
                        }, facility_type,facility_id,toTS(new Date(timeFrom)),toTS(new Date(timeTo)));                 
            }
        } catch (SQLException ex) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB SELECT error.", ex);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        
        res.put("congestionInfo", resLink);
        logger.log(Level.FINE, classname, methodName, "END");
        return res;
    }
    
}
