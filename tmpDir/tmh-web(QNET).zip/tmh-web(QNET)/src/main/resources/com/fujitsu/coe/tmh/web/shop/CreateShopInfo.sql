INSERT INTO shop (name, venue_id, category, address, 
                    tel, remarks, location, map_hint, passcode, 
                    utility_value, gender_age_group, enable_flag)
       SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?