INSERT 
INTO user_coupon_reading( 
  user_id
  , coupon_id
  , reading_start_time
  , reading_end_time
  , reading_time
) 
VALUES ( 
  ?
  , ?
  , ?
  , ?
  , ?
) 
