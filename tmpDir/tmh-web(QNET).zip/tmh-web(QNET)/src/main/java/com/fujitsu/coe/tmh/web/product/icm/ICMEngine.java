package com.fujitsu.coe.tmh.web.product.icm;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Coupon;
import com.fujitsu.coe.tmh.web.product.Product;
import com.fujitsu.coe.tmh.web.product.icm.cs.UserCouponSelector;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.*;
import com.fujitsu.coe.tmh.web.product.icm.pg.ProductGenerator;
import com.fujitsu.coe.tmh.web.product.icm.po.ProductOptimizer;
import com.fujitsu.coe.tmh.web.sim.SysClock;
import com.fujitsu.coe.tmh.web.user.User;
import com.fujitsu.coe.tmh.web.util.SystemSettings;
import com.fujitsu.coe.tmh.web.util.Timer;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author unicenfujitsu
 */
@ApplicationScoped
public class ICMEngine {

    private static final Logger LOGGER = Logger.getLogger(ICMEngine.class.getName());

    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private SystemSettings settings;
    @Inject
    private SysClock clock;
    @Inject
    private Instance<EngineExecutor> executorInstance;

    public List<Product> run(ICMRequest request) throws SQLException, IOException {
        // TODO enable Timer @Inject, get rid of ICMContext, create @Timed("icm") to support timer
        Timer timer = new Timer();
        timer.start("icm");

        ICMContext ctx = new ICMContext(db, user, settings, clock, timer);
        try {
            // Ensure this is outside of transaction scope so it is always written even with rollback
            db.update("INSERT INTO request(id, user_id, venue_id, "
                    + "from_location, to_location, from_lat, from_lon, to_lat, to_lon,"
                    + "hurry, hungry, seats) "
                    + "VALUES(?, ?, ?, "
                    + "?, ?, ?, ?, ?, ?, "
                    + "?, ?, ?)",
                    ctx.reqId, user.getId(), user.getVenue(), 
                    request.getFrom(), request.getTo(), request.getFromLocation().getLat(), request.getFromLocation().getLon(), request.getToLocation().getLat(), request.getToLocation().getLon(),
                    request.getHurry(), request.getHungry(), request.getSeats());
            ctx.log(REQUEST, ctx.reqId, ctx.clock.now(), new Date(), user.getId(), user.getVenue(), 
                    request.getFrom(), request.getFromLocation().getLat(), request.getFromLocation().getLon(), 
                    request.getTo(), request.getToLocation().getLat(), request.getToLocation().getLon(),
                    request.getHurry(), request.getHungry(), request.getSeats());

            EngineExecutor executor = executorInstance.get();
            executor.run(ctx, request);
            
            return executor.getResults();
        } finally {
            timer.end();
            LOGGER.log(Level.INFO, timer.toString());
            ctx.log(TIMER, timer.toString());
            ctx.log(CLOSE);
        }
    }

    @RequestScoped
    public static class EngineExecutor {
        @Inject
        private AssortmentDAO assDAO;
        // output
        private List<Product> products;

        public List<Product> getResults() {
            return products;
        }

        @Transactional
        public void run(ICMContext ctx, ICMRequest request) throws SQLException, IOException {
            ctx.timer.start("cache");
            int ttl = Integer.parseInt(ctx.settings.get("icm.cache.secs", "60"));
            List<Product> cache = assDAO.getRecentAssortment(request.getFrom(), request.getTo(), request.getSeats(), ttl);
            ctx.log(CACHE, ttl, cache != null);
            if (cache != null) {
                this.products = cache;
                return;
            }
            ctx.timer.stop();

            // TODO parallel run CS and PG
            ctx.timer.start("cs");
            UserCouponSelector cs = new UserCouponSelector(ctx);
            List<Coupon> coupons = cs.select(request.getHurry(), request.getHungry());
            ctx.timer.stop();

            ctx.timer.start("pg");
            ProductGenerator pg = new ProductGenerator(ctx, request);
            List<Product> products = pg.generate();
            ctx.timer.stop();

            ctx.timer.start("ca");
            CouponAssigner ca = new CouponAssigner(ctx, coupons, products);
            ca.assign();
            ctx.timer.stop();

            ctx.timer.start("po");
            ProductOptimizer po = new ProductOptimizer(ctx, products, request.getHurry());
            po.optimize();
            ctx.timer.stop();

            ctx.timer.start("pr");
            ProductRefiner pr = new ProductRefiner(ctx, products);
            pr.refine();
            ctx.timer.stop();

            ctx.timer.start("save");
            assDAO.saveAssortment(ctx.reqId, products);
            ctx.timer.stop();

            this.products = products;
        }
    }
}