SELECT
  up.user_id
  , CASE 
    WHEN (gender IS NULL) 
      THEN '-' 
    ELSE gender 
    END
  , CASE 
    WHEN (age_group IS NULL) 
      THEN - 1 
    ELSE age_group 
    END
  , CASE 
    WHEN (income_group IS NULL) 
      THEN - 1 
    ELSE income_group 
    END 
  , user_preference.pref_key , user_preference.pref_value 
FROM
  user_profile up 
  LEFT JOIN user_preference 
    ON up.user_id = user_preference.user_id 
WHERE
  up.user_id = ?; 