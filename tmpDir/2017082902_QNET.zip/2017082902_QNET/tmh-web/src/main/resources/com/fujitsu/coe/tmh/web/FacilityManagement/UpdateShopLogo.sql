UPDATE shop_logo 
SET
  logo = ?
WHERE
  shop_id = ?