package com.fujitsu.coe.tmh.web.product.icm.po;

/**
 *
 * @author chuakayick
 */
public class CouponValuator {
    
    public static double getValue(int dwellTime) {
        return Math.min(12, (dwellTime / 15) * 2);
    }
}
