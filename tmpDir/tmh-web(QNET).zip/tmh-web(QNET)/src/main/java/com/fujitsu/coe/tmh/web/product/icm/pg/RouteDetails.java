package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.route.Step;
import java.sql.SQLException;

/**
 *
 * @author kychua
 */
public interface RouteDetails {

    public Egress.Mode getMode();

    public double getAccessTime() throws SQLException;

    public double getTravelTime() throws SQLException;

    public double getWaitingTime(long stepTime, Step step) throws SQLException;
}
