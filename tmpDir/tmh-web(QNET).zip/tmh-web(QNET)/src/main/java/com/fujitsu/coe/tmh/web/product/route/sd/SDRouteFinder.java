package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import static com.fujitsu.coe.tmh.web.product.icm.log.ICMLogger.LogCategory.PG;
import com.fujitsu.coe.tmh.web.product.icm.pg.PGUtil;
import com.fujitsu.coe.tmh.web.product.route.Route;
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.http.client.fluent.Executor;
import org.apache.http.client.fluent.Request;

/**
 *
 * @author kychua
 */
public class SDRouteFinder {

    private static final Logger LOGGER = Logger.getLogger(SDRouteFinder.class.getName());
    private static final String UTF8 = "UTF-8";
    private static final String URL = "http://www.streetdirectory.com/api/?mode=journey&output=json&country=sg&q=%s+to+%s&methods=all&no_route=1&info=1";
    private ICMContext ctx;

    public SDRouteFinder(ICMContext ctx) {
        this.ctx = ctx;
    }

    /**
     * Returns a list of routes for multiple transport modes from the starting
     * to ending point.
     *
     * @param from starting point
     * @param to ending point
     * @return list of feasible routes
     * @throws IOException
     * @throws SQLException
     */
    public List<? extends Route> route(String from, String to) throws IOException, SQLException {
        // connect to server via HTTP
        String response = getSDResponse(from, to);

        // parse JSON response
        ctx.timer.start("pg.parse");
        SDRouteResults results = new ObjectMapper().readValue(response, SDRouteResults.class);
        ctx.timer.stop();
        if (results == null) {
            // invalid JSON? let's terminate and examine the response...
            LOGGER.log(Level.WARNING, response);
            throw new IllegalStateException();
        }

        // Convert to ICM steps
        ctx.timer.start("pg.map");
        List<ICMRoute> routes = new ICMRouteMapper().map(results);
        ctx.timer.stop();
        return routes;
    }

    // gets the route response from SD.com, using cache if available.
    private String getSDResponse(String from, String to) throws SQLException, IOException {
        // try cache
        String response = null;
        boolean cached = false;
        try {
            if (ctx.db != null) {
                ctx.timer.start("pg.cache");
                response = ctx.db.queryForString("SELECT response FROM route_cache WHERE from_location=? AND to_location=?", from, to);
                ctx.timer.stop();
                if (response != null) {
                    return response;
                }
            }

            ctx.timer.start("pg.http");
            response = PGUtil.curl(String.format(ctx.settings.get("route.url", URL), URLEncoder.encode(from, UTF8), URLEncoder.encode(to, UTF8)));
            ctx.timer.stop();
            // save to cache
            if (ctx.db != null) {
                ctx.timer.start("pg.cache");
                ctx.db.update("INSERT INTO route_cache(from_location, to_location, response) VALUES(?, ?, ?)", from, to, response);
                ctx.timer.stop();
            }
            return response;
        } finally {
            ctx.log(PG, cached, response);
        }
    }
}
