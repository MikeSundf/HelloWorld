package com.fujitsu.coe.tmh.web.product.route.sd;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Collections;
import java.util.List;

/**
 * JSON model for root.bustrain and root.bus;
 *
 * @author ky
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SDBusTrainRoute {

    private List<List<SDStep>> journey;  // is
    private SDRouteTotal total; // td

    public void setIs(List<List<SDStep>> journey) {
        this.journey = journey;
    }

    public void setTd(SDRouteTotal total) {
        this.total = total;
    }

    public SDRouteTotal getTotal() {
        return total;
    }

    public List<SDStep> getSteps() {
        if (journey.isEmpty() || journey.get(0) == null) {
            return Collections.emptyList();
        } else {
            return journey.get(0);
        }
    }
}
