package com.fujitsu.coe.tmh.web.user;

import com.fujitsu.coe.ss.jdbc.JdbcTemplate;
import com.fujitsu.coe.ss.jdbc.Transactional;
import com.fujitsu.coe.tmh.web.product.icm.pg.PGUtil;
import com.fujitsu.coe.tmh.web.sim.SysClock;
import com.fujitsu.coe.tmh.web.util.AdminType;
import com.fujitsu.coe.tmh.web.util.ErrorFactory;
import com.fujitsu.coe.tmh.web.util.MapBuilder;
import com.fujitsu.coe.tmh.web.util.ValidationCheck;
import com.fujitsu.coe.tmh.web.util.LogManage;
import static com.fujitsu.coe.tmh.web.util.ParamConstants.*;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toTS;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author unicenfujitsu
 */
@Path("/profile")
@ApplicationScoped
public class ProfileService {

    //those keys at client app:preferences.xml that will not save to user_preference

    String classname = ProfileService.class.getName();

    @Inject
    private JdbcTemplate db;
    @Inject
    private User user;
    @Inject
    private ActionLogger aLogger;
    @Inject
    private SysClock clock;
    @Inject
    private LogManage logger;
    @Inject
    private AdminType adminUtil;
    
    /**
     * プロファイル登録
     * @param user_id
     * @param name
     * @param email
     * @param address
     * @param postal
     * @param genderStr
     * @param ageGroupStr
     * @param incomeGroupStr
     * @param is_public
     * @param category
     * @param value
     * @param job
     * @param workplace_address
     * @return
     * @throws SQLException 
     * @author Qnet)gotoh
     */
    @POST
    @Path("/save")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    @Transactional
    public Map<String, Object> saveProfile(
            @FormParam("user_id") String user_id,
            @FormParam("name") @DefaultValue("") String name,
            @FormParam("email") String email,
            @FormParam("address") @DefaultValue("") String address,
            @FormParam("postal") @DefaultValue("") String postal,
            @FormParam("genderStr") @DefaultValue("") String genderStr,
            @FormParam("ageGroupStr") @DefaultValue("") String ageGroupStr,
            @FormParam("incomeGroupStr") @DefaultValue("") String incomeGroupStr,
            @FormParam("is_public") String is_public,
            @FormParam("category[]") List<String> category,
            @FormParam("value[]") List<String> value,
            @FormParam("job") @DefaultValue("") String job,
            @FormParam("workplace_address") @DefaultValue("") String workplace_address
            ) throws SQLException {
        aLogger.log(user_id, "PROFILE_UPDATE", null,
                String.format("[user_id=%s] [name=%s] [email=%s] [address=%s] [postal=%s] [genderStr=%s] [ageGroupStr=%s] [incomeGroupStr=%s] [is_public=%s] [job=%s] [workplace_address=%s]",
                user_id, name, email, address, postal, genderStr, ageGroupStr, incomeGroupStr, is_public, job, workplace_address));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + ",name=" + name + ",email=" + email + ",address=" + address + ",postal=" + postal + ",genderStr=" + genderStr + ",ageGroupStr=" + ageGroupStr + ",incomeGroupStr=" + incomeGroupStr + "is_public,=" + is_public + ",job=" + job + ",workplace_address=" + workplace_address + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("") || email == null || email.equals("") || is_public == null || is_public.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }        
        
        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(user_id)) ||
           !(ValidationCheck.checkStr45(name)) ||
           !(ValidationCheck.checkEmail(email)) ||
           !(ValidationCheck.checkStr100(address)) ||
           !(ValidationCheck.checkPostal(postal)) ||
           !(ValidationCheck.checkGender(genderStr)) ||
           !(ValidationCheck.checkAgeGroup(ageGroupStr)) ||
           !(ValidationCheck.checkIncomeGroup(incomeGroupStr)) ||
           !(ValidationCheck.checkIsPublic(is_public)) ||
           !(ValidationCheck.checkCategoryValue(category,value)) ||
           !(ValidationCheck.checkJob(job)) ||
           !(ValidationCheck.checkWorkplaceAddress(workplace_address))
          ){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 種別取得
        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?",user_id);
        if(recoredCount == 0){
            logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
            return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
        }
        int type = adminUtil.getUserType(user_id);

        // 権限確認
        if(type != USER_INFO_TYPE_USER){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }

        // 値変換
        boolean pref_is_public = Boolean.valueOf(is_public).booleanValue();
        Character gender = (genderStr == null || genderStr.equals("")) ? null : genderStr.charAt(0);
        Integer ageGroup = (ageGroupStr == null || ageGroupStr.equals("")) ? null : Integer.valueOf(ageGroupStr);
        Integer incomeGroup = (incomeGroupStr == null || incomeGroupStr.equals("")) ? null : Integer.valueOf(incomeGroupStr);

        // user_infoデータベース設定
        try{
            db.update("UPDATE user_info SET name=?, home_address=?, postal_code=?, update_time=? WHERE user_id=?", name, address, postal, toTS(clock.now()), user_id);
            logger.log(Level.FINE, classname, methodName, "UPDATE user_info:[name=" + name + ",home_address=" + address + ",postal_code=" + postal + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }

        // user_profileデータベース設定
        try{
            db.update("UPDATE user_profile SET gender=? , age_group=?, income_group=?, is_public_transport=?, job=?, workplace_address=? WHERE user_id=?", gender, ageGroup, incomeGroup, pref_is_public, job, workplace_address, user_id);
            logger.log(Level.FINE, classname, methodName, "UPDATE user_profile:[gender=" + gender + ",age_group=" + ageGroup + ",income_group=" + incomeGroup + ",pref_is_public=" + pref_is_public + ",job=" + job + ",workplace_address=" + workplace_address + "]");
        } catch (SQLException sqle) {
            logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
            return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
        }
        
        // user_preferenceデータベース設定
        for(int i = 0; i < category.size(); i++){
            if (db.queryForString("SELECT user_id FROM user_preference WHERE user_id=? AND pref_key =?", user_id, category.get(i)) == null) {
                try{
                    db.update("INSERT INTO user_preference(user_id, pref_key, pref_value) VALUES (?, ?, ?)", user_id, category.get(i), value.get(i));
                    logger.log(Level.FINE, classname, methodName, "INSERT user_preference:[user_id=" + user_id + ",pref_key=" + category.get(i) + ",pref_value=" + value.get(i) + "]");
                } catch (SQLException sqle) {
                    logger.thrownLog(Level.SEVERE, classname, methodName, "DB INSERT error.", sqle);
                    return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                }
            }else{
                try{
                    db.update("UPDATE user_preference SET pref_value=?  WHERE user_id=? AND pref_key =?", value.get(i), user_id, category.get(i));
                    logger.log(Level.FINE, classname, methodName, "INSERT user_preference:[user_id=" + user_id + ",pref_key=" + category.get(i) + ",pref_value=" + value.get(i) + "]");
                } catch (SQLException sqle) {
                    logger.thrownLog(Level.SEVERE, classname, methodName, "DB UPDATE error.", sqle);
                    return ErrorFactory.createError(SQL_ERROR_CODE, SQL_ERROR_MSG);
                }
            }
        }
        logger.log(Level.FINE, classname, methodName, "END");
        return MapBuilder.build("ok", true);
    }

    /**
     * プロファイル取得
     * @param user_id
     * @return
     * @throws SQLException 
     * @author Qnet)gotoh
     */
    @GET
    @Path("/list")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String,Object> getProfile(@QueryParam("user_id") String user_id) throws SQLException {
        aLogger.log(user_id, "PROFILE_VIEW", user_id, String.format("[user_id=%s]", user_id));

        String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
        logger.log(Level.FINE, classname, methodName, "START");
        logger.log(Level.FINE, classname, methodName, "Param:[user_id=" + user_id + "]");

        // 必須パラメータチェック
        if (user_id == null || user_id.equals("")) {
            logger.log(Level.SEVERE, classname, methodName, ILLEGAl_PARAM_CODE + " " + ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }        
        
        // バリデーションチェック
        if(!(ValidationCheck.checkUserId(user_id))){
            logger.log(Level.WARNING, classname, methodName, ILLEGAl_PARAM_MSG);
            return ErrorFactory.createError(ILLEGAl_PARAM_CODE, ILLEGAl_PARAM_MSG);
        }

        // 種別取得
        long recoredCount = db.queryForLong("SELECT COUNT(*) FROM user_info WHERE user_id=?",user_id);
        if(recoredCount == 0){
            logger.log(Level.WARNING, classname, methodName, UNREGISTERED_USER_MSG);
            return ErrorFactory.createError(UNREGISTERED_USER_CODE, UNREGISTERED_USER_MSG);
        }
        int type = adminUtil.getUserType(user_id);

        // 権限確認
        if(type != USER_INFO_TYPE_USER){
            logger.log(Level.WARNING, classname, methodName, NO_AUTHORITY_MSG);
            return ErrorFactory.createError(NO_AUTHORITY_CODE, NO_AUTHORITY_MSG);
        }

        // データベース参照
        final Map<String,Object> response = new LinkedHashMap<>();
        db.query("SELECT name, email, home_address, postal_code FROM user_info WHERE user_id=?", (rs) -> {
            response.put("name", rs.getString(1));
            response.put("email", rs.getString(2));
            response.put("address", rs.getString(3));
            response.put("postal", rs.getString(4));
        }, user_id);
        db.query("SELECT gender, age_group, income_group, is_public_transport, job, workplace_address FROM user_profile WHERE user_id=?", (rs) -> {
            response.put("gender", rs.getString(1));
            response.put("agegroup", rs.getString(2));
            response.put("incomegroup", rs.getString(3));
            response.put("is_public_transport", rs.getString(4));
            response.put("job", rs.getString(5));
            response.put("workplace_address", rs.getString(6));
        }, user_id);
        
        
        List categories = new ArrayList(); 
        db.query("SELECT * FROM user_preference WHERE user_id=?", (rs) -> {
            Map param = new HashMap();
            param.put("pref_key", rs.getString("pref_key"));            
            param.put("pref_value", rs.getString("pref_value"));
            categories.add(param);
        }, user_id);
        response.put("categories", categories);
        
        logger.log(Level.FINE, classname, methodName, "END");
        return response;
    }

    @GET
    @Path("/geocode")
    @Produces(MediaType.APPLICATION_JSON)
    @LogLocation
    public Map<String, Object> geocode(@QueryParam("code") String code) throws IOException, SQLException {
        aLogger.log("GEOCODE", code, null);
        if (code == null || !code.matches("\\d{6}")) {
            return MapBuilder.create().build();
        }
        
        // try cache
        String response = db.queryForString("SELECT response FROM route_cache WHERE from_location IS NULL AND to_location=?", code);
        if (response == null) {
            response = PGUtil.curl(String.format("http://www.streetdirectory.com/api/?mode=search&act=all&output=js&callback=set_data&start=0&limit=20&country=sg&profile=template_1&show_additional=0&no_total=1&q=%s", code));
            db.update("INSERT INTO route_cache(to_location, response) VALUES(?, ?)", code, response);
        }
        Matcher matcher = Pattern.compile(".+?a\":\"(.+?)\",\"x\":(.+?),\"y\":(.+?),.*").matcher(response);
        if (!matcher.matches()) {
            return MapBuilder.create().build();
        }
        
        /* XXX: Since /geocode is (currently) exclusively used for the profile screen, 
                any results can be attached to the current user without waiting for
                the save profile action. Due to time constraints this is used to workaround
                user_info having postal_code without home_address.
        
                This causes a side-effect where in the first-time profile screen, the address
                is saved even before the user hits "I'M DONE". If a user exits the app after
                setting the address but before hitting I'M DONE, the app will skip this step
                after relaunching and proceed. This is considered a low frequency and low impact
                (by KY).
        */
        String address = matcher.group(1).substring(0, matcher.group(1).indexOf(','));
        db.update("UPDATE user_info SET home_address=?, postal_code=? WHERE id=?", address, code, user.getId());
        
        return MapBuilder.create("postal", code)
                .put("address", address)
                .put("lon", Double.parseDouble(matcher.group(2)))
                .put("lat", Double.parseDouble(matcher.group(3)))
                .build();
    }

    private String dump(HttpServletRequest req) {
        StringBuilder buf = new StringBuilder();
        Collections.list(req.getParameterNames()).stream().forEach((key) -> {
            buf.append(String.format("[%s=%s] ", key, req.getParameter(key)));
        });
        return buf.toString();
    }
}
