package com.fujitsu.coe.tmh.web.product.icm.pg;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.product.Egress;
import com.fujitsu.coe.tmh.web.product.icm.ICMContext;
import com.fujitsu.coe.tmh.web.product.route.Route;
import com.fujitsu.coe.tmh.web.product.route.Step;
import static com.fujitsu.coe.tmh.web.util.TimeUtil.toHHMM;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kychua
 */
class BusTrainRouteDetails extends AbstractRouteDetails {

    private static final Logger LOGGER = Logger.getLogger(BusTrainRouteDetails.class.getName());

    public BusTrainRouteDetails(ICMContext ctx, Route route, Egress.Mode mode) {
        super(ctx, route, mode);
    }

    @Override
    public double getWaitingTime(long stepTime, Step step) throws SQLException {
        if ("BUS".equals(step.getVehicleType())) {
            // avoid SQL injection from remote services
            if (!step.getService().matches("\\d+\\w?(/\\d+\\w?)*") && !step.getService().matches("RWS\\d+")) {
                throw new IllegalArgumentException(step.getService());
            }
            LOGGER.log(Level.INFO, "Service {0} @ Bus Stop {1}", new Object[]{step.getService(), step.getDetails()});
            String service = "'" + step.getService().replaceAll("/", "','") + "'";
            // TODO probably multiple similar calls, should be cached
            return (int) Math.ceil(ctx.db.queryForDouble(String.format("SELECT MIN(%s) FROM bus_frequency bf "
                    + "INNER JOIN bus_service bs ON bs.service_number=bf.service AND bs.direction=bf.direction "
                    + "WHERE bs.service_number IN (%s) AND bs.stop_code=?", toPeakCol(stepTime), service),
                    Integer.parseInt(step.getDetails())) / 2);
        } else if ("TRAIN".equals(step.getVehicleType())) {
            return 2;
        }
        return 0;
    }

    private String toPeakCol(long time) {
        int now = toHHMM(new Date(time));
        if (now >= 630 && now <= 830) {
            return "am_peak";
        } else if (now >= 831 && now <= 1659) {
            return "am_off";
        } else if (now >= 1700 && now <= 1900) {
            return "pm_peak";
        } else {
            return "pm_off";
        }
    }
}
