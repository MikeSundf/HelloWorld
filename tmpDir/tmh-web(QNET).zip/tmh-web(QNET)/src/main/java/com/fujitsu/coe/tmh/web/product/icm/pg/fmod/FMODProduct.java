package com.fujitsu.coe.tmh.web.product.icm.pg.fmod;

import com.fujitsu.coe.ss.util.Date;
import com.fujitsu.coe.tmh.web.util.Location;

/**
 *
 * @author kychua
 */
public class FMODProduct {
    private String requestId;
    private double choiceProbability;
    private Location pickup;
    private Location dropoff;
    private Date dropoffEarly;
    private Date dropoffLate;
    private Date pickupEarly;
    private Date pickupLate;
    private double fare;
    private double passengerNum;
    private String productId;
    private String scheduleId;
    private double serviceType;
    private double travelDistance;
    private double travelTime;

    public FMODProduct() {
        
    }
    
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestId() {
        return requestId;
    }
    
    public double getChoiceProbability() {
        return choiceProbability;
    }

    public void setChoiceProbability(double choiceProbability) {
        this.choiceProbability = choiceProbability;
    }

    public Location getPickup() {
        return pickup;
    }

    public void setPickup(Location pickup) {
        this.pickup = pickup;
    }

    public Location getDropoff() {
        return dropoff;
    }

    public void setDropoff(Location dropoff) {
        this.dropoff = dropoff;
    }

    public Date getDropoffEarly() {
        return dropoffEarly;
    }

    public void setDropoffEarly(Date dropoffEarly) {
        this.dropoffEarly = dropoffEarly;
    }

    public Date getDropoffLate() {
        return dropoffLate;
    }

    public void setDropoffLate(Date dropoffLate) {
        this.dropoffLate = dropoffLate;
    }

    public Date getPickupEarly() {
        return pickupEarly;
    }

    public void setPickupEarly(Date pickupEarly) {
        this.pickupEarly = pickupEarly;
    }

    public Date getPickupLate() {
        return pickupLate;
    }

    public void setPickupLate(Date pickupLate) {
        this.pickupLate = pickupLate;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    public double getPassengerNum() {
        return passengerNum;
    }

    public void setPassengerNum(double passengerNum) {
        this.passengerNum = passengerNum;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(String scheduleId) {
        this.scheduleId = scheduleId;
    }

    public double getServiceType() {
        return serviceType;
    }

    public void setServiceType(double serviceType) {
        this.serviceType = serviceType;
    }

    public double getTravelDistance() {
        return travelDistance;
    }

    public void setTravelDistance(double travelDistance) {
        this.travelDistance = travelDistance;
    }

    public double getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(double travelTime) {
        this.travelTime = travelTime;
    }
    
    
}
